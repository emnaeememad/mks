<?php

namespace Database\Factories;

use App\Enum\AuthorTypes;
use App\Enum\Genders;
use App\Models\Author;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Author>
 */
class AuthorFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $authorNameAr = fake('ar')->name();
        $authorNameEn = fake('en')->name();

        return [
            'slug_ar' => Author::slug($authorNameAr),
            'slug_en' => Author::slug($authorNameEn),
            'name_ar' => $authorNameAr,
            'name_en' => $authorNameEn,
            'photo' => 'noimage/jpg',
            'gender' => Genders::male['name_en'],
            'is_public' => 1,
            'is_home' => 1,
            'type' => AuthorTypes::individual,
        ];
    }
}
