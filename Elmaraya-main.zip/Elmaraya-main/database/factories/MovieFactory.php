<?php

namespace Database\Factories;

use App\Enum\PublishStatus;
use App\Models\Movie;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Movie>
 */
class MovieFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $nameAr = fake('ar')->name();
        $nameEn = fake('en')->name();

        return [
            'cover' => 'noimage.jpg',
            'main_image' => 'noimage.jpg',
            'thumb_image' => 'noimage.jpg',
            'slug_ar' => Movie::slug($nameAr),
            'slug_en' => Movie::slug($nameEn),
            'name_ar' => $nameAr,
            'name_en' => $nameEn,
            'brief_ar' => fake()->sentence(6),
            'brief_en' => fake()->sentence(6),
            'description_ar' => fake()->sentence(50),
            'description_en' => fake()->sentence(50),
            'total_views' => 0,
            'total_shares' => 0,
            'status' => PublishStatus::published,
            'is_home' => 1,
            'is_featured' => 1,
            'post_date' => fake()->date(),
        ];
    }
}
