<?php

namespace Database\Factories;

use App\Enum\CategoryModules;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Category>
 */
class CategoryFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name_ar' => fake('ar')->name(),
            'name_en' => fake('en')->name(),
            'module' => CategoryModules::books,
        ];
    }
}
