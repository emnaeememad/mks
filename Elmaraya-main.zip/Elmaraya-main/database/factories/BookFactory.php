<?php

namespace Database\Factories;

use App\Enum\BookRequestType;
use App\Enum\PublishStatus;
use App\Models\Author;
use App\Models\Book;
use App\Models\Category;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Book>
 */
class BookFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $nameAr = fake('ar')->name();
        $nameEn = fake('en')->name();

        $category = Category::factory(1)->create()->first();

        $author = Author::factory(1)->create()->first();

        return [
            'main_image' => 'noimage.jpg',
            'slug_ar' => Book::slug($nameAr),
            'slug_en' => Book::slug($nameEn),
            'name_ar' => $nameAr,
            'name_en' => $nameEn,
            'hard_copy_price' => fake()->numerify('###.#'),
            'epob_price' => fake()->numerify('###.#'),
            'description_ar' => fake('ar')->text(150),
            'description_en' => fake('en')->text(150),
            'amazon_link' => fake()->url(),
            'category_id' => $category->id,
            'author_id' => $author,
            'number_of_pages' => fake()->numberBetween(0, 500),
            'bar_code' => Str::random(),
            'file' => UploadedFile::fake()->create(Book::slug($nameEn).'.pdf', 148),
            'total_soft_purchased' => 0,
            'total_hard_purchased' => 0,
            'total_views' => 0,
            'total_shares' => 0,
            'status' => PublishStatus::published,
            'reviewer' => fake('en')->text(7),
            'is_home' => 1,
            'is_featured' => 1,
            'is_recommended' => 1,
            'request_type' => BookRequestType::all,
        ];
    }
}
