<?php

namespace Database\Seeders;

use App\Enum\PayableModule;
use App\Enum\PaymentSlugs;
use App\Models\PaymentMethod;
use Illuminate\Database\Seeder;

class PaymentMethodSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        PaymentMethod::create([
            'name_ar' => 'كاش',
            'name_en' => 'Cash',
            'slug' => PaymentSlugs::cash,
            'is_editable' => false,
            'is_active' => true,
            'payable_module' => PayableModule::subscribe,
            'image' => null,
        ]);
        if (file_exists(public_path('credit-card.png'))) {
            if (! is_dir(storage_path('app/public/payment-methods'))) {
                mkdir(storage_path('app/public/payment-methods'));
            }
            copy(public_path('credit-card.png'), storage_path('app/public/payment-methods/credit-card.png'));
        }
        PaymentMethod::create([
            'name_ar' => 'الكارت الإئتماني',
            'name_en' => 'Credit Card',
            'slug' => PaymentSlugs::paymobVisa,
            'is_editable' => false,
            'is_active' => true,
            'payable_module' => PayableModule::books,
            'image' => 'payment-methods/credit-card.png',
        ]);
    }
}
