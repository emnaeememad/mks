<?php

namespace Database\Seeders;

use App\Models\MarayaSetting;
use Illuminate\Database\Seeder;

class MarayaSettingsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        MarayaSetting::truncate();
        $rows = [
            [
                'input_label' => 'رابط الفيسبوك',
                'key' => 'facebook_url',
                'value' => 'https://www.facebook.com/maraya',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'رابط لينكدإن',
                'key' => 'linkedin_url',
                'value' => 'https://www.linkedin.com/maraya',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'رابط انستجرام',
                'key' => 'instagram_url',
                'value' => 'https://www.instagram.com/maraya',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'رابط تويتر',
                'key' => 'twitter_url',
                'value' => 'https://www.twitter.com/maraya',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'رابط يوتيوب',
                'key' => 'youtube_url',
                'value' => 'https://www.youtube.com/maraya',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'رابط تيك توك',
                'key' => 'tiktok_url',
                'value' => 'https://www.tiktok.com/maraya',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'العنوان بالعربية',
                'key' => 'address_ar',
                'value' => 'المملكة العربية السعودية',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'العنوان بالانجليزية',
                'key' => 'address_en',
                'value' => 'المملكة العربية السعودية',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'رقم الهاتف',
                'key' => 'phone_1',
                'value' => '966 5000 0000',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'رقم الهاتف',
                'key' => 'phone_2',
                'value' => '966 5000 0000',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'رقم الهاتف',
                'key' => 'phone_3',
                'value' => '966 5000 0000',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'رقم الهاتف',
                'key' => 'phone_4',
                'value' => '',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'رقم الهاتف',
                'key' => 'phone_5',
                'value' => '',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'البريد الإلكتروني',
                'key' => 'email',
                'value' => 'Fq0Vp@example.com',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'رابط تطبيق Android',
                'key' => 'android_url',
                'value' => 'https://play.google.com/store/apps/details?id=com.maraya',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'رابط تطبيق iOS',
                'key' => 'ios_url',
                'value' => 'https://apps.apple.com/us/app/maraya/id1478000001',
                'input_type' => 'input',
            ],
            [
                'input_label' => 'وصف الفوتر العربي',
                'key' => 'footer_about_ar',
                'value' => 'footer about ar',
                'input_type' => 'textarea',
            ],
            [
                'input_label' => 'وصف الفوتر الانجليزي',
                'key' => 'footer_about_en',
                'value' => 'footer about en',
                'input_type' => 'textarea',
            ],
        ];
        MarayaSetting::insert($rows);
    }
}
