<?php

namespace Database\Seeders;

use App\Enum\PermissionActions;
use App\Models\Permission;
use App\Models\Role;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $routes = [];
        collect(Route::getRoutes())
            ->filter(
                fn ($r) => Str::startsWith($r->uri, 'admin') &&
                    ! Str::contains($r->uri, 'admin/dashboard') &&
                    ! Str::contains($r->uri, 'admin/login') &&
                    ! Str::contains($r->uri, 'admin/postLogin') &&
                    ! Str::contains($r->uri, 'admin/logout') &&
                    ! Str::contains($r->uri, 'admin/profile') &&
                    ! Str::contains($r->uri, 'admin/profile/updateProfile') &&
                    ! Str::contains($r->uri, 'admin/profile/updatePassword') &&
                    ! Str::contains($r->uri, 'admin/media/upload')
            )
            ->each(function ($route) use (&$routes) {
                [$_, $module, $action] = explode('.', $route->getName());
                $action = match ($action) {
                    'index' => PermissionActions::view,
                    'show' => PermissionActions::view,
                    'create' => PermissionActions::add,
                    'store' => PermissionActions::add,
                    'edit' => PermissionActions::edit,
                    'update' => PermissionActions::edit,
                    'ordering' => PermissionActions::edit,
                    'destroy' => PermissionActions::delete,
                    'delete' => PermissionActions::delete
                };
                if (isset($routes[$module])) {
                    $routes[$module][] = $action;
                } else {
                    $routes[$module] = [
                        $action,
                    ];
                }
            });
        $_routes = [];
        foreach ($routes as $module => $actions) {
            $_routes[$module] = array_unique($actions);
        }
        unset($routes);

        Permission::truncate();
        foreach ($_routes as $module => $actions) {
            foreach ($actions as $action) {
                Permission::create([
                    'module_name' => __("routes.$module", [], 'ar'),
                    'action' => $action,
                    'module' => $module,
                ]);
            }
        }

        $role = Role::updateOrCreate([
            'name_en' => 'Super Admin',
        ], [
            'name_ar' => 'Super Admin',
            'editable' => false,
        ]);

        $role->permissions()->sync(Permission::get()->pluck('id')->toArray());
    }
}
