<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\Role;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DigitalTrainingPermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $actions = [
            'view',
            'add',
            'edit',
            'delete',
        ];

        $role = Role::where('name_en', 'Super Admin')
            ->where('name_ar', 'Super Admin')
            ->where('editable', false)->first();
        foreach ($actions as $action) {
            $permission = Permission::create([
                'module_name' => 'محاضرات رقمية',
                'module' => 'digital_training',
                'action' => $action,
            ]);
            $role->permissions()->attach($permission->id);
        }
    }
}
