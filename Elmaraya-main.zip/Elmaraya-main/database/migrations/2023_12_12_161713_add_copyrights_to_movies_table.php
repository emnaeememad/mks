<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('movies', function (Blueprint $table) {
            $table->string('main_image_copyrights_ar')->nullable();
            $table->string('main_image_copyrights_en')->nullable();
            $table->string('thumb_image_copyrights_ar')->nullable();
            $table->string('thumb_image_copyrights_en')->nullable();
            $table->string('cover_copyrights_ar')->nullable();
            $table->string('cover_copyrights_en')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('movies', function (Blueprint $table) {
            $table->dropColumn([
                'main_image_copyrights_ar',
                'main_image_copyrights_en',
                'thumb_image_copyrights_ar',
                'thumb_image_copyrights_en',
                'cover_copyrights_ar',
                'cover_copyrights_en',
            ]);
        });
    }
};
