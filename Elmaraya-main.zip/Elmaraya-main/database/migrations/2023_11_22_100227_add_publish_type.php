<?php

use App\Enum\PublishType;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('blogs', function (Blueprint $table) {
            $table->enum('publish_type', PublishType::getTypes())->default(PublishType::all);
        });

        Schema::table('stories', function (Blueprint $table) {
            $table->enum('publish_type', PublishType::getTypes())->default(PublishType::all);
            $table->boolean('is_home_slider')->default(false);
        });

        Schema::table('nadaras', function (Blueprint $table) {
            $table->enum('publish_type', PublishType::getTypes())->default(PublishType::all);
        });

        Schema::table('workshops', function (Blueprint $table) {
            $table->enum('publish_type', PublishType::getTypes())->default(PublishType::all);
        });

        Schema::table('movies', function (Blueprint $table) {
            $table->enum('publish_type', PublishType::getTypes())->default(PublishType::all);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('blogs', function (Blueprint $table) {
            $table->dropColumn('publish_type');
        });

        Schema::table('stories', function (Blueprint $table) {
            $table->dropColumn('publish_type');
            $table->dropColumn('is_home_slider');
        });

        Schema::table('nadaras', function (Blueprint $table) {
            $table->dropColumn('publish_type');
        });

        Schema::table('workshops', function (Blueprint $table) {
            $table->dropColumn('publish_type');
        });

        Schema::table('movies', function (Blueprint $table) {
            $table->dropColumn('publish_type');
        });
    }
};
