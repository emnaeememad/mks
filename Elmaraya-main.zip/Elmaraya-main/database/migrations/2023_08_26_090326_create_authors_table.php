<?php

use App\Enum\AuthorTypes;
use App\Enum\Genders;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $genders = array_column(Genders::getGenders(), 'name_en');

        Schema::create('authors', function (Blueprint $table) use ($genders) {
            $table->bigIncrements('id');
            $table->string('slug_ar');
            $table->string('slug_en')->nullable();
            $table->string('name_ar');
            $table->string('name_en')->nullable();
            $table->string('photo');
            $table->enum('gender', $genders);
            $table->boolean('is_public')->default(false);
            $table->boolean('is_home')->default(false);
            $table->enum('type', AuthorTypes::getTypes())->default(AuthorTypes::individual);
            $table->softDeletes();
            $table->timestamps();
            $table->unique(['slug_ar', 'id'], 'slug_ar_id_unique');
            $table->unique(['slug_en', 'id'], 'slug_en_id_unique');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('authors');
    }
};
