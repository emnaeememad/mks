<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('digital_training_similars', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('digital_training_id');
            $table->foreign('digital_training_id')->references('id')->on('digital_trainings')->onDelete('cascade');
            $table->unsignedBigInteger('similar_id');
            $table->foreign('similar_id')->references('id')->on('digital_trainings')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('digital_training_similars');
    }
};
