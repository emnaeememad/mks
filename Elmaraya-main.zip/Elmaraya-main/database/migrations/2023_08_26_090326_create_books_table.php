<?php

use App\Enum\BookRequestType;
use App\Enum\PublishStatus;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('books', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('main_image');
            $table->string('slug_ar');
            $table->string('slug_en')->nullable();
            $table->string('name_ar');
            $table->string('name_en')->nullable();
            $table->double('hard_copy_price');
            $table->double('epob_price');
            $table->text('description_ar')->nullable();
            $table->text('description_en')->nullable();
            $table->string('amazon_link')->nullable();
            $table->integer('category_id');
            $table->integer('author_id');
            $table->integer('number_of_pages');
            $table->string('bar_code')->nullable();
            $table->string('file');
            $table->integer('total_soft_purchased')->default(0);
            $table->integer('total_hard_purchased')->default(0);
            $table->integer('total_views')->default(0);
            $table->integer('total_shares')->default(0);
            $table->enum('status', PublishStatus::getStatuses())->default(PublishStatus::draft);
            $table->string('reviewer', 250)->nullable()->comment('can be "book editor"');
            $table->boolean('is_home')->default(false);
            $table->boolean('is_featured')->default(false);
            $table->boolean('is_recommended')->default(false);
            $table->enum('request_type', BookRequestType::getTypes())->nullable();
            $table->softDeletes();
            $table->timestamps();
            $table->unique(['slug_ar', 'id'], 'slug_ar_id_unique');
            $table->unique(['slug_en', 'id'], 'slug_en_id_unique');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('books');
    }
};
