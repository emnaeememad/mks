<?php

use App\Enum\BlogModules;
use App\Enum\PublishStatus;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('blogs', function (Blueprint $table) {
            $table->increments('id');
            $table->string('cover', 250)->nullable();
            $table->string('main_image', 250)->nullable();
            $table->string('thumb_image', 250)->nullable();
            $table->string('slug_ar', 250);
            $table->string('slug_en', 250)->nullable();
            $table->string('title_ar', 250);
            $table->string('title_en', 250)->nullable();
            $table->text('brief_ar')->nullable();
            $table->text('brief_en')->nullable()->nullable();
            $table->longText('description_ar')->nullable();
            $table->longText('description_en')->nullable()->nullable();
            $table->integer('category_id')->nullable();
            $table->integer('author_id')->nullable();
            $table->integer('blog_order_home')->nullable();
            $table->integer('total_views')->default(0);
            $table->integer('total_shares')->default(0);
            $table->enum('status', PublishStatus::getStatuses())->default(PublishStatus::draft);
            $table->enum('module_type', BlogModules::getModules());
            $table->boolean('is_featured')->default(false);
            $table->boolean('is_home')->default(false);
            $table->boolean('is_recommended')->default(false);
            $table->boolean('is_home_slider')->default(false);
            $table->softDeletes();
            $table->timestamps();
            $table->unique(['slug_ar', 'id'], 'slug_ar_id_unique');
            $table->unique(['slug_en', 'id'], 'slug_en_id_unique');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('blogs');
    }
};
