<?php

use App\Enum\NadaraTypes;
use App\Enum\PublishStatus;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('nadaras', function (Blueprint $table) {
            $table->id();
            $table->string('cover', 250)->nullable();
            $table->string('main_image', 250)->nullable();
            $table->string('thumb_image', 250)->nullable();
            $table->string('video', 250)->nullable();
            $table->string('slug_ar', 250);
            $table->string('slug_en', 250)->nullable();
            $table->string('title_ar', 250);
            $table->string('title_en', 250)->nullable();
            $table->integer('category_id')->nullable();
            $table->integer('author_id')->nullable();
            $table->integer('total_views')->default(0);
            $table->integer('total_plays')->default(0);
            $table->integer('total_shares')->default(0);
            $table->enum('status', PublishStatus::getStatuses())->default(PublishStatus::draft);
            $table->enum('type', NadaraTypes::getTypes())->default(NadaraTypes::photos);
            $table->boolean('is_featured')->default(false);
            $table->boolean('is_home')->default(false);
            $table->boolean('is_recommended')->default(false);
            $table->boolean('is_home_slider')->default(false);
            $table->integer('video_duration')->default(0);
            $table->softDeletes();
            $table->timestamps();
            $table->unique(['slug_ar', 'id'], 'slug_ar_id_unique');
            $table->unique(['slug_en', 'id'], 'slug_en_id_unique');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('nadaras');
    }
};
