<?php

use App\Enum\PublishStatus;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('stories', function (Blueprint $table) {
            $table->increments('id');
            $table->string('cover', 250)->nullable();
            $table->string('main_image', 250)->nullable();
            $table->string('thumb_image', 250)->nullable();
            $table->string('slug_ar', 250);
            $table->string('slug_en', 250)->nullable();
            $table->string('title_ar', 250);
            $table->string('title_en', 250)->nullable();
            $table->string('file', 250)->nullable();
            $table->string('file_length', 250)->nullable();
            $table->integer('category_id')->nullable();
            $table->integer('author_id')->nullable();
            $table->integer('total_plays')->default(0);
            $table->integer('total_shares')->default(0);
            $table->enum('status', PublishStatus::getStatuses())->default(PublishStatus::draft);
            $table->boolean('is_home')->default(false);
            $table->boolean('is_featured')->default(false);
            $table->boolean('is_recommended')->default(false);
            $table->softDeletes();
            $table->timestamps();
            $table->unique(['slug_ar', 'id'], 'slug_ar_id_unique');
            $table->unique(['slug_en', 'id'], 'slug_en_id_unique');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('stories');
    }
};
