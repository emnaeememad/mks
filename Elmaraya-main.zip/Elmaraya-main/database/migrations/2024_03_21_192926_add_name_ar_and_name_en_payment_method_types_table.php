<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('payment_method_types', function (Blueprint $table) {
            $table->string('name_ar')->nullable(); // Change the data type as needed
            $table->string('name_en')->nullable(); // Change the data type as needed

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('payment_method_types', function (Blueprint $table) {
            $table->dropColumn('name_ar');
            $table->dropColumn('name_en');

        });
    }
};
