<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('workshops', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('cover', 250);
            $table->string('main_image', 250)->nullable();
            $table->string('thumb_image', 250)->nullable();
            $table->integer('author_id')->nullable();
            $table->date('start_date');
            $table->date('end_date');
            $table->string('slug_ar', 250);
            $table->string('slug_en', 250)->nullable();
            $table->string('title_ar', 250);
            $table->string('title_en', 250)->nullable();
            $table->text('brief_ar')->nullable();
            $table->text('brief_en')->nullable();
            $table->longText('description_ar')->nullable();
            $table->longText('description_en')->nullable();
            $table->boolean('is_bookable')->default(false);
            $table->boolean('is_home')->default(false);
            $table->boolean('is_recommended')->default(false);
            $table->boolean('is_current')->default(false);
            $table->softDeletes();
            $table->timestamps();
            $table->unique(['slug_ar', 'id'], 'slug_ar_id_unique');
            $table->unique(['slug_en', 'id'], 'slug_en_id_unique');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('workshops');
    }
};
