<?php

use App\Enum\PublishStatus;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('maraya_books', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('slug_ar', 250);
            $table->string('slug_en', 250)->nullable();
            $table->string('title_ar', 250);
            $table->string('title_en', 250)->nullable();
            $table->string('main_image');
            $table->string('file');
            $table->integer('category_id')->nullable();
            $table->integer('author_id')->nullable();
            $table->integer('total_downloads')->default(0);
            $table->integer('total_views')->default(0);
            $table->integer('total_shares')->default(0);
            $table->enum('status', PublishStatus::getStatuses())->default(PublishStatus::draft);
            $table->softDeletes();
            $table->timestamps();
            $table->unique(['slug_ar', 'id'], 'slug_ar_id_unique');
            $table->unique(['slug_en', 'id'], 'slug_en_id_unique');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('maraya_books');
    }
};
