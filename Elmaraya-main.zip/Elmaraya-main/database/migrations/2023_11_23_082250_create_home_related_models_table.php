<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('home_related_models', function (Blueprint $table) {
            $table->id();
            $table->string('relatedable_type');
            $table->unsignedBigInteger('relatedable_id');
            $table->string('section_name');
            $table->string('section_key');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('home_related_models');
    }
};
