<?php

namespace App\Integrations\Payments;

use App\Contracts\Payment;
use App\Enum\PaymentSlugs;
use App\Exceptions\UnknownPaymentId;
use App\Integrations\Payments\Paymob\Paymob;
use App\Models\Customer;
use App\Models\PaymentMethod;

class PaymentFactory
{
    public static function createPayment(
        Customer $customer,
        float $totalAmountEgp,
        int $id
    ): Payment {
        $paymentMethod = PaymentMethod::findOrFail($id);
        switch ($paymentMethod->slug) {
            case PaymentSlugs::paymobVisa:
                return new Paymob($customer, $totalAmountEgp);
                break;
        }
        throw new UnknownPaymentId;
    }
}
