<?php

namespace App\Integrations\Payments\Paymob;

use App\Contracts\PayByWebPage;
use App\Contracts\Payment;
use App\Exceptions\PaymentNotProcessable;
use App\Models\Customer;

class Paymob implements PayByWebPage, Payment
{
    private string $gatewayTrackingNumber;

    private string $payToken;

    public function __construct(
        private Customer $customer,
        private float $totalAmountEgp
    ) {
    }

    public function payByWebPage(): PayByWebPage
    {
        $token = (new Auth)();
        $orderId = (new Order($token, $this->totalAmountEgp))();
        $paymentRequest = (new PaymentRequest($token, $this->totalAmountEgp))
            ->setCustomer($this->customer)
            ->setOrderId($orderId);
        $this->payToken = $paymentRequest();

        $this->gatewayTrackingNumber = "$orderId";

        return $this;
    }

    public function gatewayTrackingNumber(): string
    {
        if (! isset($this->gatewayTrackingNumber)) {
            throw new PaymentNotProcessable;
        }

        return $this->gatewayTrackingNumber;
    }

    public function getRedirectUrl(): string
    {
        return config('paymob.iframe_link').$this->payToken;
    }

    public function getSuccessUrl(): string
    {
        return route('api.callbacks.payment-success');
    }

    public function getFailureUrl(): string
    {
        return route('api.callbacks.payment-failure');
    }
}
