<?php

namespace App\Integrations\Payments\Paymob;

use App\Exceptions\PaymentNotProcessable;
use Error;
use Exception;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class Order
{
    const ENDPOINT = '/ecommerce/orders';

    const LOG_CHANNEL = 'paymob';

    public function __construct(
        private string $token,
        private float $totalAmountEgp
    ) {
    }

    public function __invoke(): int
    {
        $apiUrl = config('paymob.api_base_url').self::ENDPOINT;

        try {
            $body = [
                'auth_token' => $this->token,
                'delivery_needed' => false,
                'amount_cents' => $this->totalAmountEgp * 100,
                'items' => [], // Souhoula and GET_GO methods must send items
            ];
            $response = Http::asJson()->post($apiUrl, $body);
            Log::channel(self::LOG_CHANNEL)->info('Order-Service::response', [
                'url' => $apiUrl,
                'request' => $body,
                'response' => $response,
            ]);
            $orderId = $response->json('id');
        } catch (Exception|Error $e) {
            Log::channel(self::LOG_CHANNEL)->info('Order-Service::Exception', [
                'url' => $apiUrl,
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);
        }

        if (! $orderId) {
            throw new PaymentNotProcessable;
        }

        return (int) $orderId;
    }
}
