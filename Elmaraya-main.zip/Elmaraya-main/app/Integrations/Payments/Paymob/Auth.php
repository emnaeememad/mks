<?php

namespace App\Integrations\Payments\Paymob;

use App\Exceptions\PaymentNotProcessable;
use Error;
use Exception;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class Auth
{
    const ENDPOINT = '/auth/tokens';

    const LOG_CHANNEL = 'paymob';

    public function __invoke(): string
    {
        $apiUrl = config('paymob.api_base_url').self::ENDPOINT;
        $apiKey = config('paymob.api_key');

        try {
            $body = ['api_key' => $apiKey];
            $response = Http::asJson()->post($apiUrl, $body);
            Log::channel(self::LOG_CHANNEL)->info('Auth-Service::response', [
                'url' => $apiUrl,
                'request' => $body,
                'response' => $response,
            ]);
            $token = $response->json('token');
        } catch (Exception|Error $e) {
            Log::channel(self::LOG_CHANNEL)->info('Auth-Service::Exception', [
                'url' => $apiUrl,
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);
        }

        if (! $token) {
            throw new PaymentNotProcessable;
        }

        return $token;
    }
}
