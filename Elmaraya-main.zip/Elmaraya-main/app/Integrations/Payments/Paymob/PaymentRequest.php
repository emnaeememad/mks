<?php

namespace App\Integrations\Payments\Paymob;

use App\Exceptions\PaymentNotProcessable;
use App\Models\Customer;
use Error;
use Exception;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class PaymentRequest
{
    const ENDPOINT = '/acceptance/payment_keys';

    const LOG_CHANNEL = 'paymob';

    private Customer $customer;

    private int $orderId;

    public function __construct(
        private string $token,
        private float $totalAmountEgp,
    ) {
    }

    public function setCustomer(Customer $customer): self
    {
        $this->customer = $customer;

        return $this;
    }

    public function setOrderId(int $orderId): self
    {
        $this->orderId = $orderId;

        return $this;
    }

    public function __invoke(): string
    {
        if (! isset($this->customer)) {
            throw new Exception('Set customer first');
        }
        if (! isset($this->orderId)) {
            throw new Exception('Set order id first');
        }

        $apiUrl = config('paymob.api_base_url').self::ENDPOINT;

        try {
            $nameTokens = collect(explode(' ', $this->customer->name));

            $body = [
                'auth_token' => $this->token,
                'amount_cents' => $this->totalAmountEgp * 100,
                'expiration' => 3600, // an hour
                'order_id' => $this->orderId,
                'currency' => 'USD', // EGP
                'integration_id' => config('paymob.channel_id'),
                'billing_data' => [
                    'apartment' => 'NA',
                    'email' => $this->customer->email,
                    'floor' => 'NA',
                    'first_name' => $nameTokens->pop() ?? '',
                    'street' => 'NA',
                    'building' => 'NA',
                    'phone_number' => $this->customer->phone_number,
                    'shipping_method' => 'NA',
                    'postal_code' => 'NA',
                    'city' => 'NA',
                    'country' => 'NA',
                    'last_name' => $nameTokens->implode(' '),
                    'state' => 'NA',
                ],
                'lock_order_when_paid' => true,
            ];
            $response = Http::asJson()->post($apiUrl, $body);
            Log::channel(self::LOG_CHANNEL)->info('Payment-Request-Service::response', [
                'url' => $apiUrl,
                'request' => $body,
                'response' => $response,
            ]);
            $token = $response->json('token');
        } catch (Exception|Error $e) {
            Log::channel(self::LOG_CHANNEL)->info('Payment-Request-Service::Exception', [
                'url' => $apiUrl,
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);
        }

        if (! $token) {
            throw new PaymentNotProcessable;
        }

        return $token;
    }
}
