<?php

namespace App\Integrations\Sms;

class SmsFactory
{
    public static function createSms()
    {
        // to be implemented...
    }
}
