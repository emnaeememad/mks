<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;
use Symfony\Component\HttpFoundation\Response;

class IsAdminCan
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, $module, $action): Response
    {
        $adminHasAccess = $request->user('admins')
            ->role()
            ->whereHas(
                'permissions',
                fn ($q) => $q->where([
                    'module' => $module,
                    'action' => $action,
                ])
            )
            ->exists();

        if ($adminHasAccess) {
            return $next($request);
        }

        Alert::error('خطأ', 'ليس لديك صلاحية لتنقيذ تلك العملية');

        return redirect(route('admin.dashboard'));
    }
}
