<?php

namespace App\Http\Middleware;

use Carbon\Carbon;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Symfony\Component\HttpFoundation\Response;

class DetectLang
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $allowedLanguages = ['ar', 'en'];
        $lang = '';
        $ROUTE_PARAMS = Route::current()->parameters();

        if ($request->has('lang')) {
            $lang = $request->lang;
        } elseif (isset($ROUTE_PARAMS['lang'])) {
            $lang = $ROUTE_PARAMS['lang'];
        } elseif (session()->has('lang')) {
            $lang = session()->get('lang');
        }

        $lang = in_array($lang, $allowedLanguages) ? $lang : $allowedLanguages[0];
        // if the url does not contain the language parameter
        // back to the default language
        if (! isset($ROUTE_PARAMS['lang']) && is_null($request->segment(1))) {
            $lang = $allowedLanguages[1];
        } elseif (isset($ROUTE_PARAMS['lang']) && $ROUTE_PARAMS['lang'] == 'en' && is_null($request->segment(2))) {
            return redirect(url('/'), 301);
        }

        app()->setLocale($lang);
        session()->put('locale', $lang);
        Carbon::setlocale($lang);
        app()->setLocale('ar'); // remove when active both language
        session()->put('locale', 'ar'); // remove when active both language
        Carbon::setlocale('ar'); // remove when active both language

        return $next($request);
    }
}
