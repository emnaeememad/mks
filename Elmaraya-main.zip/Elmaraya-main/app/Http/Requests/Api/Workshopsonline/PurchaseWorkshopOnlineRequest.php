<?php

namespace App\Http\Requests\Api\Workshopsonline;

use App\Http\Requests\Api\ApiBaseRequest;

class PurchaseWorkshopOnlineRequest extends ApiBaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('sanctum')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            // 'payment_id' => 'required|exists:payment_methods,id',
            'payment_type_id' => 'required|exists:payment_method_types,id',
        ];
    }

    public function attributes()
    {
        return [
            // 'payment_id' => __('attributes.payment_method'),
            'payment_type_id' => __('attributes.payment_method_types'),
        ];
    }
}
