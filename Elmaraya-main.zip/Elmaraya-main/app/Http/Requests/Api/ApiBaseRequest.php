<?php

namespace App\Http\Requests\Api;

use App\Exceptions\ValidationResponseException;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;

class ApiBaseRequest extends FormRequest
{
    protected function failedValidation(Validator $validator)
    {
        $_errors = [];
        $errors = $validator->errors()->messages();
        foreach ($errors as $input => $inputErrors) {
            $_errors[$input] = implode(',', $inputErrors);
        }
        throw new ValidationResponseException($_errors, __('attributes.validation-message'));
    }
}
