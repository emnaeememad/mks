<?php

namespace App\Http\Requests\Api\Profile;

use App\Http\Requests\Api\ApiBaseRequest;

class ChangePasswordRequest extends ApiBaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('sanctum')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'old_password' => 'required|min:6|max:100',
            'password' => 'required|confirmed|min:6|max:100',
        ];
    }

    public function attributes()
    {
        return [
            'old_password' => __('attributes.old_password'),
            'password' => __('attributes.password'),
        ];
    }
}
