<?php

namespace App\Http\Requests\Api\Profile;

use App\Http\Requests\Api\ApiBaseRequest;
use App\Rules\PhoneNumber;

class EditProfileRequest extends ApiBaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('sanctum')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|min:3|max:100|string',
            'email' => 'required|email|max:200|unique:customers,email,'.auth('sanctum')->id().',id',
            'phone_number' => [
                'required',
                'unique:customers,phone_number,'.auth('sanctum')->id().',id',
                new PhoneNumber,
            ],
        ];
    }

    public function attributes()
    {
        return [
            'name' => __('attributes.name'),
            'email' => __('attributes.email'),
            'phone_number' => __('attributes.phone_number'),
        ];
    }
}
