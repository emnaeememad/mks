<?php

namespace App\Http\Requests\Api\Auth;

use App\Http\Requests\Api\ApiBaseRequest;
use App\Rules\PhoneNumber;

class ResendVerificationRequest extends ApiBaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function rules(): array
    {
        return [
            'email' => 'nullable|email|exists:customers,email',
            'phone_number' => [
                'required',
                'exists:customers,phone_number',
                new PhoneNumber,
            ],
        ];
    }

    public function attributes()
    {
        return [
            'email' => __('attributes.email'),
            'phone_number' => __('attributes.phone_number'),
        ];
    }
}
