<?php

namespace App\Http\Requests\Api\Auth;

use App\Http\Requests\Api\ApiBaseRequest;
use App\Rules\Number;
use App\Rules\PhoneNumber;

class VerifyRequest extends ApiBaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'email' => 'required|email|exists:customers,email',
            'phone_number' => [
                'required',
                'exists:customers,phone_number',
                new PhoneNumber,
            ],
            'code' => [
                'required',
                'max:4',
                new Number,
            ],
        ];
    }

    public function attributes()
    {
        return [
            'email' => __('attributes.email'),
            'phone_number' => __('attributes.phone_number'),
            'code' => __('attributes.verify-code'),
        ];
    }
}
