<?php

namespace App\Http\Requests\Api\Auth;

use App\Http\Requests\Api\ApiBaseRequest;
use App\Rules\PhoneNumber;

class LoginRequest extends ApiBaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'phone_number' => ['required', new PhoneNumber],
            'password' => 'required|max:200',
        ];
    }

    public function attributes()
    {
        return [
            'phone_number' => __('attributes.phone_number'),
            'password' => __('attributes.password'),
        ];
    }
}
