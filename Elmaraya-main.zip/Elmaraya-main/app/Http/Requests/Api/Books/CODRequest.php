<?php

namespace App\Http\Requests\Api\Books;

use App\Rules\PhoneNumber;
use App\Http\Requests\Api\ApiBaseRequest;

class CODRequest extends ApiBaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('sanctum')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'first_name' => 'required|min:3|max:200|string',
            'last_name' => 'required|min:3|max:200|string',
            'address' => 'required|min:3|max:750',
            'phone_number' => ['required', new PhoneNumber],
            'email' => 'required|email|max:200',
            'shipping_id' => 'required|exists:shipping_locations,id'
        ];
    }

    public function attributes()
    {
        return [
            'first_name' => __('attributes.first_name'),
            'last_name' => __('attributes.last_name'),
            'address' => __('attributes.address'),
            'phone_number' => __('attributes.phone_number'),
            'email' => __('attributes.email'),
            'shipping_id' => __('attributes.shipping_region')
        ];
    }
}
