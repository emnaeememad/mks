<?php

namespace App\Http\Requests\LandingPage\ContactUs;

use App\Rules\PhoneNumber;
use Illuminate\Foundation\Http\FormRequest;

class ContactUsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth()->guest();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'first_name' => 'required|min:3|max:100|string',
            'last_name' => 'required|min:3|max:100|string',
            'email' => 'required|email|max:200',
            'phone_number' => ['required', new PhoneNumber],
            'message' => 'required|min:3|max:750|string',
        ];
    }

    public function attributes()
    {
        return [
            'first_name' => __('attributes.first_name'),
            'last_name' => __('attributes.last_name'),
            'email' => __('attributes.email'),
            'phone_number' => __('attributes.phone_number'),
            'message' => __('attributes.message'),
        ];
    }
}
