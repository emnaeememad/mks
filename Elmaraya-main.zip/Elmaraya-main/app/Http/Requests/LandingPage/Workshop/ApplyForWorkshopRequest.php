<?php

namespace App\Http\Requests\LandingPage\Workshop;

use App\Rules\PhoneNumber;
use Illuminate\Foundation\Http\FormRequest;

class ApplyForWorkshopRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth()->guest();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|min:3|max:100|string',
            'age' => 'required|integer|max:100',
            'phone_number' => ['required', new PhoneNumber],
            'email' => 'required|email|max:200',
            'address' => 'required|min:3|max:750|string',
            'why_join_us' => 'required|min:3|max:750|string',
            'files' => 'nullable|array|min:1',
            'files.*' => 'required|mimes:pdf,doc,docx,png,jpg,jpeg',
        ];
    }

    public function attributes()
    {
        return [
            'name' => __('attributes.name'),
            'age' => __('attributes.age'),
            'phone_number' => __('attributes.phone_number'),
            'email' => __('attributes.email'),
            'address' => __('attributes.address'),
            'why_join_us' => __('attributes.why_join_us'),
            'files' => __('attributes.attachments'),
            'files.*' => __('attributes.attachment'),
        ];
    }
}
