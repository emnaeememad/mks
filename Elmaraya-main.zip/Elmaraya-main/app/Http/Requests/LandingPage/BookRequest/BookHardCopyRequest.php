<?php

namespace App\Http\Requests\LandingPage\BookRequest;

use App\Rules\PhoneNumber;
use Illuminate\Foundation\Http\FormRequest;

class BookHardCopyRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth()->guest();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'book_id' => 'required|exists:books,id',
            'first_name' => 'required|min:3|max:100|string',
            'last_name' => 'required|min:3|max:100|string',
            'address' => 'required|min:3|max:750|string',
            'phone_number' => ['required', new PhoneNumber],
            'email' => 'required|email|max:200',
        ];
    }

    public function attributes()
    {
        return [
            'first_name' => __('attributes.first_name'),
            'last_name' => __('attributes.last_name'),
            'address' => __('attributes.address'),
            'email' => __('attributes.email'),
            'phone_number' => __('attributes.phone_number'),
        ];
    }
}
