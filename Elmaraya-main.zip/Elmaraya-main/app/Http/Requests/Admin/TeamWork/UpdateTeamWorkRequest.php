<?php

namespace App\Http\Requests\Admin\TeamWork;

use Illuminate\Foundation\Http\FormRequest;

class UpdateTeamWorkRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'title_ar' => 'required|min:3|max:200',
            'title_en' => 'required|min:3|max:200',
            'name' => 'required|min:3|max:200',
            'image' => 'nullable|image',
        ];
    }

    public function attributes()
    {
        return [
            'title_ar' => 'وظيفة العضو عربي',
            'title_en' => 'وظيفة العضو إنجليزي',
            'name' => 'إسم العضو',
            'image' => 'الصورة الشخصية للعضو',
        ];
    }
}
