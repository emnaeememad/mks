<?php

namespace App\Http\Requests\Admin\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UpdatePasswordRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'old_password' => 'required|string',
            'password' => [
                'required',
                'string',
                'min:8',
                'confirmed',
                'max:200',
                //                'regex:/[a-z]/',      // must contain at least one lowercase letter
                //                'regex:/[A-Z]/',      // must contain at least one uppercase letter
                //                'regex:/[0-9]/',      // must contain at least one digit
                //                'regex:/[@$!%*#?&]/', // must contain a special character
            ],
        ];
    }

    public function attributes()
    {
        return [
            'old_password' => 'كلمة المرور القديمة',
            'password' => 'كلمة المرور',
        ];
    }
}
