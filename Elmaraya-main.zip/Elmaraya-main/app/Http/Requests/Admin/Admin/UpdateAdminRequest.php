<?php

namespace App\Http\Requests\Admin\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UpdateAdminRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|min:3|max:250',
            'email' => "required|unique:admins,email,{$this->admin->id},id|email|max:250",
            'phone_number' => 'nullable|min:8|max:11|regex:/^[0-9]+$/',
            'photo' => 'nullable|sometimes|image',
            'role_id' => 'required|exists:roles,id',
            'password' => 'nullable|sometimes|min:8|max:200',
        ];
    }

    public function attributes()
    {
        return [
            'name' => 'الإسم',
            'email' => 'البريد الإلكتروني',
            'phone_number' => 'رقم الهاتف',
            'photo' => 'الصورة الشخصية',
            'role_id' => 'الصلاحية',
            'password' => 'كلمة المرور',
        ];
    }
}
