<?php

namespace App\Http\Requests\Admin\Author;

use App\Enum\Genders;
use App\Enum\WritingTypes;
use Illuminate\Foundation\Http\FormRequest;

class UpdateAuthorRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $genders = array_column(Genders::getGenders(), 'name_en');

        return [
            'name_ar' => 'required|string|min:3|max:255',
            'name_en' => 'required|string|min:3|max:255',
            'photo' => 'nullable|image',
            'gender' => 'required|in:'.implode(',', $genders),
            'is_public' => 'required|in:0,1',
            'is_home' => 'required|in:0,1',
            'writing_type' => 'required|in:'.implode(',', WritingTypes::getTypes()),
            'is_published' => 'required|in:0,1',
        ];
    }
}
