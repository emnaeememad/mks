<?php

namespace App\Http\Requests\Admin\Story;

use App\Enum\PublishStatus;
use App\Enum\PublishType;
use Illuminate\Foundation\Http\FormRequest;

class StoreStoryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'cover' => 'nullable|image',
            'main_image' => 'nullable|image',
            'thumb_image' => 'nullable|image',
            'title_ar' => 'required|min:5|max:200',
            'title_en' => 'required|min:5|max:200',
			'description_ar' => 'nullable',
            'description_en' => 'nullable',
            'category_id' => 'nullable|exists:categories,id',
            'author_id' => 'required|exists:authors,id',
            'status' => 'required|in:'.implode(',', PublishStatus::getStatuses()),
            'is_home' => 'required|in:1,0',
            'is_featured' => 'required|in:1,0',
            'is_recommended' => 'required|in:1,0',
            'file' => 'required|mimes:mp3',
            'hours' => 'required|integer|min:0|max:23',
            'minutes' => 'required|integer|min:0|max:59',
            'seconds' => 'required|integer|min:0|max:59',
            'post_date' => 'required|date',
            'publish_type' => 'required|in:'.implode(',', PublishType::getTypes()),
            'is_home_slider' => 'required|in:1,0',
            'main_image_copyrights_ar' => 'nullable|string|min:3|max:200',
            'main_image_copyrights_en' => 'nullable|string|min:3|max:200',
            'thumb_image_copyrights_ar' => 'nullable|string|min:3|max:200',
            'thumb_image_copyrights_en' => 'nullable|string|min:3|max:200',
            'cover_copyrights_ar' => 'nullable|string|min:3|max:200',
            'cover_copyrights_en' => 'nullable|string|min:3|max:200',
            'soundcloud_url' => 'nullable|url',
            'anghami_url' => 'nullable|url',
            'spotify_url' => 'nullable|url',
        ];
    }

    public function attributes()
    {
        return [
            'cover' => 'صورة الغلاف',
            'main_image' => 'الصورة الرئيسية',
            'thumb_image' => 'الصورة المصغرة',
            'title_ar' => 'العنوان عربي',
            'title_en' => 'العنوان إنجليزي',
            'category_id' => 'تابع لقسم',
            'author_id' => 'كتب بواسطة',
            'status' => 'حالة النشر',
            'description_ar' => 'الوصف الكامل عربي',
            'description_en' => 'الوصف الكامل إنجليزي',			
            'is_home' => 'تظهر في الصفحة الرئيسية',
            'is_featured' => 'حكاية رئيسية',
            'is_recommended' => 'تظهر كمقترح',
            'file' => 'الملف الصوتي',
            'hours' => 'الساعات',
            'minutes' => 'الدقائق',
            'seconds' => 'الثواني',
            'post_date' => 'تاريخ النشر',
            'publish_type' => 'نوع النشر',
            'is_home_slider' => 'تظهر في الصفحة الرئيسية',
            'main_image_copyrights_ar' => 'حقوق نشر الصورة',
            'main_image_copyrights_en' => 'حقوق نشر الصورة',
            'thumb_image_copyrights_ar' => 'حقوق نشر الصورة',
            'thumb_image_copyrights_en' => 'حقوق نشر الصورة',
            'cover_copyrights_ar' => 'حقوق نشر الصورة',
            'cover_copyrights_en' => 'حقوق نشر الصورة',
            'soundcloud_url' => 'رابط سوندكود',
            'anghami_url' => 'رابط انغامي',
            'spotify_url' => 'رابط سبوتفايفي',
        ];
    }

    public function messages()
    {
        return [
            'status.in' => 'لابد ان تكون حالة النشر من الآتي: (قيد المراجعة, تم النشر او تم الأرشفة)',
            'is_home.in' => 'لابد ان تكون قيمة (تظهر في الصفحة الرئيسية) تعم او لا',
            'is_featured.in' => 'لابد ان تكون قيمة (حكاية رئيسية) تعم او لا',
            'is_recommended.in' => 'لابد ان تكون قيمة (تظهر كمقترح) تعم او لا',
            'publish_type.in' => 'لابد ان تكون نوع النشر من الآتي: (الكل، الموبايل، الويب)',
            'is_home_slider.in' => 'لابد ان تكون قيمة (تظهر في الصفحة الرئيسية) تعم او لا',
        ];
    }
}
