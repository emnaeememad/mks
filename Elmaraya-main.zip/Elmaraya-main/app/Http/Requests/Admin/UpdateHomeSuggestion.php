<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UpdateHomeSuggestion extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth()->guard('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'blog_1' => 'required|integer|exists:blogs,id',
            'blog_2' => 'required|integer|exists:blogs,id',
            'blog_3' => 'required|integer|exists:blogs,id',
            'blog_4' => 'required|integer|exists:blogs,id',
            'blog_5' => 'required|integer|exists:blogs,id',
            'blog_6' => 'required|integer|exists:blogs,id',
            'author' => 'required|integer|exists:authors,id',
            'author1' => 'required|integer|exists:authors,id',
            'author2' => 'required|integer|exists:authors,id',
            'author3' => 'required|integer|exists:authors,id',
            'author4' => 'required|integer|exists:authors,id',
            'author5' => 'required|integer|exists:authors,id',
            'author6' => 'required|integer|exists:authors,id',
            'blog_7' => 'required|integer|exists:blogs,id',
            'story' => 'required|integer|exists:stories,id',
            'nadara' => 'required|integer|exists:nadaras,id',
            'signing_parties' => 'required|integer|exists:blogs,id',
            'book2' => 'required|integer|exists:books,id',
            'book3' => 'required|integer|exists:books,id',
            'seminars' => 'required|integer|exists:blogs,id',
            'book4' => 'required|integer|exists:books,id',
        ];
    }

    public function attributes()
    {
        return [
            'blog_1' => 'المدونة',
            'blog_2' => 'المدونة',
            'blog_3' => 'المدونة',
            'blog_4' => 'المدونة',
            'blog_5' => 'المدونة',
            'blog_6' => 'المدونة',
            'author' => 'الكاتب',
            'author1' => 'الكاتب',
            'author2' => 'الكاتب',
            'author3' => 'الكاتب',
            'author4' => 'الكاتب',
            'author5' => 'الكاتب',
            'author6' => 'الكاتب',
            'blog_7' => 'المدونة',
            'story' => 'الحكاية',
            'nadara' => 'النضارة',
        ];
    }
}
