<?php

namespace App\Http\Requests\Admin\WorkshopOnline;

use App\Enum\PublishType;
use Illuminate\Foundation\Http\FormRequest;

class UpdateWorkshopOnlineRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'title' => 'required|min:3|max:200',
            'description' => 'required', 
            'availability_start_date' => 'nullable|date',
            'availability_end_date' => 'nullable|date|after_or_equal:availability_start_date',
             'author_id' => 'required|exists:authors,id',

        ];
    }

    public function attributes()
    {
        return [ 
            'title' => 'العنوان عربي',
            'title_en' => 'العنوان إنجليزي',
            'availability_start_date' => 'تاريخ بدايةالفتره المجانيه',
            'availability_end_date' => 'تاريخ نهاية التدريب الفتره المجانيه',
            'author_id' => 'كتب بواسطة', 
            'description' => 'الوصف الكامل عربي', 
        ];
    }
}
