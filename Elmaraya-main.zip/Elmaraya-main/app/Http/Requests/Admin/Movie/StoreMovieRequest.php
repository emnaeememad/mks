<?php

namespace App\Http\Requests\Admin\Movie;

use App\Enum\PublishStatus;
use App\Enum\PublishType;
use Illuminate\Foundation\Http\FormRequest;

class StoreMovieRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'cover' => 'required|image',
            'main_image' => 'required|image',
            'thumb_image' => 'required|image',
            'name_ar' => 'required|min:5|max:200',
            'name_en' => 'required|min:5|max:200',
            'brief_ar' => 'required|min:5|max:750',
            'brief_en' => 'nullable|min:5|max:750',
            'description_ar' => 'required',
            'description_en' => 'nullable',
            'status' => 'required|in:'.implode(',', PublishStatus::getStatuses()),
            'is_home' => 'required|in:1,0',
            'is_featured' => 'required|in:1,0',
            'files' => 'nullable|array|min:1',
            'files.*' => 'required|image',
            'post_date' => 'required|date',
            'publish_type' => 'required|in:'.implode(',', PublishType::getTypes()),
            'videos' => 'nullable|array|min:1',
            'videos.*' => 'required|file|mimes:mp4,ogx,oga,ogv,ogg,webm',
            'main_image_copyrights_ar' => 'nullable|string|min:3|max:200',
            'main_image_copyrights_en' => 'nullable|string|min:3|max:200',
            'thumb_image_copyrights_ar' => 'nullable|string|min:3|max:200',
            'thumb_image_copyrights_en' => 'nullable|string|min:3|max:200',
            'cover_copyrights_ar' => 'nullable|string|min:3|max:200',
            'cover_copyrights_en' => 'nullable|string|min:3|max:200',
            // 'categories.*' => 'required',
        ];
    }

    public function attributes()
    {
        return [
            'cover' => 'صورة الغلاف',
            'main_image' => 'الصورة الرئيسية',
            'thumb_image' => 'الصورة المصغرة',
            'name_ar' => 'العنوان عربي',
            'name_en' => 'العنوان إنجليزي',
            'brief_ar' => 'الوصف المصغر عربي',
            'brief_en' => 'الوصف المصغر إنجليزي',
            'description_ar' => 'الوصف الكامل عربي',
            'description_en' => 'الوصف الكامل إنجليزي',
            'status' => 'حالة النشر',
            'is_home' => ' في الصفحة الرئيسية',
            'is_featured' => ' رئيسية',
            'files.*' => 'الملفات',
            // 'categories.*' => 'القسم',
            'post_date' => 'تاريخ النشر',
            'publish_type' => 'نوع النشر',
            'videos.*' => 'الفيديوهات',
            'main_image_copyrights_ar' => 'حقوق نشر الصورة',
            'main_image_copyrights_en' => 'حقوق نشر الصورة',
            'thumb_image_copyrights_ar' => 'حقوق نشر الصورة',
            'thumb_image_copyrights_en' => 'حقوق نشر الصورة',
            'cover_copyrights_ar' => 'حقوق نشر الصورة',
            'cover_copyrights_en' => 'حقوق نشر الصورة',
        ];
    }

    public function messages()
    {
        return [
            'status.in' => 'لابد ان تكون حالة النشر من الآتي: (قيد المراجعة, تم النشر او تم الأرشفة)',
            'is_home.in' => 'لابد ان تكون قيمة (في الصفحة الرئيسية) تعم او لا',
            'is_featured.in' => 'لابد ان تكون قيمة (رئيسية) تعم او لا',
            'publish_type.in' => 'لابد ان تكون قيمة (نوع النشر) (الكل، الموبايل، الويب)',
            'files.*.image' => 'يجب ان يكون الملف صورة',
            'files.*.max' => 'يجب ان يكون الملف لا يزيد عن 2 ميجا',
            'videos.*.mimes' => 'يجب ان يكون الفيديو من نوع (mp4, ogx, oga, ogv, ogg, webm)',
            // 'categories.*' => 'الحقل قسم مطلوب.',
         ];
    }
}
