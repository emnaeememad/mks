<?php

namespace App\Http\Requests\Admin\Nadara;

use App\Enum\NadaraTypes;
use App\Enum\PublishStatus;
use App\Enum\PublishType;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreNadaraRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'cover' => 'nullable|image',
            'main_image' => 'nullable|image',
            'thumb_image' => 'nullable|image',
            'title_ar' => 'required|min:5|max:200',
            'title_en' => 'required|min:5|max:200',
            'description_ar' => 'nullable',
            'description_en' => 'nullable',
            'category_id' => 'required|exists:categories,id',
            'author_id' => 'required|exists:authors,id',
            'status' => 'required|in:'.implode(',', PublishStatus::getStatuses()),
            'is_home' => 'required|in:1,0',
            'is_featured' => 'required|in:1,0',
            'featured_group' => 'required|in:1,0',
            'is_recommended' => 'required|in:1,0',
            'is_home_slider' => 'required|in:1,0',
            'video' => 'nullable|file|mimes:mp4,webm,avi|max:40096',
            'youtube_link' => 'nullable|string|url',
            'type' => 'required|in:'.implode(',', NadaraTypes::getTypes()),
            'files' => 'nullable|array|min:1',
            'files.*' => 'required|image',
            'video_duration' => 'required_if:type,reels|numeric|min:1',
            'post_date' => 'required|date',
            'publish_type' => 'required|in:'.implode(',', PublishType::getTypes()),
            'main_image_copyrights_ar' => 'nullable|string|min:3|max:200',
            'main_image_copyrights_en' => 'nullable|string|min:3|max:200',
            'thumb_image_copyrights_ar' => 'nullable|string|min:3|max:200',
            'thumb_image_copyrights_en' => 'nullable|string|min:3|max:200',
            'cover_copyrights_ar' => 'nullable|string|min:3|max:200',
            'cover_copyrights_en' => 'nullable|string|min:3|max:200',
        ];
    }

    public function attributes()
    {
        return [
            'cover' => 'صورة الغلاف',
            'main_image' => 'الصورة الرئيسية',
            'thumb_image' => 'الصورة المصغرة',
            'title_ar' => 'العنوان عربي',
            'title_en' => 'العنوان إنجليزي',
            'category_id' => 'تابع لقسم',
            'author_id' => 'كتب بواسطة',
            'status' => 'حالة النشر',
            'is_home' => ' في الصفحة الرئيسية',
            'is_featured' => ' رئيسية',
            'is_recommended' => ' كمقترح',
            'is_home_slider' => ' كسلايدر في الرئيسية',
            'video' => 'الفيديو',
            'type' => 'نوع النضارة',
            'files' => 'معرض الصور',
            'files.*' => 'معرض الصور',
            'video_duration' => 'مدة الفيديو',
            'post_date' => 'تاريخ النشر',
            'publish_type' => 'نوع النشر',
            'main_image_copyrights_ar' => 'حقوق نشر الصورة',
            'main_image_copyrights_en' => 'حقوق نشر الصورة',
            'thumb_image_copyrights_ar' => 'حقوق نشر الصورة',
            'thumb_image_copyrights_en' => 'حقوق نشر الصورة',
            'cover_copyrights_ar' => 'حقوق نشر الصورة',
            'cover_copyrights_en' => 'حقوق نشر الصورة',
        ];
    }

    public function messages()
    {
        return [
            'status.in' => 'لابد ان تكون حالة النشر من الآتي: (قيد المراجعة, تم النشر او تم الأرشفة)',
            'is_home.in' => 'لابد ان تكون قيمة (في الصفحة الرئيسية) تعم او لا',
            'is_featured.in' => 'لابد ان تكون قيمة (رئيسية) تعم او لا',
            'is_recommended.in' => 'لابد ان تكون قيمة (كمقترح) تعم او لا',
            'is_home_slider.in' => 'لابد ان تكون قيمة (كسلايدر في الرئيسية) تعم او لا',
            'type.in' => 'لابد ان تكون نوع النضارة من الآتي: (فيديو, صورة)',
            'publish_type.in' => 'لابد ان تكون نوع النشر من الآتي: (الكل ، الموبايل ، الويب)',
        ];
    }
}
