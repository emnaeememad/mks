<?php

namespace App\Http\Requests\Admin\MarayaBook;

use App\Enum\PublishStatus;
use Illuminate\Foundation\Http\FormRequest;

class UpdateMarayaBookRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'title_ar' => 'required|min:3|max:200',
            'title_en' => 'required|min:3|max:200',
            'main_image' => 'nullable|image',
            'file' => 'nullable|mimes:pdf',
            'category_id' => 'required|exists:categories,id',
            'author_id' => 'required|exists:authors,id',
            'status' => 'required|in:'.implode(',', PublishStatus::getStatuses()),
        ];
    }

    public function attributes()
    {
        return [
            'title_ar' => 'العنوان عربي',
            'title_en' => 'العنوان إنجليزي',
            'main_image' => 'صورة الغلاف',
            'file' => 'الكتاب PDF',
            'category_id' => 'تابع لقسم',
            'author_id' => 'كتب بواسطة',
            'status' => 'حالة النشر',
        ];
    }

    public function messages()
    {
        return [
            'status.in' => 'لابد ان تكون حالة النشر من الآتي: (قيد المراجعة, تم النشر او تم الأرشفة)',
        ];
    }
}
