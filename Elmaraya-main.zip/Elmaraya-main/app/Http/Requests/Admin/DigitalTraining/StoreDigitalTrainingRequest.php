<?php

namespace App\Http\Requests\Admin\DigitalTraining;

use Illuminate\Foundation\Http\FormRequest;

class StoreDigitalTrainingRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'title_ar' => 'required|string',
            'title_en' => 'required|string',
            'description_ar' => 'required|string',
            'description_en' => 'required|string',
            'what_will_learn_ar' => 'required|string',
            'what_will_learn_en' => 'required|string',
            'intro' => 'required|mimetypes:video/mp4,video/3gp',
            'trainer_id' => 'required|exists:trainers,id',
            'similar_digitals' => 'array|exists:digital_trainings,id',
        ];
    }
}
