<?php

namespace App\Http\Requests\Admin\Subscription;

use Illuminate\Foundation\Http\FormRequest;

class UpdateSubscriptionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'title_ar' => 'required|string|min:3|max:255',
            'title_en' => 'required|string|min:3|max:255',
            'description_ar' => 'required|string|min:3',
            'description_en' => 'nullable|string|min:3',
            'price' => 'required|numeric|min:0|regex:/^\d+(\.\d{1,2})?$/',
            'price_after' => 'nullable|numeric|min:0|regex:/^\d+(\.\d{1,2})?$/',
            'use_price_after' => 'nullable',
        ];
    }
}
