<?php

namespace App\Http\Requests\Admin\Role;

use Illuminate\Foundation\Http\FormRequest;

class UpdateRoleRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'name_ar' => 'required|min:3|max:250',
            'name_en' => 'required|min:3|max:250',
            'permissions' => 'required|array|filled',
            'permissions.*' => 'integer|required|exists:permissions,id',
        ];
    }

    public function attributes()
    {
        return [
            'name_ar' => 'إسم الصلاحية عربي',
            'name_en' => 'إسم الصلاحية إنجليزي',
            'permissions' => 'الصلاحيات',
            'permissions.*' => 'الصلاحيات',
        ];
    }
}
