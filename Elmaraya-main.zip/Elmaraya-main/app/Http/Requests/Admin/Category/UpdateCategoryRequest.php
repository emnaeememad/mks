<?php

namespace App\Http\Requests\Admin\Category;

use App\Enum\CategoryModules;
use Illuminate\Foundation\Http\FormRequest;

class UpdateCategoryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'name_ar' => 'required|min:3|max:200',
            'name_en' => 'required|min:3|max:200',
            'module' => 'required|in:'.implode(',', CategoryModules::getModules()),
            'parent_id' => 'nullable|sometimes|exists:categories,id',
            'is_active' => 'boolean',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ];
    }

    public function attributes()
    {
        return [
            'name_ar' => 'إسم القسم عربي',
            'name_en' => 'إسم القسم إنجليزي',
            'module' => 'القسم يتبع',
        ];
    }
}
