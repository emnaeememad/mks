<?php

namespace App\Http\Requests\Admin\Blog;

use App\Enum\PublishStatus;
use App\Enum\PublishType;
use Illuminate\Foundation\Http\FormRequest;

class StoreBlogRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'cover' => 'nullable|image',
            'main_image' => 'nullable|image',
            'thumb_image' => 'nullable|image',
            'title_ar' => 'required|min:5|max:200',
            'title_en' => 'required|min:5|max:200',
            'brief_ar' => 'nullable|min:20|max:750',
            'brief_en' => 'nullable|min:20|max:750',
            'description_ar' => 'nullable',
            'description_en' => 'nullable',
            'category_id' => 'nullable|exists:categories,id',
            'author_id' => 'required|exists:authors,id',
            'status' => 'required|in:'.implode(',', PublishStatus::getStatuses()),
            'is_home' => 'sometimes|in:1,0',
            'is_featured' => 'sometimes|in:1,0',
            'is_feature_blog' =>  'boolean',
            'is_recommended' => 'sometimes|in:1,0',
            'is_home_slider' => 'sometimes|in:1,0',
            'post_date' => 'nullable|date',
            'publish_type' => 'sometimes|in:'.implode(',', PublishType::getTypes()),
            'translator_ar' => 'nullable|string|min:3|max:200',
            'translator_en' => 'nullable|string|min:3|max:200',
            'main_image_copyrights_ar' => 'nullable|string|min:3|max:200',
            'main_image_copyrights_en' => 'nullable|string|min:3|max:200',
            'thumb_image_copyrights_ar' => 'nullable|string|min:3|max:200',
            'thumb_image_copyrights_en' => 'nullable|string|min:3|max:200',
            'cover_copyrights_ar' => 'nullable|string|min:3|max:200',
            'cover_copyrights_en' => 'nullable|string|min:3|max:200',
        ];
    }

    public function attributes()
    {
        return [
            'cover' => 'صورة الغلاف',
            'main_image' => 'الصورة الرئيسية',
            'thumb_image' => 'الصورة المصغرة',
            'title_ar' => 'العنوان عربي',
            'title_en' => 'العنوان إنجليزي',
            'brief_ar' => 'الوصف المصغر عربي',
            'brief_en' => 'الوصف المصغر إنجليزي',
            'description_ar' => 'الوصف الكامل عربي',
            'description_en' => 'الوصف الكامل إنجليزي',
            'category_id' => 'تابع لقسم',
            'author_id' => 'كتب بواسطة',
            'status' => 'حالة النشر',
            'is_home' => ' في الصفحة الرئيسية',
            'is_featured' => ' رئيسية',
            'is_feature_blog' => 'مدونة رئيسية',
            'is_recommended' => ' كمقترح',
            'is_home_slider' => ' كسلايدر في الرئيسية',
            'post_date' => 'تاريخ النشر',
            'publish_type' => 'نوع النشر',
            'translator_ar' => 'إسم المترجم عربي',
            'translator_en' => 'إسم المترجم إنجليزي',
            'main_image_copyrights_ar' => 'حقوق نشر الصورة',
            'main_image_copyrights_en' => 'حقوق نشر الصورة',
            'thumb_image_copyrights_ar' => 'حقوق نشر الصورة',
            'thumb_image_copyrights_en' => 'حقوق نشر الصورة',
            'cover_copyrights_ar' => 'حقوق نشر الصورة',
            'cover_copyrights_en' => 'حقوق نشر الصورة',
        ];
    }

    public function messages()
    {
        return [
            'status.in' => 'لابد ان تكون حالة النشر من الآتي: (قيد المراجعة, تم النشر او تم الأرشفة)',
            'is_home.in' => 'لابد ان تكون قيمة (في الصفحة الرئيسية) تعم او لا',
            'is_featured.in' => 'لابد ان تكون قيمة (رئيسية) تعم او لا',
            'is_recommended.in' => 'لابد ان تكون قيمة (كمقترح) تعم او لا',
            'is_home_slider.in' => 'لابد ان تكون قيمة (كسلايدر في الرئيسية) تعم او لا',
            'publish_type.in' => 'لابد ان تكون نوع النشر من الآتي: (الكل، الموبايل، الويب)',
        ];
    }
}
