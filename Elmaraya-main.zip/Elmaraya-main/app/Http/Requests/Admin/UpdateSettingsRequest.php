<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UpdateSettingsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'facebook_url' => 'nullable|url',
            'linkedin_url' => 'nullable|url',
            'instagram_url' => 'nullable|url',
            'twitter_url' => 'nullable|url',
            'youtube_url' => 'nullable|url',
            'tiktok_url' => 'nullable|url',
            'address_ar' => 'nullable|string|min:10|max:255',
            'address_en' => 'nullable|string|min:10|max:255',
            'phone_1' => 'nullable|string',
            'phone_2' => 'nullable|string',
            'phone_3' => 'nullable|string',
            'phone_4' => 'nullable|string',
            'phone_5' => 'nullable|string',
            'email' => 'nullable|email',
            'android_url' => 'nullable|url',
            'ios_url' => 'nullable|url',
            'footer_about_ar' => 'nullable|min:10|max:1000',
            'footer_about_en' => 'nullable|min:10|max:1000',
        ];
    }
}
