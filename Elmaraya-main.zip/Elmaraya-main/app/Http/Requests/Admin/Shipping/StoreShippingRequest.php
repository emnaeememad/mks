<?php


namespace App\Http\Requests\Admin\Shipping;
use App\Enum\BookRequestType;
use App\Enum\PublishStatus;
use Illuminate\Foundation\Http\FormRequest;

class StoreShippingRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|min:3|max:200',
            'price' => 'required|numeric',

        ];
    }

    public function attributes()
    {
        return [
            'name' => '  الاسم',
            'price' => '  السعر',

        ];
    }

    public function messages()
    {
        return [
            'name.required' => 'حقل الاسم مطلوب.',
            'name.min' => 'يجب أن يحتوي حقل الاسم على الأقل على 3 أحرف.',
            'name.max' => 'يجب أن يحتوي حقل الاسم على الأكثر 200 حرف.',
            'price.required' => 'حقل السعر مطلوب.',
            'price.numeric' => 'حقل السعر يجب أن يكون قيمة رقمية.',
        ];
    }
}
