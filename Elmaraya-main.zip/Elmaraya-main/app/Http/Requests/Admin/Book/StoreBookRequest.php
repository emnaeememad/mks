<?php

namespace App\Http\Requests\Admin\Book;

use App\Enum\PublishStatus;
use App\Enum\BookRequestType;
use Illuminate\Foundation\Http\FormRequest;

class StoreBookRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'main_image' => 'required|image',
            'name_ar' => 'required|min:3|max:200',
            'name_en' => 'required|min:3|max:200',
            'hard_copy_price' => 'required|numeric|min:0|regex:/^\d+(\.\d{1,2})?$/',
            'epob_price' => 'required|numeric|min:0|regex:/^\d+(\.\d{1,2})?$/',
            'description_ar' => 'required',
            'description_en' => 'nullable',
            'amazon_link' => 'nullable|url',
            'category_id' => 'required|exists:categories,id',
            'author_id' => 'required|exists:authors,id',
            'number_of_pages' => 'nullable|numeric|min:1',
            'file' => 'nullable|file',
            'status' => 'required|in:'.implode(',', PublishStatus::getStatuses()),
            // 'bar_code' => 'nullable|string',
            // 'reviewer' => 'nullable|string',
            'is_home' => 'required|boolean|in:0,1',
            'is_featured' => 'required|boolean|in:0,1',
            'is_recommended' => 'required|boolean|in:0,1',
            'request_type' => 'required|in:'.implode(',', BookRequestType::getTypes()),
            'extra_details_en' => 'nullable|string',
            'extra_details_ar' => 'nullable|string',
            'post_date' => 'required|date',
            'main_image_copyrights_ar' => 'nullable|string|min:3|max:200',
            'main_image_copyrights_en' => 'nullable|string|min:3|max:200',
            'published_house_id' => 'required|exists:authors,id'

        ];
    }

    public function attributes()
    {
        return [
            'cover' => 'صورة الغلاف',
            'main_image' => 'الصورة الرئيسية',
            'thumb_image' => 'الصورة المصغرة',
            'title_ar' => 'العنوان عربي',
            'title_en' => 'العنوان إنجليزي',
            'category_id' => 'تابع لقسم',
            'author_id' => 'كتب بواسطة',
            'status' => 'حالة النشر',
            'is_home' => ' في الصفحة الرئيسية',
            'is_featured' => ' رئيسية',
            'is_recommended' => ' كمقترح',
            'is_home_slider' => ' كسلايدر في الرئيسية',
            'video' => 'الفيديو',
            'type' => 'نوع النضارة',
            'files' => 'معرض الصور',
            'files.*' => 'معرض الصور',
            'video_duration' => 'مدة الفيديو',
            'request_type' => 'نوع الطلب',
            'extra_details_en' => 'تفاصيل اضافية',
            'extra_details_ar' => 'تفاصيل اضافية',
            // 'bar_code' => 'الباركود',
            // 'reviewer' => 'المراجع',
            'number_of_pages' => 'عدد الصفحات',
            'file' => 'الملف',
            'amazon_link' => 'الرابط',
            'hard_copy_price' => 'سعر النسخة',
            'epob_price' => 'سعر الكتاب',
            'description_ar' => 'الوصف عربي',
            'description_en' => 'الوصف أنجليزي',
            'post_date' => 'تاريخ النشر',
            'main_image_copyrights_ar' => 'حقوق نشر الصورة',
            'main_image_copyrights_en' => 'حقوق نشر الصورة',
            'published_house_id' => 'دار النشر',
        ];
    }

    public function messages()
    {
        return [
            'status.in' => 'لابد ان تكون حالة النشر من الآتي: (قيد المراجعة, تم النشر او تم الأرشفة)',
            'is_home.in' => 'لابد ان تكون قيمة (في الصفحة الرئيسية) تعم او لا',
            'is_featured.in' => 'لابد ان تكون قيمة (رئيسية) تعم او لا',
            'is_recommended.in' => 'لابد ان تكون قيمة (كمقترح) تعم او لا',
            'is_home_slider.in' => 'لابد ان تكون قيمة (كسلايدر في الرئيسية) تعم او لا',
        ];
    }
}
