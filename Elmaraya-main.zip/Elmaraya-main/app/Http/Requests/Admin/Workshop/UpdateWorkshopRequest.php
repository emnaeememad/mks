<?php

namespace App\Http\Requests\Admin\Workshop;

use App\Enum\PublishType;
use Illuminate\Foundation\Http\FormRequest;

class UpdateWorkshopRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return auth('admins')->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'cover' => 'nullable|image',
            'main_image' => 'nullable|image',
            'thumb_image' => 'nullable|image',
            'title_ar' => 'required|min:3|max:200',
            'title_en' => 'required|min:3|max:200',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'author_id' => 'required|exists:authors,id',
            'brief_ar' => 'required|min:20|max:750',
            'brief_en' => 'nullable|min:20|max:750',
            'description_ar' => 'required',
            'description_en' => 'nullable',
            'is_home' => 'required|in:1,0',
            'is_recommended' => 'required|in:1,0',
            'is_bookable' => 'required|in:1,0',
            'is_current' => 'required|in:1,0',
            'publish_type' => 'required|in:'.implode(',', PublishType::getTypes()),
        ];
    }

    public function attributes()
    {
        return [
            'cover' => 'الصورة الغلاف',
            'main_image' => 'الصورة الرئيسية',
            'thumb_image' => 'الصورة المصغرة',
            'title_ar' => 'العنوان عربي',
            'title_en' => 'العنوان إنجليزي',
            'start_date' => 'تاريخ بداية التدريب',
            'end_date' => 'تاريخ نهاية التدريب',
            'author_id' => 'كتب بواسطة',
            'brief_ar' => 'الوصف المصغر عربي',
            'brief_en' => 'الوصف المصغر إنجليزي',
            'description_ar' => 'الوصف الكامل عربي',
            'description_en' => 'الوصف الكامل إنجليزي',
            'is_home' => 'تظهر في الصفحة الرئيسية',
            'is_recommended' => 'تظهر كمقترح',
            'is_bookable' => 'الحجز فعال',
            'is_current' => 'حالية / منتهية',
            'publish_type' => 'نوع النشر',
        ];
    }
}
