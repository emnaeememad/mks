<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PaymentMethodTypesResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $name = app()->getLocale() == 'ar' ? $this->name_ar : $this->name_en;

        return [
            'id' => $this->id,
            'name' => $this->name_ar,
            // 'integration_id' => $this->integration_id,
            // 'iframe_id' => $this->iframe_id,          
            'image_url' => $this->image_url,
        ];
    }
}
