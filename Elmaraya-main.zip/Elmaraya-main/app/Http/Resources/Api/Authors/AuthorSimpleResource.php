<?php

namespace App\Http\Resources\Api\Authors;

use App\Enum\Genders;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AuthorSimpleResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $name = app()->getLocale() == 'ar' ? $this->name_ar : $this->name_en;
        $view_url =   route('landingPage.author.show', ['lang' => app()->getLocale(), 'slug' => $this->slug_translated]) ;
        return [
            'id' => $this->id,
            'name' => $name,
            'is_male' => $this->gender == Genders::male['name_en'],
            'photo' => $this->image_url,  
            'view_url' =>  $view_url

        ];
    }
}
