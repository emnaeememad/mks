<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MyBookResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $name = app()->getLocale() == 'ar' ? $this?->book?->name_ar : $this?->book?->name_en;

        return [
            'name' => $name,
            'epop_url' => $this->book->file_url ?? '',
            'image' => $this->book->main_image_url ?? '',
        ];
    }
}
