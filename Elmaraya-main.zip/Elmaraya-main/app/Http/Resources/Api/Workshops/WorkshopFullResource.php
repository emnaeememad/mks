<?php

namespace App\Http\Resources\Api\Workshops;

use App\Http\Resources\Api\Authors\AuthorSimpleResource;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class WorkshopFullResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        if (app()->getLocale() == 'ar') {
            $title = $this->title_ar;
            $brief = $this->brief_ar;
            $description = $this->description_ar;
        } else {
            $title = $this->title_en;
            $brief = $this->brief_en;
            $description = $this->description_en;
        }
        $view_url =route('landingPage.workshop.show', ['lang' => app()->getLocale(), 'slug' => $this->slug_translated]);
        return [
            'id' => $this->id,
            'title' => $title,
            'brief' => $brief,
            'description' => $description,
            'author' => new AuthorSimpleResource($this->author),
            'main_image' => $this->main_image_url,
            'thumb_image' => $this->thumb_image_url,
            'cover_image' => $this->cover_url,
            'start_date' => Carbon::parse($this->start_date)->format('d M Y'),
            'end_date' => Carbon::parse($this->end_date)->format('d M Y'),
            'total_shares' => $this->total_shares,
            'total_requests' => $this->total_requests,
            'view_url' =>  $view_url

        ];
    }
}
