<?php

namespace App\Http\Resources\Api\Workshops;

use App\Http\Resources\Api\Authors\AuthorSimpleResource;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class WorkshopSimpleResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $title = app()->getLocale() == 'ar' ? $this->title_ar : $this->title_en;
        $view_url =route('landingPage.workshop.show', ['lang' => app()->getLocale(), 'slug' => $this->slug_translated]);

        return [
            'id' => $this->id,
            'title' => $title,
            'author' => new AuthorSimpleResource($this->author),
            'main_image' => $this->main_image_url,
            'thumb_image' => $this->thumb_image_url,
            'start_date' => Carbon::parse($this->start_date)->format('d M Y'),
            'end_date' => Carbon::parse($this->end_date)->format('d M Y'),
            'view_url' =>  $view_url

        ];
    }
}
