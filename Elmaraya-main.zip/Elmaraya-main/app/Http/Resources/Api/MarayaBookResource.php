<?php

namespace App\Http\Resources\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MarayaBookResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $title = app()->getLocale() == 'ar' ? $this?->title_ar : $this?->title_en;

        return [
            'name' => $title,
            'pdf_url' => $this->file_url ?? '',
            'image' => $this->main_image_url ?? '',
        ];
    }
}
