<?php

namespace App\Http\Resources\Api\Nadara;

use App\Http\Resources\Api\Authors\AuthorSimpleResource;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class NadaraSimpleResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $view_url = route('landingPage.nadara.show', ['lang' => app()->getLocale(), 'slug' => $this->slug_translated]);

        return [
            'id' => $this->id,
            'title' => $this->title_translated,
            'description' => strip_tags($this->description_ar),
            'author' => new AuthorSimpleResource($this->author),
            'main_image' => $this->main_image_url,
            'thumb_image' => $this->thumb_image_url,
            'video_url' => $this->type == 'reels' ? $this->video_url : '',
            'youtube_link' => $this->type == 'reels' ? $this->youtube_link : '',
            'main_image_copyrights' => $this->main_image_copyrights,
            'thumb_image_copyrights' => $this->thumb_image_copyrights,
            'cover_copyrights' => $this->cover_copyrights,
            'view_url' =>  $view_url

        ];
    }
}
