<?php


namespace App\Http\Resources\Api\Cart;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MovieResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $view_url = route('landingPage.movie.show', ['lang' => app()->getLocale(), 'slug' => $this->slug_translated]);
        return [
            'id' => $this->id,
            'name' => $this->name_translated,
            'brief' => $this->brief_translated,
            'description' => $this->description_translated,
            'main_image' => $this->main_image_url,         
            'view_url' =>  $view_url

        ];
    }
}
