<?php


namespace App\Http\Resources\Api\Cart;

use App\Enum\OrderType;
use Illuminate\Http\Request;
use App\Traits\CartItemTransformer;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Api\Blogs\BlogSimpleResource;

class CartResource extends JsonResource
{
    use CartItemTransformer;

    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        
        $itemDetails = $this->transformItemDetails($this->item_type, $this->item_id, $this->id);
        $item_type = $this->transformItemType($this->item_type);
        $response = [
            'id' => $this->id,
            'quantity' =>  $this->quantity,
            'item_type' =>   $item_type ,
            'item' => $itemDetails,
        ];

        // if ($item_type ==OrderType::book ) {
        //     $response['book_type'] = $this->book_type;
        // }

        return $response;
    }
}
