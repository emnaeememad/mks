<?php

namespace App\Http\Resources\Api\Cart;

use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\WorkshopOnline;
use App\Bll\AvailabilityWorkshopOnlineHelper;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Api\Authors\AuthorSimpleResource;

class WorkshopOnlineResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
         
        $formattedPrice = $this->price ? $this->formatPrice($this->price) : null;

         return [
            'id' => $this->id,
            'title' => $this->title,
            'price' => $formattedPrice, 

        ];
    }

      /**
     * Format the price attribute to a floating-point number with two decimal places.
     *
     * @param  float  $price
     * @return float
     */
    public   function formatPrice(float $price): float
    {
        // Format the price attribute to a floating-point number with two decimal places
        return round($price, 2) ?? 0.0;
    }
}
