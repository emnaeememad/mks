<?php

namespace App\Http\Resources\Api\Cart;

use Illuminate\Http\Resources\Json\ResourceCollection;

class BookResourceCollection extends ResourceCollection
{
    protected $cart_id;

    public function __construct($resource, $cart_id)
    {
         parent::__construct($resource);

        $this->cart_id = $cart_id;
    }

    public function toArray($request)
    {
        return $this->collection->map(function ($bookResource) {
            $bookResource->cart_id = $this->cart_id;
            return $bookResource;
        })->toArray();

      
    }
}
