<?php


namespace App\Http\Resources\Api\Cart\HardCopies;

use App\Models\Book;
use App\Enum\OrderType;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PhysicalCartResource extends JsonResource
{

    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {

        $item = Book::find($this->item_id);

        $response = [
            'id' => $this->id,
            'quantity' =>  $this->quantity,
            'item_type' =>   OrderType::book,
            'item' => new PhysicalBookResource($item),
        ];

        return $response;
    }
}
