<?php


namespace App\Http\Resources\Api\Cart\HardCopies;

use App\Models\Cart;
use App\Enum\BookType;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Api\Authors\AuthorSimpleResource;

class PhysicalBookResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $view_url = route('landingPage.book.show', ['lang' => app()->getLocale(), 'slug' => $this->slug_translated]);
        return [
            'id' => $this->id,
            'name' => $this->name_translated,
            'book_type' =>  BookType::physical,
            'price' =>  $this->hard_copy_price,
            'description' => $this->description_translated,
            'main_image' => $this->main_image_url,
            'view_url' =>  $view_url
        ];
    }
}
