<?php

namespace App\Http\Resources\Api\Workshopsonline;

use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\WorkshopOnline;
use App\Bll\AvailabilityWorkshopOnlineHelper;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Api\Authors\AuthorSimpleResource;

class WorkshopOnlineSimpleResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $customer = auth('sanctum')->user();
        $isCustomerHasActiveSubscription = $customer->customerSubscriptions()->active()->exists();
        $isAccessFreeAvailability = AvailabilityWorkshopOnlineHelper::checkAvailability(WorkshopOnline::where('id', $this->id));
        $accessible = false;
        ($customer->load('workshoponlinePurchases'));
        if ($customer->hasPurchasedWorkshoponline($this->id)) {
            $accessible = true;
        }
        $formattedPrice = $this->price ? $this->formatPrice($this->price) : null;

        $finalaccessStatus = $isCustomerHasActiveSubscription || $isAccessFreeAvailability  || $accessible;
        return [
            'id' => $this->id,
            'title' => $this->title,
            'price' => $formattedPrice,
            'author' => new AuthorSimpleResource($this->author),
            'videos' => $finalaccessStatus === true ? WorkshopOnlineVideosResource::collection($this->videos) : [],
            'finalaccessStatus' =>  $finalaccessStatus,
            'isAccessFreeAvailability' =>  $isAccessFreeAvailability,
            'subscriber_status' => $isCustomerHasActiveSubscription,
            'is_purchased' => $accessible ,

        ];
    }

      /**
     * Format the price attribute to a floating-point number with two decimal places.
     *
     * @param  float  $price
     * @return float
     */
    public   function formatPrice(float $price): float
    {
        // Format the price attribute to a floating-point number with two decimal places
        return round($price, 2) ?? 0.0;
    }
}
