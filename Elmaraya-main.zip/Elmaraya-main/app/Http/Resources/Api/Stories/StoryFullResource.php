<?php

namespace App\Http\Resources\Api\Stories;

use App\Http\Resources\Api\Authors\AuthorSimpleResource;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class StoryFullResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $view_url = route('landingPage.story.show', ['lang' => app()->getLocale(), 'slug' => $this->slug_translated]);

        return [
            'id' => $this->id,
            'title' => $this->title_translated,
            'author' => new AuthorSimpleResource($this->author),
            'main_image' => $this->main_image_url,
            'thumb_image' => $this->thumb_image_url,
            'cover_image' => $this->cover_url,
            'file_url' => $this->file_url,
            'file_length' => $this->file_length_trimmed,
            'total_plays' => $this->total_plays,
            'total_shares' => $this->total_shares,
            'main_image_copyrights' => $this->main_image_copyrights,
            'thumb_image_copyrights' => $this->thumb_image_copyrights,
            'cover_copyrights' => $this->cover_copyrights,
            'soundcloud_url' => $this->soundcloud_url,
            'spotify_url' => $this->spotify_url,
            'anghami_url' => $this->anghami_url,
            'view_url' =>  $view_url

        ];
    }
}
