<?php

namespace App\Http\Resources\Api\Books;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SubscriptionsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $title = app()->getLocale() == 'ar' ? $this->title_ar : $this->title_en;
        $description = app()->getLocale() == 'ar' ? $this->description_ar : $this->description_en;
      
        return [
            'id' => $this->id,
            'title' => $title ,         
            'description' => $description ,         
            'price' => $this->price,
            'price_after' => $this->price_after,
            'price_after_status' => $this->use_price_after == 0 ? false : true,
        ];
    }
}
