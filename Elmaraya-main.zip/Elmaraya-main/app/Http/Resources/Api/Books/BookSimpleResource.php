<?php

namespace App\Http\Resources\Api\Books;

use App\Http\Resources\Api\Authors\AuthorSimpleResource;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class BookSimpleResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $view_url = route('landingPage.book.show', ['lang' => app()->getLocale(), 'slug' => $this->slug_translated]);
        return [
            'id' => $this->id,
            'name' => $this->name_translated,
            'author' => new AuthorSimpleResource($this->author),
            'main_image' => $this->main_image_url,
            'hard_copy_price' => $this->hard_copy_price,
            'epub_copy_price' => $this->epob_price,
            'main_image_copyrights' => $this->main_image_copyrights,
            'view_url' =>  $view_url,
            'apple_store_id' =>  $this->apple_store_id
        ];
    }
}
