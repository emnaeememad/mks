<?php

namespace App\Http\Resources\Api\Books;

use App\Models\Orders;
use Illuminate\Http\Request;
use App\Services\FileReaderService;
use App\Integrations\Payments\Paymob\Order;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Api\Categories\CategoryResource;
use App\Http\Resources\Api\Authors\AuthorSimpleResource;

class BookFullResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {

        // dd(1);

        $customer = auth('sanctum')->user();

        $view_url = route('landingPage.book.show', ['lang' => app()->getLocale(), 'slug' => $this->slug_translated]);
 

        $fileReaderService = new FileReaderService();
        $canRead = $fileReaderService->canUserReadFile($customer, $this->id);
        
        return [
            'id' => $this->id,
            'name' => $this->name_translated,
            'description' => $this->description_translated,
            'extra_details_ar' => $this->extra_details_ar,
            'author' => new AuthorSimpleResource($this->author),
            'category' => new CategoryResource($this->category),
            'main_image' => $this->main_image_url,
            'hard_copy_price' => $this->hard_copy_price,
            'epub_copy_price' => $this->epob_price,
            'epub_url' =>  $canRead ? $this->file_url : '',
            'amazon_link' => $this->amazon_link,
            'number_of_pages' => $this->number_of_pages,
            // 'bar_code' => $this->bar_code,
            'total_soft_purchased' => $this->total_soft_purchased,
            'total_hard_purchased' => $this->total_hard_purchased,
            'total_views' => $this->total_views,
            'total_shares' => $this->total_shares,
            // 'reviewer' => $this->reviewer,
            'main_image_copyrights' => $this->main_image_copyrights,
            'view_url' => $view_url,
            'apple_store_id' =>  $this->apple_store_id,
        ];
    }
}
