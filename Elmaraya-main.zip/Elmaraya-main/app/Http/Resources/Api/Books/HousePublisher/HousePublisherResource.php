<?php

namespace App\Http\Resources\Api\Books\HousePublisher;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Api\Books\BookSimpleSubResource;

class HousePublisherResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $customer = auth('sanctum')->user();

        $name = app()->getLocale() == 'ar' ? $this->name_ar : $this->name_en;
        return [
            'id' => $this->id,
            'name' => $name,
            'photo' => $this->image_url,
            'books' => BookSimpleSubResource::collection($this->booksHouse),
        ];
    }
}
