<?php

namespace App\Http\Resources\Api\Categories\Blogs;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Api\Blogs\BlogSimpleResource;

class CategoryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $name = app()->getLocale() == 'ar' ? $this->name_ar : $this->name_en;
        $paginatedBlogs= $this->blogs()->paginate(10);

        return [
            'id' => $this->id,
            'name' => $name,
            'image' => $this->image_url,
            'children' => CategoryChildrenResource::collection($this->children),
            'blogs' => BlogSimpleResource::collection($paginatedBlogs),
        ];
    }
}
