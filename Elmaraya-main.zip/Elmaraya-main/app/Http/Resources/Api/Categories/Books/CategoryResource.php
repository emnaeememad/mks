<?php

namespace App\Http\Resources\Api\Categories\Books;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Api\Books\BookSimpleResource;
use App\Http\Resources\Api\Categories\Books\CategoryChildrenResource;

class CategoryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $name = app()->getLocale() == 'ar' ? $this->name_ar : $this->name_en;
        $paginatedBooks= $this->books()->paginate(10);

        return [
            'id' => $this->id,
            'name' => $name,
            'image' => $this->image_url,
            'children' => CategoryChildrenResource::collection($this->children),
            'books' => BookSimpleResource::collection($paginatedBooks),
        ];
    }
}
