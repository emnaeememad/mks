<?php

namespace App\Http\Resources\Api\Categories\Story;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Api\Blogs\BlogSimpleResource;
 use App\Http\Resources\Api\Nadara\NadaraSimpleResource;
use App\Http\Resources\Api\Categories\Story\CategoryChildrenResource;

class CategoryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $name = app()->getLocale() == 'ar' ? $this->name_ar : $this->name_en;
        $paginatedStories= $this->stories()->paginate(10);

        return [
            'id' => $this->id,
            'name' => $name,
            'image' => $this->image_url,
            'children' => CategoryChildrenResource::collection($this->children),
            'stories' => NadaraSimpleResource::collection($paginatedStories),
        ];
    }
}
