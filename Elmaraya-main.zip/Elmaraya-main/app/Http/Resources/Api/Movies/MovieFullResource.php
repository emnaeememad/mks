<?php

namespace App\Http\Resources\Api\Movies;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MovieFullResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $view_url = route('landingPage.movie.show', ['lang' => app()->getLocale(), 'slug' => $this->slug_translated]);

        return [
            'id' => $this->id,
            'name' => $this->name_translated,
            'brief' => $this->brief_translated,
            'description' => $this->description_translated,
            'main_image' => $this->main_image_url,
            'thumb_image' => $this->thumb_image_url,
            'cover_image' => $this->cover_url,
            'total_shares' => $this->total_shares,
            'images' => MovieImageResource::collection($this->images),
            'videos' => MovieImageResource::collection($this->videos),
            'main_image_copyrights' => $this->main_image_copyrights,
            'thumb_image_copyrights' => $this->thumb_image_copyrights,
            'cover_copyrights' => $this->cover_copyrights,
            'view_url' =>  $view_url

        ];
    }
}
