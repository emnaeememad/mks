<?php

namespace App\Http\Controllers\Api;

use App\Models\Nadara;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Enum\CategoryModules;
use App\Services\NadaraService;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\ApiBaseController;
use App\Http\Resources\Api\Nadara\NadaraFullResource;
use App\Http\Resources\Api\Nadara\NadaraSimpleResource;
use App\Http\Resources\Api\Categories\Nadara\CategoryResource;

class NadaraController extends ApiBaseController
{
    public function __construct(
        private readonly NadaraService $nadaraService
    ) {
    }

    public function getList(Request $request): JsonResponse
    {
        $nadaraPhotos = $this->nadaraService->getMobileFiltered(4, 'mobile');
        $nadaraReels = $this->nadaraService->getFeaturedReels(4, 'mobile');

        return $this->successResponse([
            'nadaraReels' => NadaraSimpleResource::collection($nadaraReels),
            'nadaraPhotos' => NadaraSimpleResource::collection($nadaraPhotos),
        ]);
    }

    public function getPhotosList(Request $request): JsonResponse
    {
        $nadaraPhotos = $this->nadaraService->getFiltered($request, 'mobile');

        return $this->successResponse([
            'nadaraPhotos' => NadaraSimpleResource::collection($nadaraPhotos->items()),
            'next' => $nadaraPhotos->hasMorePages(),
            'total' => $nadaraPhotos->total(),
        ]);
    }

    public function getReelsList(Request $request): JsonResponse
    {
        $nadaraReels = $this->nadaraService->getFilteredReels($request, 'mobile');

        return $this->successResponse([
            'nadaraReels' => NadaraSimpleResource::collection($nadaraReels->items()),
            'next' => $nadaraReels->hasMorePages(),
            'total' => $nadaraReels->total(),
        ]);
    }

    public function getNadara(int $id): JsonResponse
    {
        $story = $this->nadaraService->getNadaraDetails($id);

        return $this->successResponse(NadaraFullResource::make($story));
    }

    public function eventView(int $id): JsonResponse
    {
        $this->nadaraService->eventView($id);

        return $this->successResponse([]);
    }

    public function eventPlay(int $id): JsonResponse
    {
        $this->nadaraService->eventPlay($id);

        return $this->successResponse([]);
    }

    public function eventShare(int $id): JsonResponse
    {
        $this->nadaraService->eventShare($id);

        return $this->successResponse([]);
    }
 
    public function getDistinctiveNadaras() {
        $distinctiveBlogs =  Nadara::published()
       ->where('is_distinctive', 1)
      ->inRandomOrder()
      ->limit(10) 
      ->get();
      return $this->successResponse(NadaraSimpleResource::collection($distinctiveBlogs));

  }


  public function getCategory(Request $request)
  {       
      $categories = Category::with(['children.nadaras', 'nadaras'])->canBeParent()
          ->where('module', CategoryModules::nadara)->where('is_active', 1)
          ->get();
     return $this->successResponse(CategoryResource::collection($categories));

  }
}
