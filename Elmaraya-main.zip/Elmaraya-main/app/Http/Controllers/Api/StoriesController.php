<?php

namespace App\Http\Controllers\Api;

use App\Models\Story;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Enum\CategoryModules;
use App\Services\StoriesService;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\ApiBaseController;
use App\Http\Resources\Api\Stories\StoryFullResource;
use App\Http\Resources\Api\Stories\StorySimpleResource;
use App\Http\Resources\Api\Categories\Story\CategoryResource;

class StoriesController extends ApiBaseController
{
    public function __construct(
        private readonly StoriesService $storiesService
    ) {
    }

    public function getList(Request $request): JsonResponse
    {
        $stories = $this->storiesService->getFiltered($request, 'mobile');

        return $this->successResponse([
            'stories' => StorySimpleResource::collection($stories->items()),
            'next' => $stories->hasMorePages(),
            'total' => $stories->total(),
        ]);
    }

    public function getMostPlayed(): JsonResponse
    {
        $stories = $this->storiesService->getMostPlayed(4, 'mobile');
        return $this->successResponse(StorySimpleResource::collection($stories));
    }

    public function getStory(int $id): JsonResponse
    {
        $story = $this->storiesService->getStoryDetails($id);
        $otherSotories = $this->storiesService->getOtherStories($story);

        return $this->successResponse(['story' => StoryFullResource::make($story), 'other_stories' => StorySimpleResource::collection($otherSotories)]);
    }

    public function eventPlay(int $id): JsonResponse
    {
        $this->storiesService->eventPlay($id);

        return $this->successResponse([]);
    }

    public function eventShare(int $id): JsonResponse
    {
        $this->storiesService->eventShare($id);

        return $this->successResponse([]);
    }

    public function getDistinctiveStories() {
        $distinctiveBlogs =  Story::published()
       ->where('is_distinctive', 1)
      ->inRandomOrder()
      ->limit(10) 
      ->get();
      return $this->successResponse(StorySimpleResource::collection($distinctiveBlogs));

  }
  public function getCategory(Request $request)
  {       
      $categories = Category::with(['children.stories', 'stories'])->canBeParent()
          ->where('module', CategoryModules::stories)->where('is_active', 1)
          ->get();
     return $this->successResponse(CategoryResource::collection($categories));

  }
  
}
