<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\ApiBaseController;
use App\Http\Requests\Api\ContactUs\ContactUsRequest;
use App\Http\Resources\Api\MarayaBookResource;
use App\Models\MarayaAbout;
use App\Models\MarayaPrivacy;
use App\Services\Api\ContactUsService;
use App\Services\MarayaBooksService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MarayaDataController extends ApiBaseController
{
    public function about(Request $request): JsonResponse
    {
        $about = MarayaAbout::first();

        return $this->successResponse([
            'about' => app()->getLocale() == 'ar' ? ($about?->about_ar ?? '') : ($about?->about_en ?? ''),
        ]);
    }

    public function privacy(Request $request): JsonResponse
    {
        $privacy = MarayaPrivacy::first();

        return $this->successResponse([
            'privacy' => app()->getLocale() == 'ar' ? ($privacy?->privacy_ar ?? '') : ($privacy?->privacy_en ?? ''),
        ]);
    }

    public function contactUs(ContactUsRequest $request): JsonResponse
    {
        (new ContactUsService)->apiContactUs($request);

        return $this->successResponse([], __('api.contact-us-received'));
    }

    public function books(Request $request): JsonResponse
    {
        $books = (new MarayaBooksService)->bookList($request);

        return $this->successResponse([
            'books' => MarayaBookResource::collection($books->items()),
            'next' => $books->hasMorePages(),
            'total' => $books->total(),
        ]);
    }
}
