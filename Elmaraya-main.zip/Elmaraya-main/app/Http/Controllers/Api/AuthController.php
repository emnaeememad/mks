<?php

namespace App\Http\Controllers\Api;

use Exception;
use Illuminate\Http\JsonResponse;
use App\Exceptions\NonVerifiedCustomer;
use App\Services\Api\Auth\LoginService;
use App\Http\Requests\Api\Auth as AuthRequest;
use App\Services\Api\Auth\RegisterService;
use App\Http\Controllers\ApiBaseController;
use App\Http\Resources\Api\ProfileResource;
use App\Services\Api\Auth\ForgotPasswordService;

class AuthController extends ApiBaseController
{
    public function __construct(
        private readonly RegisterService $registerService,
        private readonly LoginService $loginService,
        private readonly ForgotPasswordService $forgotPasswordService,
    ) {
    }

    public function register(
        AuthRequest\RegisterRequest $request
    ): JsonResponse {
        $customer = $this->registerService->register($request);

        return $this->successResponse(new ProfileResource($customer), __('api.customer-registered'));
    }

    public function login(
        AuthRequest\LoginRequest $request
    ): JsonResponse {
        try {
            $customer = $this->loginService->login($request);
            $token = $this->loginService->generateToken($customer);
        } catch (NonVerifiedCustomer $e) {
            return $this->failResponse($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            return $this->failResponse($e->getMessage());
        }

        return $this->successResponse([
            'customer' => new ProfileResource($customer),
            'token' => $token,
        ], __('api.customer-logged-in'));
    }

    public function phoneForgotPassword(
        AuthRequest\PhoneForgotPasswordRequest $request
    ): JsonResponse {
        $this->forgotPasswordService->phoneForgotPassword($request);

        return $this->successResponse([], __('api.reset-code-via-phone'));
    }

    public function emailForgotPassword(
        AuthRequest\EmailForgotPasswordRequest $request
    ): JsonResponse {
        $this->forgotPasswordService->emailForgotPassword($request);

        return $this->successResponse([], __('api.reset-code-via-mail'));
    }

    public function phoneResetPassword(
        AuthRequest\PhoneResetPasswordRequest $request
    ): JsonResponse {
        $this->forgotPasswordService->phoneResetPassword($request);

        return $this->successResponse([], __('api.password-reset-success'));
    }

    public function emailResetPassword(
        AuthRequest\EmailResetPasswordRequest $request
    ): JsonResponse {
        $status = $this->forgotPasswordService->emailResetPassword($request);
        if($status == false){
            return $this->failResponse(__('api.password-reset-failed'));
 
        }
        return $this->successResponse([], __('api.password-reset-success'));
    }

    public function verifyAccount(
        AuthRequest\VerifyRequest $request
    ): JsonResponse {
        if ($this->registerService->verify($request)) {
            return $this->successResponse([], __('api.customer-verified'));
        }

        return $this->failResponse(__('api.verify-fail'));
    }

    public function resendOtp(
        AuthRequest\ResendVerificationRequest $request
    ): JsonResponse {
        $this->registerService->resendOtp($request);

        return $this->successResponse([], __('api.otp-resent'));
    }

    public function deleteAccount(){
        try {
            $user = auth()->user();
            $user ? $user->delete() : null;
            return $this->successResponse([], __('api.account-deleted'));
        } catch (\Exception $e) {
            return $this->failResponse($e->getMessage(), $e->getCode());
        }
        
    }
}
