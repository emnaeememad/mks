<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\ApiBaseController;
use App\Http\Requests\Api\Profile\ChangePasswordRequest;
use App\Http\Requests\Api\Profile\EditProfileRequest;
use App\Http\Resources\Api\ProfileResource;
use App\Services\Api\Profile\ProfileService;
use Exception;
use Illuminate\Http\JsonResponse;

class ProfileController extends ApiBaseController
{
    public function __construct(
        private readonly ProfileService $profileService,
    ) {
    }

    public function profile(): JsonResponse
    {
        return $this->successResponse(new ProfileResource(auth('sanctum')->user()));
    }

    public function edit(EditProfileRequest $request): JsonResponse
    {
        $customer = $this->profileService->edit(auth('sanctum')->user(), $request);

        return $this->successResponse(new ProfileResource($customer));
    }

    public function changePassword(ChangePasswordRequest $request): JsonResponse
    {
        try {
            $this->profileService->changePassword(auth('sanctum')->user(), $request);

            return $this->successResponse([], __('api.password-changed'));
        } catch (Exception $e) {
            return $this->failResponse($e->getMessage());
        }
    }
}
