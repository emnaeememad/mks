<?php

namespace App\Http\Controllers\Api;

use App\Models\Blog;
use App\Models\Category;
use App\Enum\BlogModules;
use Illuminate\Http\Request;
use App\Enum\CategoryModules;
use Illuminate\Http\JsonResponse;
use App\Services\BlogModulesService;
use App\Traits\BlogModulesControllerTrait;
use App\Http\Controllers\ApiBaseController;
use App\Http\Resources\Api\Blogs\BlogFullResource;
use App\Http\Resources\Api\Blogs\BlogSimpleResource;
use App\Http\Resources\Api\Categories\Blogs\CategoryResource;

class BlogsController extends ApiBaseController
{
    public function __construct(
        private readonly BlogModulesService $blogModulesService
    ) {
    }

    public function getList(Request $request): JsonResponse
    {
        $blogs = $this->blogModulesService->getFiltered(BlogModules::blogs, $request, 'mobile');

        return $this->successResponse([
            'blogs' => BlogSimpleResource::collection($blogs->items()),
            'next' => $blogs->hasMorePages(),
            'total' => $blogs->total(),
        ]);
    }

    public function getMostRead(): JsonResponse
    {
        $blogs = $this->blogModulesService->getMostRead(BlogModules::blogs, 4, 'mobile');

        return $this->successResponse(BlogSimpleResource::collection($blogs));
    }

    public function getBlog(int $id): JsonResponse
    {
        $blog = $this->blogModulesService->getBlogDetails($id);

        return $this->successResponse(BlogFullResource::make($blog));
    }

    public function eventView(int $id): JsonResponse
    {
        $this->blogModulesService->eventView($id);

        return $this->successResponse([]);
    }

    public function eventShare(int $id): JsonResponse
    {
        $this->blogModulesService->eventShare($id);

        return $this->successResponse([]);
    }

    public function getDistinctiveBlogs()
    {
        $distinctiveBlogs =  Blog::published()
            ->where('is_distinctive', 1)
            ->inRandomOrder()
            ->limit(10)
            ->get();
        return $this->successResponse(BlogSimpleResource::collection($distinctiveBlogs));
    }

    public function getCategory(Request $request)
    {
         
        $categories = Category::with(['children.blogs', 'blogs'])->canBeParent()
            ->where('module', CategoryModules::blogs)->where('is_active', 1)
            ->get();

       return $this->successResponse(CategoryResource::collection($categories));

    }
}
