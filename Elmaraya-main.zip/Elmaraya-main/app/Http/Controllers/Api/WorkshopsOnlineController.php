<?php

namespace App\Http\Controllers\Api;

use App\Models\Workshop;
use Illuminate\Http\Request;
use App\Models\WorkshopOnline;
use App\Models\PaymentMethodType;
use Illuminate\Http\JsonResponse;
use App\Services\WorkshopsService;
use Illuminate\Support\Facades\Log;
 use App\Http\Resources\Api\Workshopsonline\WorkshopOnlineFullResource;
use App\Http\Controllers\ApiBaseController;
use App\Bll\PaymobPaymentMethodWorkshopOnline;
use App\Http\Requests\Api\Workshopsonline\PurchaseWorkshopOnlineRequest;
use App\Http\Resources\Api\Workshopsonline\WorkshopOnlineSimpleResource;

class WorkshopsOnlineController extends ApiBaseController
{
    public function __construct(
        private readonly WorkshopsService $workshopsService
    ) {
    }

    public function index(Request $request): JsonResponse
    {
        $workshopsonline = WorkshopOnline::with('videos')->descOrder()->paginate(10);

        return $this->successResponse([
            'workshops' => WorkshopOnlineSimpleResource::collection($workshopsonline),
            'next' => $workshopsonline->hasMorePages(),
            'total' => $workshopsonline->total(),
        ]);
    }

    public function show(Request $request, $workshopsonline): JsonResponse
    {
        $workshoponline = WorkshopOnline::with('videos')->find($workshopsonline);

        return $this->successResponse([
            new WorkshopOnlineFullResource($workshoponline),
        ]);
    }

    public function getPurchasedWorkshoponline(): JsonResponse
    {
        $customer = auth()->user();
        $customer->load('workshoponlinePurchases');
        $purchasedWorkshopsonline = $customer->purchasedWorkshoponline();



        return $this->successResponse([
            'workshops' => WorkshopOnlineSimpleResource::collection($purchasedWorkshopsonline),
            'next' => $purchasedWorkshopsonline->hasMorePages(),
            'total' => $purchasedWorkshopsonline->total(),
        ]);
    }



    public function getDistinctiveWorkshops()
    {
        $distinctiveBlogs =  WorkshopOnline::with('videos')->where('is_distinctive', 1)
            ->inRandomOrder()
            ->paginate(10);
        return $this->successResponse([
            'workshops' => WorkshopOnlineSimpleResource::collection($distinctiveBlogs),
            'next' => $distinctiveBlogs->hasMorePages(),
            'total' => $distinctiveBlogs->total(),
        ]);
    }

    public function purchase(PurchaseWorkshopOnlineRequest $request, $workshopsonline)
    {

        $payment_paymob_type = PaymentMethodType::findOrFail($request->payment_type_id);
        $payment_paymob_type->integration_id;
        $iframe_id_or_wallet_number = $payment_paymob_type->iframe_id;
        $integration_id = $payment_paymob_type->integration_id;
        $paymob_type = $payment_paymob_type->type;
        $iframe_id_or_wallet_number = $payment_paymob_type->iframe_id;

        if ($payment_paymob_type->type == 'wallet') {
            $iframe_id_or_wallet_number = $payment_paymob_type->iframe_id ?? '01010101010';
        }

         try {
            // Check if the book exists
            WorkshopOnline::findOrFail($workshopsonline);
        } catch (\Exception $ex) {
            // Handle the case where the book does not exist
            Log::error($ex);
            return $this->failResponse(__('api.workshop-online-not-found'));
        }

         try {
            $customer = auth('sanctum')->user();
          
           ($customer->load('workshoponlinePurchases'));
            if ($customer->hasPurchasedWorkshoponline($workshopsonline)) {
                return $this->failResponse(__('api.workshop-online-already-purchased'));
            }
        } catch (\Exception $ex) {
            // Handle any exceptions here
            Log::error($ex);
            return $this->failResponse(__('api.payment-failed'));
        }
        $paymentId = $request->payment_id;
        $paymob = new PaymobPaymentMethodWorkshopOnline($workshopsonline, $paymentId,  $integration_id, $paymob_type, $iframe_id_or_wallet_number);
        /// Callback run in BookController
        $url = $paymob->checkingOut();
        if ($url == false) {
            return $this->failResponse();
        }
        return $this->successResponse($url, __('api.workshop-online-purchase'));
    }
}
