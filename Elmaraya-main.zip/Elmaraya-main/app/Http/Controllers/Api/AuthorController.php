<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\ApiBaseController;
use App\Http\Controllers\Controller;
use App\Http\Resources\Api\Authors\AuthorFullResource;
use App\Models\Author;
use App\Services\AuthorService;
use App\Services\BlogModulesService;
use App\Services\StoriesService;
use App\Services\BooksService;
use App\Services\MoviesService;
use App\Services\WorkshopsService;
use App\Services\HomeService;
use App\Services\MarayaBooksService;
use App\Services\NadaraService;
use Illuminate\Http\Request;
use App\Enum\BlogModules;

class AuthorController extends ApiBaseController
{
    public function __construct(
        private BlogModulesService $blogModulesService,
        private StoriesService $storiesService,
        private BooksService $booksService,
        private MoviesService $moviesService,
        private WorkshopsService $workshopsService,
        private HomeService $homeService,
        private MarayaBooksService $marayaBooksService,
        private NadaraService $nadaraService,
        private AuthorService $authorService,
    ) {
    }

    public function show($id, Request $request)
    {
        $author = $this->authorService->getAuthorDetails($id);

        $data = [
            'model' => AuthorFullResource::make($author),
            'blogs' => $this->blogModulesService->getFiltered(BlogModules::blogs, $request->merge(['author' => $author->id, 'per_page' => 200])),
            'stories' => $this->storiesService->getFiltered($request->merge(['author' => $author->id, 'per_page' => 200])),
            'nadaras' => $this->nadaraService->getFiltered($request->merge(['author' => $author->id, 'per_page' => 200])),
            'books' => $this->booksService->getFiltered($request->merge(['author' => $author->id, 'per_page' => 200])),
            'workshops' => $this->workshopsService->getFiltered($request->merge(['author' => $author->id, 'per_page' => 200])),
        ];
        return $data;
        // return $this->successResponse(AuthorFullResource::make($author));
    }
}
