<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\ApiBaseController;
use App\Http\Requests\Api\Workshops\ApplyForWorkshopRequest;
use App\Http\Resources\Api\Workshops\WorkshopFullResource;
use App\Http\Resources\Api\Workshops\WorkshopSimpleResource;
use App\Models\Workshop;
use App\Services\WorkshopsService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class WorkshopsController extends ApiBaseController
{
    public function __construct(
        private readonly WorkshopsService $workshopsService
    ) {
    }

    public function current(Request $request): JsonResponse
    {
        $workshops = $this->workshopsService->getCurrent($request, 'mobile');

        return $this->successResponse([
            'workshops' => WorkshopSimpleResource::collection($workshops->items()),
            'next' => $workshops->hasMorePages(),
            'total' => $workshops->total(),
        ]);
    }

    public function passed(Request $request): JsonResponse
    {
        $workshops = $this->workshopsService->getPassed($request, 'mobile');

        return $this->successResponse([
            'workshops' => WorkshopSimpleResource::collection($workshops->items()),
            'next' => $workshops->hasMorePages(),
            'total' => $workshops->total(),
        ]);
    }

    public function getWorkshop(int $id): JsonResponse
    {
        $workshop = $this->workshopsService->getWorkshopDetails($id);

        return $this->successResponse(WorkshopFullResource::make($workshop));
    }

    public function apply(ApplyForWorkshopRequest $request, int $id): JsonResponse
    {
        $this->workshopsService->applyForWorkshop($id, $request);

        return $this->successResponse([], __('api.workshop-applied'));
    }

    public function eventShare(int $id): JsonResponse
    {
        $this->workshopsService->eventShare($id);

        return $this->successResponse([]);
    }
    public function getDistinctiveWorkshops() {
        $distinctiveBlogs =  Workshop:: 
      where('is_distinctive', 1)
      ->inRandomOrder()
      ->limit(10) 
      ->get();
      return $this->successResponse(WorkshopSimpleResource::collection($distinctiveBlogs));

  }
}
