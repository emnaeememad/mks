<?php

namespace App\Http\Controllers\Api;

use App\Models\Book;
use App\Models\Cart;
use App\Enum\OrderType;
use App\Models\Customer;
use App\Models\Workshop;
use Illuminate\Http\Request;
use App\Services\CartService;
use App\Models\WorkshopOnline;
use Illuminate\Validation\Rule;
use App\Models\PaymentMethodType;
use Illuminate\Http\JsonResponse;
use App\Factories\CartItemFactory;
use App\Services\WorkshopsService;
use Illuminate\Support\Facades\DB;
use App\Traits\CartItemTransformer;
use Illuminate\Support\Facades\Log;
use App\Services\HardCopiesCartService;
use App\Http\Controllers\ApiBaseController;
use App\Http\Resources\Api\Cart\CartResource;
use App\Bll\PaymobPaymentMethodWorkshopOnline;
use App\Http\Resources\Api\Cart\HardCopies\PhysicalCartResource;
use App\Http\Resources\Api\Workshopsonline\WorkshopOnlineFullResource;
use App\Http\Requests\Api\Workshopsonline\PurchaseWorkshopOnlineRequest;
use App\Http\Resources\Api\Workshopsonline\WorkshopOnlineSimpleResource;

class CartController extends ApiBaseController
{
    use CartItemTransformer;

    protected $cartService;
    protected $hardCopiesCartService;


    public function __construct(CartService $cartService, HardCopiesCartService $hardCopiesCartService)
    {
        $this->cartService = $cartService;
        $this->hardCopiesCartService = $hardCopiesCartService;
    }



    public function addItem(Request $request)
    {
        // Get the authenticated user's ID
        $customer = auth('sanctum')->user();
        $morphMap = [
            OrderType::book => Book::class,
            OrderType::workshoponline => WorkshopOnline::class,
            // Add more item types and their corresponding models as needed
        ];
        $itemType = $request->input('item_type');

        $model = $morphMap[$itemType] ?? null;
        $customerCart = Cart::where('customer_id', $customer->id)->first();

        if($customerCart && $customerCart?->item_type != $model){
            return $this->failResponse('لا يمكن اضافة عنصر من نوع اخر');
        }

        // Validate the request data
        $validatedData = $request->validate([
            'item_id' => [
                'required',
                function ($attribute, $value, $fail) use ($model) {
                    if (!$model || !$model::where('id', $value)->exists()) {
                        $fail("The selected $attribute is invalid.");
                    }
                },
            ],
            'item_type' => 'required|string',
            'quantity' => 'required|integer|min:1',
            'book_type' => 'nullable|string|in:digital,physical',
        ]);

        // Check if the item is already in the cart for the user
        $existingCartItem = Cart::where('customer_id', $customer->id)
            ->where('item_id', $validatedData['item_id'])
            ->where('item_type', $model) // Compare with the class name in camel case
            ->exists();

        if ($request->has('book_type')) {
            $existingCartBookItem = Cart::where('customer_id', $customer->id)
                ->where('item_id', $validatedData['item_id'])
                ->where('book_type', $validatedData['book_type'])
                ->where('item_type', $model) // Compare with the class name in camel case
                ->exists();
            if ($existingCartBookItem) {
                return $this->failResponse('العنصر مضاف بالفعل');
            }
        } else {
            if ($existingCartItem) {
                return $this->failResponse('العنصر مضاف بالفعل');
            }
        }

        // Create the appropriate item object using the factory
        $item = CartItemFactory::make($validatedData['item_type'])->findItem($validatedData['item_id']);

        $quantity = $validatedData['quantity'];
        $this->cartService->addToCart($customer, $item, $quantity, $request);

        return $this->successResponse('تم اضافة العنصر بنجاح');
    }
    public function updateQuantity(Request $request)
    {
        // Validate the request data
        $validatedData = $request->validate([
            'cart_id' => 'required|exists:cart,id',
            'quantity' => 'required|integer|min:1',
        ]);

        // Update the quantity using the CartService
        $this->cartService->updateQuantity($validatedData['cart_id'], $validatedData['quantity']);

        // Get the authenticated user's ID
        $customer = auth('sanctum')->user();
        // Retrieve all items in the cart for the user
        $cartItems = $this->cartService->getAllItems($customer->id);
        $all_quantity = $this->cartService->getAllItemsCount($customer->id);

        $total_price = $this->cartService->getTotalPricePerItemType($customer->id);
        $total_price_physical = $this->cartService->calculatePriceForPhysicalBook($customer->id);

        $fee = DB::table('additional_fees')
            ->where('min_price', '<=', $total_price_physical)
            ->where('max_price', '>=', $total_price_physical)
            ->first();

        $summary = [
            'all_quantity' => $all_quantity,
            'books_total_fee' => (float) $fee?->fee,
            'total_price' => $total_price,
            'final_total_price' => $total_price +  $fee?->fee,
        ];

        return $this->successResponse([
            'summary' => $summary
        ]);
    }

    public function removeItem(Request $request)
    {
        // Validate the request data
        $validatedData = $request->validate([
            'cart_id' => 'required|exists:cart,id',
        ]);

        // Remove the item from the cart using the CartService
        $removed = $this->cartService->removeFromCart($validatedData['cart_id']);

        if ($removed) {
            return response()->json(['message' => 'تم الحذف بنجاح']);
        } else {
            return response()->json(['error' => 'فشلت العمليه برجاء المحاولة مره اخري'], 500);
        }
    }



    public function getAllItems(Request $request)
    {
        // Get the authenticated user's ID
        $customer = auth('sanctum')->user();
        // Retrieve all items in the cart for the user
        $cartItems = $this->cartService->getAllItems($customer->id);
        $all_quantity = $cartItems->sum('quantity');

        // Group cart items by their types
        $groupedCartItems = $cartItems->groupBy('item_type');

        $total_price = $this->cartService->getTotalPricePerItemType($customer->id);
        $total_price_physical = $this->cartService->calculatePriceForPhysicalBook($customer->id);

        $fee = DB::table('additional_fees')
            ->where('min_price', '<=', $total_price_physical)
            ->where('max_price', '>=', $total_price_physical)
            ->first();

        $summary = [
            'all_quantity' => $all_quantity,
            'books_total_fee' => (float) $fee?->fee,
            'total_price' => $total_price,
            'final_total_price' => $total_price +  $fee?->fee,
        ];
        // dd( $total_price);
        // Transform grouped cart items
        $transformedCartItems = $groupedCartItems->map(function ($items, $itemType) {
            $itemTyped = $this->transformItemType($itemType);

            return [
                'item_type' => $itemTyped,
                'items' => CartResource::collection($items),

            ];
        });
        // Flatten the collection to remove outer keys
        $flattenedCartItems = $transformedCartItems->values();

        $finalResponse = [
            'cart_items' => $flattenedCartItems,
            'summary' => $summary,
        ];

        return $this->successResponse($finalResponse);
    }

    public function getHardCopiesItems(Request $request)
    {
        $customer = auth('sanctum')->user();
        $cartItems = $this->cartService->getPhysicalBookItems($customer->id);
        $total_price = $this->cartService->calculatePriceForHardCopies($cartItems);
        $fee = $this->hardCopiesCartService->getFeeForTotalPrice($total_price);

        $all_quantity = $cartItems->sum('quantity');
        $summary = [
            'all_quantity' => $all_quantity,
            'books_total_fee' => $fee,
            'total_price' => $total_price,
            'final_total_price' => $total_price +  $fee,
        ];
        $itemsResource =  PhysicalCartResource::collection($cartItems);
        return [
            'physical_book' => $itemsResource,
            'summary' => $summary,
        ];
    }


    public function getDigitalItems(Request $request)
    {
        // Get the authenticated user's ID
        $customer = auth('sanctum')->user();
        // Retrieve all items in the cart for the user
        $cartItems = $this->cartService->getAllDigitalItems($customer->id);
        $all_quantity = $cartItems->sum('quantity');

        // Group cart items by their types
        $groupedCartItems = $cartItems->groupBy('item_type');

        $total_price = $this->cartService->getTotalPricePerDigitalType($cartItems);

        $summary = [
            'all_quantity' => $all_quantity,
            'final_total_price' => $total_price,
        ];
        // Transform grouped cart items
        $transformedCartItems = $groupedCartItems->map(function ($items, $itemType) {
            $itemTyped = $this->transformItemType($itemType);

            return [
                'item_type' => $itemTyped,
                'items' => CartResource::collection($items),

            ];
        });
        // Flatten the collection to remove outer keys
        $flattenedCartItems = $transformedCartItems->values();

        $finalResponse = [
            'cart_type' => $flattenedCartItems?->first() ? $flattenedCartItems->first()['item_type'] : null,
            'cart_items' => $flattenedCartItems,
            'summary' => $summary,
        ];

        return $this->successResponse($finalResponse);
    }
}
