<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\ApiBaseController;
use App\Http\Resources\Api\Movies\MovieFullResource;
use App\Http\Resources\Api\Movies\MovieSimpleResource;
use App\Models\Movie;
use App\Services\MoviesService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MoviesController extends ApiBaseController
{
    public function __construct(
        private readonly MoviesService $moviesService
    ) {
    }

    public function getList(Request $request): JsonResponse
    {
        $movies = $this->moviesService->getFiltered($request, 'mobile');

        return $this->successResponse([
            'movies' => MovieSimpleResource::collection($movies->items()),
            'next' => $movies->hasMorePages(),
            'total' => $movies->total(),
        ]);
    }

    public function getMovie(int $id): JsonResponse
    {
        $movie = $this->moviesService->getMovieDetails($id);

        return $this->successResponse(MovieFullResource::make($movie));
    }

    public function eventShare(int $id): JsonResponse
    {
        $this->moviesService->eventShare($id);

        return $this->successResponse([]);
    }

    public function eventView(int $id): JsonResponse
    {
        $this->moviesService->eventView($id);

        return $this->successResponse([]);
    }

 
    public function getDistinctiveMovies() {
        $distinctiveBlogs =  Movie::published()
       ->where('is_distinctive', 1)
      ->inRandomOrder()
      ->limit(10) 
      ->get();
      return $this->successResponse(MovieSimpleResource::collection($distinctiveBlogs));

  }
}
