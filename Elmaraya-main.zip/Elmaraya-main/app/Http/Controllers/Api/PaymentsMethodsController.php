<?php

namespace App\Http\Controllers\Api;

use App\Models\Book;
use App\Models\Category;
use App\Models\Customer;
use App\Models\Shipping;
use App\Models\BookRequest;
use App\Models\BookPurchase;
use App\Models\Subscription;
use Illuminate\Http\Request;
use App\Enum\CategoryModules;
use App\Models\WorkshopOnline;
use App\Services\BooksService;
use App\Models\PaymentMethodType;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use App\Models\CustomerSubscription;
use App\Models\WorkshoponlinePurchase;
use App\Services\PaymentMethodService;
use Illuminate\Database\QueryException;
use App\Bll\HardCopyPaymobPaymentMethod;
use App\Bll\SubscribePaymobPaymentMethod;
use App\Http\Resources\Api\MyBookResource;
use App\Http\Controllers\ApiBaseController;
use App\Http\Resources\Api\ShippingResource;
use App\Bll\PaymobPaymentMethodWorkshopOnline;
use App\Services\Api\Books\CustomerBookService;
use App\Http\Requests\Api\Books\HardCopyRequest;
use App\Http\Requests\Api\Books\PurchaseRequest;
use App\Http\Resources\Api\PaymentMethodResource;
use App\Http\Resources\Api\Books\BookFullResource;
use App\Http\Resources\Api\Books\BookSimpleResource;
use App\Http\Requests\Api\Subscribe\SubscribeRequest;
use App\Http\Resources\Api\PaymentMethodTypesResource;
use App\Http\Resources\Api\Books\BookSimpleAllResource;
use App\Http\Resources\Api\Books\BookSimpleSubResource;
use App\Http\Resources\Api\Books\SubscriptionsResource;
use App\Http\Resources\Api\Purchasedbooks\BookResource;
use App\Http\Resources\Api\Books\BookSimpleBurchasedResource;
use App\Http\Resources\Api\Categories\Books\CategoryResource;

class PaymentsMethodsController extends ApiBaseController
{
    public function __construct(
        private readonly CustomerBookService $customerBookService,
        private readonly BooksService $booksService,
        private readonly PaymentMethodService $paymentMethodService,
    ) {
    }

    public function index(): JsonResponse
    {
        $paymentMethods = $this->paymentMethodService->getAllPaymentMethods();

          return $this->successResponse(PaymentMethodResource::collection($paymentMethods));
    }

    public function getPaymobTypes()  {
        $paymentMethodsTypes = PaymentMethodType::get();
        return $this->successResponse(PaymentMethodTypesResource::collection($paymentMethodsTypes));
    }
 
}
