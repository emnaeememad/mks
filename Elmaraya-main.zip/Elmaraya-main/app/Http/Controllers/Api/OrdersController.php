<?php

namespace App\Http\Controllers\Api;

use App\Models\Book;
use App\Enum\BookType;
use App\Models\Orders;
use App\Enum\OrderType;
use App\Models\Category;
use App\Models\Customer;
use App\Models\Shipping;
use App\Enum\PaymentSlugs;
use App\Models\BookRequest;
use App\Models\OrdersBooks;
use App\Models\BookPurchase;
use App\Models\Subscription;
use Illuminate\Http\Request;
use App\Enum\CategoryModules;
use App\Models\PaymentMethod;
use App\Services\CartService;
use App\Models\WorkshopOnline;
use App\Services\BooksService;
use App\Models\ShippingDetails;
use App\Models\PaymentMethodType;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Models\CustomerSubscription;
use App\Models\WorkshoponlinePurchase;
use App\Services\PaymentMethodService;
use App\Factories\PaymentMethodFactory;
use Illuminate\Database\QueryException;
use App\Bll\HardCopyPaymobPaymentMethod;
use App\Bll\SubscribePaymobPaymentMethod;
use App\Http\Resources\Api\MyBookResource;
use App\Http\Controllers\ApiBaseController;
use App\Http\Requests\Api\Books\CODRequest;
use App\Integrations\Payments\Paymob\Order;
use App\PaymentMethods\PaymobPaymentMethod;
use App\Http\Resources\Api\ShippingResource;
use App\Bll\PaymobPaymentMethodWorkshopOnline;
use App\Services\Api\Books\CustomerBookService;
use App\Http\Requests\Api\Books\HardCopyRequest;
use App\Http\Requests\Api\Books\PurchaseRequest;
use App\Http\Resources\Api\PaymentMethodResource;
use App\Http\Resources\Api\Books\BookFullResource;
use App\Http\Resources\Api\Books\BookSimpleResource;
use App\Http\Requests\Api\Subscribe\SubscribeRequest;
use App\Http\Resources\Api\PaymentMethodTypesResource;
use App\Http\Resources\Api\Books\BookSimpleAllResource;
use App\Http\Resources\Api\Books\BookSimpleSubResource;
use App\Http\Resources\Api\Books\SubscriptionsResource;
use App\Http\Resources\Api\Purchasedbooks\BookResource;
use App\Http\Resources\Api\Books\BookSimpleBurchasedResource;
use App\Http\Resources\Api\Categories\Books\CategoryResource;
use App\Models\Cart;

class OrdersController extends ApiBaseController
{
    public function __construct(
        private readonly CustomerBookService $customerBookService,
        private readonly BooksService $booksService,
        private readonly PaymentMethodService $paymentMethodService,
        private readonly CartService $cartService,
    ) {
    }

    public function purchase(PurchaseRequest $request)
    {

        $payment_paymob_type = PaymentMethodType::findOrFail($request->payment_type_id);
        $payment_paymob_type->integration_id;
        $iframe_id_or_wallet_number = $payment_paymob_type->iframe_id;
        $integration_id = $payment_paymob_type->integration_id;
        $paymob_type = $payment_paymob_type->type;
        $iframe_id_or_wallet_number = $payment_paymob_type->iframe_id;

        if ($payment_paymob_type->type == 'wallet') {
            $iframe_id_or_wallet_number = $payment_paymob_type->iframe_id ?? '01010101010';
        }

        // try {
        //     // Check if the book exists
        //     Book::findOrFail($bookId);
        // } catch (\Exception $ex) {
        //     // Handle the case where the book does not exist
        //     Log::error($ex);
        //     return $this->failResponse(__('api.book-not-found'));
        // }

        try {
            $customer = auth('sanctum')->user();
            ($customer->load('bookPurchases'));
            // if ($customer->hasPurchasedBook($bookId)) {
            //     return $this->failResponse(__('api.book-already-purchased'));
            // }
        } catch (\Exception $ex) {
            // Handle any exceptions here
            Log::error($ex);
            return $this->failResponse(__('api.payment-failed'));
        }
        $paymentId = $request->payment_id;
        // get the total that will be sent to payment gateway
        $total_price =  $this->cartService->getTotalPricePerItemType($customer->id);

        if($total_price  == 0){
            return $this->failResponse(__('api.cart-is-empty-or-something-went-wrong'));
        }
        
        $parameters = [
            'integration_id' => $integration_id,
            'paymob_type' => $paymob_type,
            'iframe_id_or_wallet_number' => $iframe_id_or_wallet_number,
            'request' => $request,
        ];

        $paymentMethod = PaymentMethodFactory::create(
            $total_price,
            $paymentId,
            $parameters
        );

        $url = $paymentMethod->checkingOut();

        if ($url == false) {
            return $this->failResponse();
        }
        Cart::where('customer_id', $customer->id)->delete();
        return $this->successResponse($url, __('api.book-purchase'));
    }
    /// callback for both subscription

    public function callback(Request $request)
    {
        $iframe_id_or_wallet_number = $request->iframe_id;
        $integration_id = $request->integration_id;
        $paymob_type = $request->type ?? 'default';
        $orders = Orders::where('gateway_tracking', $request->order)->get();

        foreach ($orders as $order) {
            // for testing i will suggest it is false to make operations
            if ($request->success !== "true") {
                $order->update([
                    'status' => 'purchased',
                ]);
                return $this->successResponse([], __('api.request-done'));
                // return (new CheckoutController)->checkout_done($request->merchant_order_id, $payment_details);
            } else {
                return $this->successResponse([], __('api.request-failed'));
            }
        }


        $bookRequest = BookRequest::where('gateway_tracking', $request->order)->first();
        if ($bookRequest) {
            $gateway_tracking = $bookRequest->gateway_tracking;
            $paymob = new HardCopyPaymobPaymentMethod($bookRequest->id, $gateway_tracking,  $integration_id, $paymob_type, $iframe_id_or_wallet_number, $request);
            $paymob->callback($request, $bookRequest);
            return;
        }
    }

    public function purchaseByCOD(CODRequest $request)
    {
        try {
            DB::beginTransaction();

            $customer = auth('sanctum')->user();
            $cartItems = $this->cartService->getPhysicalBookItems($customer->id);


            if ($cartItems->isEmpty()) {
                return $this->failResponse(__('api.cart-is-empty'));
            }
            $payment = PaymentMethod::where('slug', PaymentSlugs::cash)->first();

            $orderbook =  Orders::create([
                'customer_id' => $customer->id,
                'payment_id'      => $payment->id,
                'gateway_tracking'      => rand(1000, 9999),
                'status' => 'pending',
                'order_type' => OrderType::book,
                'book_type' => BookType::physical
            ]);

            $data = $request->validated();
            $data['order_id'] = $orderbook->id;
            ShippingDetails::create($data);


            $shipping = Shipping::find($request->shipping_id);


            //TDO total_price + shipping price + (Range of books price in cart) + clear cart + create Notify
            $cartIds = [];
            $total_price = 0;
            foreach ($cartItems as $physicalItem) {
                $book = Book::find($physicalItem->item_id);
                $cartIds[] = $physicalItem->id;
                $total_price += $book->hard_copy_price * $physicalItem->quantity;

                OrdersBooks::create([
                    'price' => $book->hard_copy_price,
                    'quantity' => $physicalItem->quantity,
                    'book_id' => $book->id,
                    'order_id' => $orderbook->id,
                ]);
                $book->update(['total_hard_purchased' => $book->total_hard_purchased + 1]);
            }

            $fee = DB::table('additional_fees')
                ->where('min_price', '<=', $total_price)
                ->where('max_price', '>=', $total_price)
                ->first();


            $total_price += $shipping->price;

            if ($fee) {
                $total_price += $fee->fee; // Assuming the fee column in the additional_fees table holds the fee amount
                // Update the orderbook with the total_price and the additional_fee_id
                $orderbook->update([
                    'total_price' => $total_price,
                    'additional_fee_id' => $fee->id, // Save the additional_fee_id to the orders table
                ]);
            } else {
                $orderbook->update([
                    'total_price' => $total_price,
                ]);
            }

            $this->cartService->clearCartById($cartIds);
            DB::commit();

            return $this->successResponse([], __('api.request-done'));
        } catch (\Exception $e) {
            DB::rollback();
            return $this->failResponse($e->getMessage(), __('api.request-error'));
        }
    }

    
}
