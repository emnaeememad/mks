<?php

namespace App\Http\Controllers\Api;

use App\Models\Book;
use App\Models\Author;
use App\Models\Orders;
use App\Models\Category;
use App\Models\Customer;
use App\Models\Shipping;
use App\Models\BookRequest;
use App\Models\BookPurchase;
use App\Models\Subscription;
use Illuminate\Http\Request;
use App\Enum\CategoryModules;
use App\Services\CartService;
use App\Models\WorkshopOnline;
use App\Services\BooksService;
use App\Models\PaymentMethodType;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use App\Models\CustomerSubscription;
use App\Models\WorkshoponlinePurchase;
use App\Services\PaymentMethodService;
use Illuminate\Database\QueryException;
use App\Bll\HardCopyPaymobPaymentMethod;
use App\Bll\SubscribePaymobPaymentMethod;
use App\Http\Resources\Api\MyBookResource;
use App\Integrations\Payments\Paymob\Auth;
use App\Http\Controllers\ApiBaseController;
use App\PaymentMethods\PaymobPaymentMethod;
use App\Http\Resources\Api\ShippingResource;
use App\Bll\PaymobPaymentMethodWorkshopOnline;
use App\Services\Api\Books\CustomerBookService;
use App\Http\Requests\Api\Books\HardCopyRequest;
use App\Http\Requests\Api\Books\PurchaseRequest;
use App\Http\Resources\Api\PaymentMethodResource;
use App\Http\Resources\Api\Books\BookFullResource;
use App\Http\Resources\Api\Books\BookSimpleResource;
use App\Http\Requests\Api\Subscribe\SubscribeRequest;
use App\Http\Resources\Api\PaymentMethodTypesResource;
use App\Http\Resources\Api\Books\BookSimpleAllResource;
use App\Http\Resources\Api\Books\BookSimpleSubResource;
use App\Http\Resources\Api\Books\SubscriptionsResource;
use App\Http\Resources\Api\Purchasedbooks\BookResource;
use App\Http\Resources\Api\Books\BookSimpleBurchasedResource;
use App\Http\Resources\Api\Categories\Books\CategoryResource;
use App\Http\Resources\Api\Books\HousePublisher\HousePublisherResource;

class BooksController extends ApiBaseController
{
    public function __construct(
        private readonly CustomerBookService $customerBookService,
        private readonly BooksService $booksService,
        private readonly PaymentMethodService $paymentMethodService,
        private readonly CartService $cartService,
    ) {
    }

    public function myBooks(Request $request): JsonResponse
    {
        $customerBooks = $this->customerBookService->getBooks(auth('sanctum')->user(), $request);

        return $this->successResponse([
            'books' => MyBookResource::collection($customerBooks->items()),
            'next' => $customerBooks->hasMorePages(),
            'total' => $customerBooks->total(),
        ]);
    }

    // public function mostSold(Request $request): JsonResponse
    // {
    //     $books = $this->booksService->getMostSold($request);

    //     return $this->successResponse([
    //         'books' => BookSimpleResource::collection($books->items()),
    //         'next' => $books->hasMorePages(),
    //         'total' => $books->total(),
    //     ]);
    // }

    public function all(Request $request): JsonResponse
    {
        // Get the filtered books
        $books = $this->booksService->getFilteredAll($request);

        return $this->successResponse([
            'books' => BookSimpleResource::collection($books->items()),
            'next' => $books->hasMorePages(),
            'total' => $books->total(),
        ]);
    }

    public function getRequestTypeAllbooks(Request $request): JsonResponse
    {
        // Get the filtered books
        $books = $this->booksService->getFilteredAll($request);

        return $this->successResponse([
            'books' => BookSimpleAllResource::collection($books->items()),
            'next' => $books->hasMorePages(),
            'total' => $books->total(),
        ]);
    }

    // public function neddSubscription(Request $request)
    // {
    //     $customerBooks = $this->customerBookService->getBooksNeedSub(auth('sanctum')->user(), $request);

    //     return $this->successResponse([
    //         'books' => BookSimpleSubResource::collection($customerBooks->items()),
    //         'next' => $customerBooks->hasMorePages(),
    //         'total' => $customerBooks->total(),
    //     ]);
    // }

    public function neddSubscription(Request $request)
    {
        $companies = Author::companies()
            ->with([
                'booksHouseFeatured' => function ($query) {
                    $query->published()->requestTypeSubscription()
                        ->isDistinctive();
                },
                'booksHouse' => function ($query) {
                    $query->published()->requestTypeSubscription();
                },
            ])
            ->when($request->has('publisher_house_id'), function ($query) use ($request) {
                $publisherHouseId = $request->input('publisher_house_id');
                $query->orderByRaw("CASE WHEN id = $publisherHouseId THEN 0 ELSE 1 END, main DESC");
            })
            ->orderByDesc('main')

            ->paginate(10);

        return $this->successResponse(
            HousePublisherResource::collection($companies)
        );


        // $customerBooks = $this->customerBookService->getBooksNeedSub(auth('sanctum')->user(), $request);

        // return $this->successResponse([
        //     'books' => BookSimpleSubResource::collection($customerBooks->items()),
        //     'next' => $customerBooks->hasMorePages(),
        //     'total' => $customerBooks->total(),
        // ]);
    }

    public function needPurchased(Request $request)
    {
        $customerBooks = $this->customerBookService->getBooksNeedBurch(auth('sanctum')->user(), $request);

        return $this->successResponse([
            'books' => BookSimpleBurchasedResource::collection($customerBooks->items()),
            'next' => $customerBooks->hasMorePages(),
            'total' => $customerBooks->total(),
        ]);
    }

    public function show(int $id): JsonResponse
    {
        $book = $this->booksService->getBookDetails($id);

        return $this->successResponse(BookFullResource::make($book));
    }

    // public function hardCopy(HardCopyRequest $request, int $id): JsonResponse
    // {
    //     $this->booksService->hardCopy($request, $id);

    //     return $this->successResponse([], __('api.book-hard-copy'));
    // }

    // public function purchase(PurchaseRequest $request, int $id): JsonResponse
    // {
    //     try {

    //         $links = $this->booksService->purchase($request, auth('sanctum')->user(), $id);
    //         return $this->successResponse($links, __('api.book-purchase'));
    //     } catch (QueryException $ex) {
    //         // Log the exception or handle it as needed
    //         Log::error('QueryException occurred during book purchase: ' . $ex );

    //         // Return an error response
    //         return $this->failResponse(__('api.internal-server-error'), 500);
    //     } catch (\Exception $ex) {
    //         // Log the exception or handle it as needed
    //         Log::error('Exception occurred during book purchase: ' . $ex );

    //         // Return an error response
    //         return $this->failResponse(__('api.internal-server-error'), 500);
    //     }
    // }

    public function eventShare(int $id): JsonResponse
    {
        $this->booksService->eventShare($id);

        return $this->successResponse([]);
    }

    public function eventView(int $id): JsonResponse
    {
        $this->booksService->eventView($id);

        return $this->successResponse([]);
    }


    // public function purchase(PurchaseRequest $request, int $id): JsonResponse
    // {
    //     $links = $this->booksService->purchase($request, auth('sanctum')->user(), $id);

    //     return $this->successResponse($links, __('api.book-purchase'));
    // } 

    public function purchase(PurchaseRequest $request, $bookId)
    {

        $payment_paymob_type = PaymentMethodType::findOrFail($request->payment_type_id);
        $payment_paymob_type->integration_id;
        $iframe_id_or_wallet_number = $payment_paymob_type->iframe_id;
        $integration_id = $payment_paymob_type->integration_id;
        $paymob_type = $payment_paymob_type->type;
        $iframe_id_or_wallet_number = $payment_paymob_type->iframe_id;

        if ($payment_paymob_type->type == 'wallet') {
            $iframe_id_or_wallet_number = $payment_paymob_type->iframe_id ?? '01010101010';
        }

        try {
            // Check if the book exists
            Book::findOrFail($bookId);
        } catch (\Exception $ex) {
            // Handle the case where the book does not exist
            Log::error($ex);
            return $this->failResponse(__('api.book-not-found'));
        }

        try {
            $customer = auth()->user();
            ($customer->load('bookPurchases'));
            if ($customer->hasPurchasedBook($bookId)) {
                return $this->failResponse(__('api.book-already-purchased'));
            }
        } catch (\Exception $ex) {
            // Handle any exceptions here
            Log::error($ex);
            return $this->failResponse(__('api.payment-failed'));
        }
        $paymentId = $request->payment_id;
        $paymob = new PaymobPaymentMethod($bookId, $paymentId,  $integration_id, $paymob_type, $iframe_id_or_wallet_number);
        $url = $paymob->checkingOut();
        if ($url == false) {
            return $this->failResponse();
        }
        return $this->successResponse($url, __('api.book-purchase'));
    }
    /// callback for both subscription

    public function callback(Request $request)
    {
        $iframe_id_or_wallet_number = $request->iframe_id;
        $integration_id = $request->integration_id;
        $paymob_type = $request->type ?? 'default';
        $orders = Orders::where('gateway_tracking', $request->order)->get();
        if ($orders->isNotEmpty()) {
            if ($request->success !== "true") {
                foreach ($orders as $order) {
                    $order->update([
                        'status' => 'purchased',
                    ]);
                }
                // clear the cart after the purchased items was done
                $this->cartService->clearCart($orders->first()?->customer_id);
                return;
                // return $this->successResponse([], __('api.request-done'));
            } else {
                return $this->successResponse([], __('api.request-failed'));
            }
        }

        $subscription = CustomerSubscription::where('gateway_tracking', $request->order)->first();

        if ($subscription) {
            $gateway_tracking = $subscription->gateway_tracking;
            $paymob = new SubscribePaymobPaymentMethod($subscription->id, $gateway_tracking,  $integration_id, $paymob_type, $iframe_id_or_wallet_number);
            $paymob->callback($request, $subscription);
            return;
        }
        $bookRequest = BookRequest::where('gateway_tracking', $request->order)->first();
        if ($bookRequest) {
            $gateway_tracking = $bookRequest->gateway_tracking;
            $paymob = new HardCopyPaymobPaymentMethod($bookRequest->id, $gateway_tracking,  $integration_id, $paymob_type, $iframe_id_or_wallet_number, $request);
            $paymob->callback($request, $bookRequest);
            return;
        }
    }

    public function paymentMethods(int $id): JsonResponse
    {
        $paymentMethods = $this->paymentMethodService->getBooksPaymentMethods();

        return $this->successResponse(PaymentMethodResource::collection($paymentMethods));
    }

    public function paymentMethodsTypes()
    {
        $paymentMethodsTypes = PaymentMethodType::paginate(10);
        return $this->successResponse(PaymentMethodTypesResource::collection($paymentMethodsTypes));
    }

    public function getPurchasedBooks(Request $request)
    {
        $customer = auth()->user();
        $customer->load('bookPurchases');
        return $this->successResponse(BookResource::collection($customer->purchasedBooksAll()));
    }

    ///getDistinctiveBooks

    public function getDistinctiveBooks()
    {
        $distinctiveBooks =  Book::published()
            ->where('is_distinctive', 1)
            ->inRandomOrder()
            ->limit(10)
            ->get();
        return $this->successResponse(BookSimpleResource::collection($distinctiveBooks));
    }


    public function  getPaymobTypes()
    {

        $paymentMethodsTypes = PaymentMethodType::paginate(10);
        return $this->successResponse(PaymentMethodTypesResource::collection($paymentMethodsTypes));
    }

    public function subscribe(SubscribeRequest $request)
    {

        $payment_paymob_type = PaymentMethodType::findOrFail($request->payment_type_id);
        $payment_paymob_type->integration_id;
        $iframe_id_or_wallet_number = $payment_paymob_type->iframe_id;
        $integration_id = $payment_paymob_type->integration_id;
        $paymob_type = $payment_paymob_type->type;
        $iframe_id_or_wallet_number = $payment_paymob_type->iframe_id;

        if ($payment_paymob_type->type == 'wallet') {
            $iframe_id_or_wallet_number = $payment_paymob_type->iframe_id ?? '01010101010';
        }

        try {
            // Check if the book exists
            Subscription::findOrFail($request->subscription_id);
        } catch (\Exception $ex) {
            // Handle the case where the book does not exist
            Log::error($ex);
            return $this->failResponse(__('api.subscription-not-found'));
        }

        try {
            $customer = auth('sanctum')->user();
            $isCustomerHasActiveSubscription = $customer->customerSubscriptions()->active()->exists();

            if ($isCustomerHasActiveSubscription) {
                return $this->failResponse(__('api.customer-already-subscribe'));
            }
        } catch (\Exception $ex) {
            // Handle any exceptions here
            Log::error($ex);
            return $this->failResponse(__('api.payment-failed'));
        }
        $paymentId = $request->payment_id;
        $paymob = new SubscribePaymobPaymentMethod($request->subscription_id, $paymentId,  $integration_id, $paymob_type, $iframe_id_or_wallet_number);
        $url = $paymob->checkingOut();
        if ($url == false) {
            return $this->failResponse();
        }
        return $this->successResponse($url, __('api.customer-subscribe'));
    }

    public function  getSubscriptions()
    {
        $subscriptions = Subscription::descOrder()->paginate(3);
        return $this->successResponse(SubscriptionsResource::collection($subscriptions));
    }

    public function getShippingLocations()
    {
        $shipping = Shipping::get();
        return $this->successResponse(ShippingResource::collection($shipping));
    }


    public function hardCopy(HardCopyRequest $request, $bookId)
    {

        $payment_paymob_type = PaymentMethodType::findOrFail($request->payment_type_id);
        $payment_paymob_type->integration_id;
        $iframe_id_or_wallet_number = $payment_paymob_type->iframe_id;
        $integration_id = $payment_paymob_type->integration_id;
        $paymob_type = $payment_paymob_type->type;
        $iframe_id_or_wallet_number = $payment_paymob_type->iframe_id;

        if ($payment_paymob_type->type == 'wallet') {
            $iframe_id_or_wallet_number = $payment_paymob_type->iframe_id ?? '01010101010';
        }

        try {
            // Check if the book exists
            Book::findOrFail($bookId);
        } catch (\Exception $ex) {
            // Handle the case where the book does not exist
            Log::error($ex);
            return $this->failResponse(__('api.book-not-found'));
        }

        try {
            $customer = auth()->user();
            ($customer->load('bookPurchases'));
            if ($customer->hasPurchasedBook($bookId)) {
                return $this->failResponse(__('api.book-already-purchased'));
            }
        } catch (\Exception $ex) {
            // Handle any exceptions here
            Log::error($ex);
            return $this->failResponse(__('api.payment-failed'));
        }
        $paymentId = $request->payment_id;
        $paymob = new HardCopyPaymobPaymentMethod(
            $bookId,
            $paymentId,
            $integration_id,
            $paymob_type,
            $iframe_id_or_wallet_number,
            $request
        );
        $url = $paymob->checkingOut();
        if ($url == false) {
            return $this->failResponse();
        }
        return $this->successResponse($url, __('api.book-purchase'));
    }


    public function getCategory(Request $request)
    {

        $categories = Category::with(['children.books', 'books'])->canBeParent()
            ->where('module', CategoryModules::books)->where('is_active', 1)
            ->get();

        return $this->successResponse(CategoryResource::collection($categories));
    }

    // function to get the houser publisher with subscription books of it
    public function getHousePublisher()
    {
        $companies = Author::companies()
            ->with([
                'booksHouse' => function ($query) {
                    $query->published()->requestTypeSubscription();
                },
            ])
            ->orderByDesc('main')
            ->paginate(10);

        return $this->successResponse(
            HousePublisherResource::collection($companies)
        );
    }

    // function to get the  subscription books

    public function getSubscription(Request $request)
    {
        $customerBooks = $this->customerBookService->getBooksNeedSub(auth('sanctum')->user(), $request);

        return $this->successResponse([
            'books' => BookSimpleSubResource::collection($customerBooks->items()),
        ]);
    }
    // function to fine the susbscribtion books but they are featured
    public function getsubscriptionFeatures(Request $request)
    {
        $customerBooks = $this->customerBookService->getDistinctiveBooksNeedSub(auth('sanctum')->user(), $request);

        return $this->successResponse([
            'books' => BookSimpleSubResource::collection($customerBooks->items()),
        ]); 
    }
}
