<?php

namespace App\Http\Controllers\Landing;


use App\Models\Customer;
use App\Traits\AppSettings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    use AppSettings;

    // Not work right now on portal
    public function  signup(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'namesignup' => 'required|string|max:255|unique:customers,name',
                'emailsignup' => 'required|string|email|max:255|unique:customers,email',
                'passwordsignup' => 'required|string|min:6',
            ]);

            if ($validator->fails()) {
                return response()->json(['errors' => $validator->errors()], 422);
            }

            // Create new Customer
            $customer = Customer::create([
                'name' => $request->namesignup,
                'email' => $request->emailsignup,
                'password' => ($request->passwordsignup), // in model hashed
            ]);
            // Log in the user after successful registration
            Auth::login($customer);
            // Additional logic if needed
            return response()->json(['message' => 'تم تسجيل الحساب بنجاح'], 200);
        } catch (\Exception $ex) {
            Log::error($ex);
            return response()->json(['message' => 'حدث خطأ أثناء معالجة الطلب'], 500);
        }
    }

    public function login(Request $request)
    {
        try {
            // Validate the request data
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'password' => 'required',
            ]);

            if ($validator->fails()) {
                // Return validation error response
                return response()->json(['message' => 'الرجاء إدخال بيانات صحيحة'], 422);
            }

            $credentials = $request->only('email', 'password');

            // Attempt to authenticate the user
            if (Auth::guard('web')->attempt($credentials)) {
                // Authentication successful
                return response()->json(['message' => 'تم تسجيل الدخول بنجاح'], 200);
            } else {
                // Authentication failed
                return response()->json(['message' => 'البريد الإلكتروني أو كلمة المرور غير صحيحة'], 401);
            }
        } catch (\Exception $ex) {
            Log::error($ex);
            return response()->json(['message' => 'حدث خطأ أثناء معالجة الطلب'], 500);
        }
    }

    public function logout(Request $request)
    {
        try {
            Auth::logout();

            // Clear the session data
            $request->session()->invalidate();

            // Regenerate the CSRF token
            $request->session()->regenerateToken();

            return response()->json(['message' => 'تم تسجيل الخروج بنجاح'], 200);
        } catch (\Exception $ex) {
            Log::error($ex);
            return response()->json(['message' => 'حدث خطأ أثناء تسجيل الخروج'], 500);
        }
    }
}
