<?php

namespace App\Http\Controllers\Landing;


use App\Models\Customer;
use App\Traits\AppSettings;
use Illuminate\Http\Request;
use App\Services\BooksService;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AccountDetailsController extends Controller
{
    use AppSettings;
    public function __construct(
        private BooksService $booksService,
      
    ) {
    }
    /**
     * Display the account details of the logged-in customer.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        // Get the authenticated user
        $customer = Auth::user();

        // Check if the user is a customer
        if (!$customer instanceof Customer) {
            // If not a customer, return an Unauthorized error response
            abort(401, 'Unauthorized');
        }
        $app_settings = $this->app_settings();
        $customer = auth()->user();
        $customer->load('bookPurchases');
        $mybooks = $customer->purchasedBooksAll();
 
         // Return the account details of the customer
        return view('landing.account.show', compact('app_settings', 'customer', 'mybooks'));
    }

    /**
     * Update the account details of the logged-in customer.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Get the authenticated user
        $customer = Auth::user();

        // Check if the user is a customer
        if (!$customer instanceof Customer) {
            // If not a customer, return an error response
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        // Validate the request data
        $validator = Validator::make($request->all(), [
            'name' => 'sometimes|string|max:255',
            'email' => 'sometimes|string|email|max:255|unique:customers,email,' . $customer->id,
            'password' => 'sometimes|string|min:8|confirmed',
        ]);

        // If validation fails, return the errors
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // Update the account details if provided in the request
        if ($request->has('name')) {
            $customer->name = $request->name;
        }
        if ($request->has('email')) {
            $customer->email = $request->email;
        }
        if ($request->has('password')) {
            $customer->password = Hash::make($request->password);
        }

        // Save the changes
        $customer->save();

        // Return a success response
        return response()->json(['message' => 'Account details updated successfully', 'account_details' => $customer]);
    }

    /**
     * Update the image of the customer.
     *
     * @param  \Illuminate\Http\UploadedFile  $image
     * @param  \App\Models\Customer  $customer
     * @return void
     */
    public function updateImage($image, $customer)
    {
        // Delete old image if exists
        if ($customer->image) {
            Storage::delete($customer->image);
        }

        // Store new image
        $imagePath = $image->store('customer_images');

        // Update the image path in the customer model
        $customer->image = $imagePath;
    }
}
