<?php

namespace App\Http\Controllers\Landing;

use App\Enum\BlogModules;
use App\Enum\SearchPages;
use App\Http\Controllers\Controller;
use App\Services\AuthorService;
use App\Services\BlogModulesService;
use App\Services\BooksService;
use App\Services\MoviesService;
use App\Services\NadaraService;
use App\Services\StoriesService;
use App\Services\WorkshopsService;
use App\Traits\AppSettings;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    use AppSettings;

    public function __construct(
        private BooksService $booksService,
        private BlogModulesService $blogModulesService,
        private StoriesService $storiesService,
        private MoviesService $moviesService,
        private WorkshopsService $workshopsService,
        private NadaraService $nadara,
        private AuthorService $author,
    ) {
    }

    public function search(Request $request): View
    {
        $searchPage = $request->get('search_page');
        if (! in_array($searchPage, SearchPages::getPages())) {
            $searchPage = null;
        }

        $request->merge(['search' => $request->get('search_keyword')]);

        $collection = null;
        $view = 'landing.search.empty-page';

        switch ($searchPage) {
            case SearchPages::blogs:
                $collection = $this->blogModulesService->getFiltered(BlogModules::blogs, $request);
                $view = 'landing.search.blogs';
                $pageTitle = __('landing/home.blogs');
                break;
            case SearchPages::books:
                $collection = $this->booksService->getFiltered($request);
                $view = 'landing.search.books';
                $pageTitle = __('landing/home.books');
                break;
            case SearchPages::stories:
                $collection = $this->storiesService->getFiltered($request);
                $view = 'landing.search.stories';
                $pageTitle = __('landing/home.stories');
                break;
            case SearchPages::movies:
                $collection = $this->moviesService->getFiltered($request);
                $view = 'landing.search.movies';
                $pageTitle = __('landing/home.movies');
                break;
            case SearchPages::workshops:
                $collection = $this->workshopsService->getFiltered($request);
                $view = 'landing.search.workshops';
                $pageTitle = __('landing/home.workshops');
                break;
            case SearchPages::nadara:
                $collection = $this->nadara->getFiltered($request);
                $view = 'landing.search.nadara';
                $pageTitle = __('landing/home.nadara');
                break;
            case SearchPages::authors:
                $collection = $this->author->getFiltered($request);
                $view = 'landing.search.authors';
                $pageTitle = __('landing/home.authors');
                break;
            case SearchPages::all:
                $collection = [
                    'blogs' => $this->blogModulesService->getFiltered(BlogModules::blogs, $request),
                    'books' => $this->booksService->getFiltered($request),
                    'stories' => $this->storiesService->getFiltered($request),
                    'movies' => $this->moviesService->getFiltered($request),
                    'workshops' => $this->workshopsService->getFiltered($request),
                    'nadara' => $this->nadara->getFiltered($request),
                    'authors' => $this->author->getFiltered($request)
                ];
                $view = 'landing.search.all';
                $pageTitle = __('landing/home.all');
                break;
        }
        return view($view, [
            'app_settings' => $this->app_settings(),
            'searchEnable' => true,
            'searchCategories' => SearchPages::getPagesTranslated(),
            'searchPage' => $searchPage,
            'collection' => $collection,
            'pageTitle' => $pageTitle,
        ]);
    }
}
