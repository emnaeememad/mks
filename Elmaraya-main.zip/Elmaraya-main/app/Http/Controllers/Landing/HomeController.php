<?php

namespace App\Http\Controllers\Landing;

use Exception;
use App\Models\Book;
use App\Models\Author;
use App\Models\Nadara;
use App\Models\Category;
use App\Models\HomeHtml;
use App\Models\TeamWork;
use App\Models\Workshop;
use App\Enum\AuthorTypes;
use App\Enum\BlogModules;
use App\Enum\NadaraTypes;
use App\Enum\SearchPages;
use App\Models\ContactUs;
use App\Enum\WritingTypes;
use App\Models\BookRequest;
use App\Models\MarayaAbout;
use App\Traits\AppSettings;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Enum\CategoryModules;
use App\Services\HomeService;
use App\Services\BooksService;
use App\Models\WorkshopRequest;
use App\Services\MoviesService;
use App\Services\NadaraService;
use App\Services\StoriesService;
use App\Models\HomeRelatedModels;
use App\Services\WorkshopsService;
use Illuminate\Support\Facades\DB;
use App\Services\BreadcrumbService;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Services\BlogModulesService;
use App\Services\MarayaBooksService;
use Illuminate\Support\Facades\Cookie;
use App\Models\WorkshopRequestAttachment;
use Illuminate\Database\Eloquent\Collection;
use App\Http\Requests\LandingPage\ContactUs\ContactUsRequest;
use App\Http\Requests\LandingPage\BookRequest\BookHardCopyRequest;
use App\Http\Requests\LandingPage\Workshop\ApplyForWorkshopRequest;

class HomeController extends Controller
{
    use AppSettings;

    public function __construct(
        private BlogModulesService $blogModulesService,
        private StoriesService $storiesService,
        private BooksService $booksService,
        private MoviesService $moviesService,
        private WorkshopsService $workshopsService,
        private HomeService $homeService,
        private MarayaBooksService $marayaBooksService,
        private NadaraService $nadaraService
    ) {
    }

public function home(): View
{
    $sliders = collect([]);

    $this->blogModulesService->getHomeSlider(BlogModules::blogs, 4, 'web')->each(function ($blog) use (&$sliders) {
        $sliders->push([
            'type' => 'blog',
            'date' => $blog->post_date,
            'url' => route('landingPage.blogs.show', ['slug' => $blog->slug_translated, 'lang' => app()->getLocale()]),
            'image' => $blog->main_image_url,
            'category' => $blog?->category->name_translated,
            'author' => $blog?->author->name_translated,
            'title' => Str::words($blog['small_title'], 7, ' ...'),
        ]);
    });

    $this->storiesService->getHomeSlider(4, 'web')->each(function ($story) use (&$sliders) {
        $sliders->push([
            'type' => 'story',
            'date' => $story->post_date,
            'url' => route('landingPage.story.show', ['lang' => app()->getLocale(), 'slug' => $story->slug_translated]),
            'image' => $story->main_image_url,
            'category' => $story?->category->name_translated,
            'author' => $story?->author?->name_translated,
            'title' => $story->small_title,
        ]);
    });

    $this->nadaraService->getHomeSlider(4, 'web')->each(function ($nadara) use (&$sliders) {
        $sliders->push([
            'type' => 'nadara',
            'date' => $nadara->post_date,
            'url' => route('landingPage.nadara.show', ['lang' => app()->getLocale(), 'slug' => $nadara->slug_translated]),
            'image' => $nadara->main_image_url,
            'category' => $nadara?->category->name_translated,
            'author' => $nadara?->author?->small_name,
            'title' => $nadara->small_title,
        ]);
    });

    $sliders = $sliders->sortByDesc('date');

    return view('landing.home', [
        'sliders' => $sliders,
        'blogs' => $this->blogModulesService->getHome(BlogModules::blogs, 4, 'web'),
        'most_read_blogs' => $this->blogModulesService->getMostRead(BlogModules::blogs, 4, 'web'),
        'stories' => $this->storiesService->getHome(2, 'web'),
        'most_listen_stories' => $this->storiesService->getMostPlayed(4, 'web'),
        'reels' => $this->nadaraService->getHomeReels(4, 'web'),
        'photos' => $this->nadaraService->getHomePhotos(3, 'web'),
        'random' => $this->homeService->getRandomData(),
        'most_publishers' => $this->blogModulesService->getMostPublishedAuthors(BlogModules::blogs),
        'app_settings' => $this->app_settings(),
        'searchEnable' => true,
        'searchCategories' => SearchPages::getPagesTranslated(),
        'htmlSection' => HomeHtml::first(),
        'homeRelatedModels' => HomeRelatedModels::where('section_name', 'home-suggestion')->with('relatedable')->get(),
    ]);
}
    private function getFilmsCategories(): Collection
    {
        return Category::where('module', CategoryModules::movies)->get(['id', 'name_ar']);
    }
    public function about(): View
    {
        $about = MarayaAbout::first();

        return view('landing.about', [
            'app_settings' => $this->app_settings(),
            'about' => app()->getLocale() == 'ar' ? ($about?->about_ar ?? '') : ($about?->about_en ?? ''),
        ]);
    }

    public function book(Request $request)
    {
        if ($request->has('page')) {
            return response()->json([
                'books' => $this->booksService->getFiltered($request),
            ]);
        }

        return view('landing.books', [
            'app_settings' => $this->app_settings(),
            'categories' => Category::with('children')->canBeParent()->where('module', CategoryModules::books)->get(),
            'books' => $this->booksService->getFiltered($request),
            'featured_books' => $this->booksService->getFeatured($request->merge(['per_page' => 4])),
            'most_sold' => $this->booksService->getMostSold($request->merge(['per_page' => 4])),
            'seminars' => $this->blogModulesService->getFiltered(BlogModules::seminars, $request->merge(['per_page' => 3])),
            'signing_parties' => $this->blogModulesService->getFiltered(BlogModules::signing_parties, $request->merge(['per_page' => 3])),
            'exhibitions' => $this->blogModulesService->getFiltered(BlogModules::exhibitions, $request->merge(['per_page' => 3])),
            'searchCategories' => SearchPages::getPagesTranslated(),
            'searchEnable' => true,
            'searchPage' => SearchPages::books,
        ]);
    }

    public function showBook($lang, $slug, Request $request)
    {
        $cookie_name = (Str::replace('.', '', ($request->ip())) . '-' . $lang . '-' . $slug);
        $book = $this->booksService->getSlugableBookDetails($slug);
        if (Cookie::get($cookie_name) == '') { //check if cookie is set
            $cookie = cookie($cookie_name, '1', 60); //set the cookie
            $this->booksService->eventWebView($slug); //count the view

            return response()
                ->view('landing.single_book', [
                    'app_settings' => $this->app_settings(),
                    'model' => $book,
                    'recommended_modules' => $this->booksService->getMostSold($request->merge(['per_page' => 6])),
                    'breadcrumb' => BreadcrumbService::getModelBreadcrumb($book),
                ])->withCookie($cookie); //store the cookie
        } else {
            return view('landing.single_book', [
                'app_settings' => $this->app_settings(),
                'model' => $book,
                'recommended_modules' => $this->booksService->getMostSold($request->merge(['per_page' => 6])),
                'breadcrumb' => BreadcrumbService::getModelBreadcrumb($book),
            ]); //this view is not counted
        }
    }

    public function shareBook($lang, $book): void
    {
        $this->booksService->eventShare($book);
    }

    public function bookRequest($lang, $slug, BookHardCopyRequest $request)
    {
        try {
            $book = Book::where('slug_' . app()->getLocale(), $slug)->firstOrFail();
            if ($book) {
                BookRequest::create($request->validated());
                $book->update([
                    'total_requests' => DB::raw('total_hard_purchased + 1'),
                ]);

                return back()->with([
                    'status' => 'success',
                ]);
            }
        } catch (Exception $e) {
            return back()->with([
                'status' => 'error',
                'message' => $e->getMessage(),
            ]);
        }
    }

    public function seminar(Request $request)
    {
        return response()->json([
            'seminars' => $this->blogModulesService->getFiltered(BlogModules::seminars, $request->merge(['per_page' => 3])),
        ]);
    }

    public function signing_parties(Request $request)
    {
        return response()->json([
            'signing_parties' => $this->blogModulesService->getFiltered(BlogModules::signing_parties, $request->merge(['per_page' => 3])),
        ]);
    }

    public function exhibition(Request $request)
    {
        return response()->json([
            'exhibitions' => $this->blogModulesService->getFiltered(BlogModules::exhibitions, $request->merge(['per_page' => 3])),
        ]);
    }

    public function blog(Request $request)
    {
        if ($request->has('page')) {
            return response()->json([
                'blogs' => $this->blogModulesService->getFiltered(BlogModules::blogs, $request, 'web'),
            ]);
        }
        return view('landing.blogs', [
            'app_settings' => $this->app_settings(),
            'blogs' => $this->blogModulesService->getFiltered(BlogModules::blogs, $request, 'web'),
            'most_read' => $this->blogModulesService->getMostRead(BlogModules::blogs, 4, 'web'),
            'featured_blogs' => $this->blogModulesService->getFeatured(BlogModules::blogs, 3, 'web'),
            'getFeaturedBlog' => $this->blogModulesService->getFeaturedBlog(BlogModules::blogs, 1, 'web'),
            'recommended_blogs' => $this->blogModulesService->getRecommendation(BlogModules::blogs, 3, 'web'),
            'recommended_stories' => $this->storiesService->getRecommendation(1, 'web'),
            'recommended_nadaras' => $this->nadaraService->getRecommendation(1, 'web'),
            'categories' => Category::with('children')->canBeParent()->where('module', CategoryModules::blogs)->where('is_active', 1)->get(),
            'searchCategories' => SearchPages::getPagesTranslated(),
            'category' => $request->category ? Category::with('children')->where('id', $request->category)->first() : null,
            'searchEnable' => true,
            'searchPage' => SearchPages::blogs,
        ]);
    }

    public function team(): View
    {
        return view('landing.team_work', [
            'app_settings' => $this->app_settings(),
            'featured_team' => TeamWork::featured()->get(),
            'unFeatured_team' => TeamWork::notFeatured()->get(),
        ]);
    }

    public function contact(): View
    {
        return view('landing.contact', [
            'app_settings' => $this->app_settings(),
        ]);
    }

    public function maraya_books(Request $request)
    {
        if ($request->has('page')) {
            return response()->json([
                'books' => $this->marayaBooksService->bookList($request->merge(['per_page' => 18])),
            ]);
        }

        return view('landing.maraya_books', [
            'app_settings' => $this->app_settings(),
            'books' => $this->marayaBooksService->bookList($request->merge(['per_page' => 18])),
            'categories' => Category::with('children')->canBeParent()->where('module', CategoryModules::maraya_books)->where('is_active', 1)->get(),
        ]);
    }

    public function maraya_blogs(Request $request)
    {
        if ($request->has('page')) {
            return response()->json([
                'blogs' => $this->blogModulesService->getFiltered(BlogModules::maraya_blogs, $request),
            ]);
        }

        return view('landing.maraya_blogs', [
            'app_settings' => $this->app_settings(),
            'blogs' => $this->blogModulesService->getFiltered(BlogModules::maraya_blogs, $request),
            'categories' => Category::with('children')->canBeParent()->where('module', CategoryModules::maraya_blogs)->where('is_active', 1)->get(),
        ]);
    }
/*
    public function showMarayaBlog($lang, $slug, Request $request)
    {
        if (request()->route()->getName() == 'landingPage.maraya_blogs.show') {
            $module = BlogModules::maraya_blogs;
        } else {
            $module = BlogModules::blogs;
        }
        $cookie_name = (Str::replace('.', '', ($request->ip())) . '-' . $lang . '-' . $slug);
        $blog = $this->blogModulesService->getSlugableBlogDetails($slug);
        if (Cookie::get($cookie_name) == '') { //check if cookie is set
            $cookie = cookie($cookie_name, '1', 60); //set the cookie
            $this->blogModulesService->eventWebView($slug); //count the view

            return response()
                ->view('landing.single_blog', [
                    'app_settings' => $this->app_settings(),
                    'model' => $blog,
                    'most_read' => $this->blogModulesService->getBlogMostRead($blog, 'web'),
                    'recommended_blogs' => $this->blogModulesService->getRecommendation(BlogModules::blogs, 3, 'web'),
                    'recommended_stories' => $this->storiesService->getRecommendation(1, 'web'),
                    'recommended_nadaras' => $this->nadaraService->getRecommendation(1, 'web'),
                    'module' => $module,
                    'breadcrumb' => BreadcrumbService::getModelBreadcrumb($blog),
                ])->withCookie($cookie); //store the cookie
        } else {
            return view('landing.single_blog', [
                'app_settings' => $this->app_settings(),
                'model' => $blog,
                'most_read' => $this->blogModulesService->getBlogMostRead($blog, 'web'),
                'recommended_blogs' => $this->blogModulesService->getRecommendation(BlogModules::blogs, 3, 'web'),
                'recommended_stories' => $this->storiesService->getRecommendation(1, 'web'),
                'recommended_nadaras' => $this->nadaraService->getRecommendation(1, 'web'),
                'module' => $module,
                'breadcrumb' => BreadcrumbService::getModelBreadcrumb($blog),
            ]); //this view is not counted
        }
    }
	*/
	
		public function showMarayaBlog($lang, $slug, Request $request)
	{
		if (request()->route()->getName() == 'landingPage.maraya_blogs.show') {
			$module = BlogModules::maraya_blogs;
		} else {
			$module = BlogModules::blogs;
		}

		$cookie_name = 'visited_blogs_' . $lang;
		$visited_blogs = json_decode(Cookie::get($cookie_name, '[]'), true);
		$blog = $this->blogModulesService->getSlugableBlogDetails($slug);

		if (!in_array($slug, $visited_blogs)) {
			$visited_blogs[] = $slug;
			$cookie = cookie($cookie_name, json_encode($visited_blogs), 60);
			$this->blogModulesService->eventWebView($slug);

			return response()
				->view('landing.single_blog', [
					'app_settings' => $this->app_settings(),
					'model' => $blog,
					'most_read' => $this->blogModulesService->getBlogMostRead($blog, 'web'),
					'recommended_blogs' => $this->blogModulesService->getRecommendation(BlogModules::blogs, 3, 'web'),
					'recommended_stories' => $this->storiesService->getRecommendation(1, 'web'),
					'recommended_nadaras' => $this->nadaraService->getRecommendation(1, 'web'),
					'module' => $module,
					'breadcrumb' => BreadcrumbService::getModelBreadcrumb($blog),
				])->withCookie($cookie);
		} else {
			return view('landing.single_blog', [
				'app_settings' => $this->app_settings(),
				'model' => $blog,
				'most_read' => $this->blogModulesService->getBlogMostRead($blog, 'web'),
				'recommended_blogs' => $this->blogModulesService->getRecommendation(BlogModules::blogs, 3, 'web'),
				'recommended_stories' => $this->storiesService->getRecommendation(1, 'web'),
				'recommended_nadaras' => $this->nadaraService->getRecommendation(1, 'web'),
				'module' => $module,
				'breadcrumb' => BreadcrumbService::getModelBreadcrumb($blog),
			]);
		}
	}

    public function showBlogModule($lang, $slug, Request $request)
    {
        $module = explode('.', request()->route()->getName())[1];
        $blog = $this->blogModulesService->getSlugableBlogDetails($slug);
        $cookie_name = (Str::replace('.', '', ($request->ip())) . '-' . $lang . '-' . $slug);
        if (Cookie::get($cookie_name) == '') { //check if cookie is set
            $cookie = cookie($cookie_name, '1', 60); //set the cookie
            $this->blogModulesService->eventWebView($slug); //count the view

            return response()
                ->view('landing.single_blog_module', [
                    'app_settings' => $this->app_settings(),
                    'model' => $blog,
                    'recommended_modules' => $this->blogModulesService->getRecommendation($module),
                    'module' => $module,
                    'breadcrumb' => BreadcrumbService::getModelBreadcrumb($blog),
                ])->withCookie($cookie); //store the cookie
        } else {
            return view('landing.single_blog_module', [
                'app_settings' => $this->app_settings(),
                'model' => $blog,
                'recommended_modules' => $this->blogModulesService->getRecommendation($module),
                'module' => $module,
                'breadcrumb' => BreadcrumbService::getModelBreadcrumb($blog),
            ]); //this view is not counted
        }
    }

    public function shareBlog($lang, $blog): void
    {
        $this->blogModulesService->eventShare($blog);
    }

    public function movie(Request $request)
    {
        // dd($request->all());
        $categories = $this->getFilmsCategories();
        // Get category IDs from request
        $categoryIds = $request->query('categories', []);
 
        // dd($request->all());
        if ($request->ajax()) {
            if ($request->has('page')) {
                // Check if categories are present
                if ($request->has('categories')) { 
                     return response()->json([
                        'movies' => $this->moviesService->getFilteredAndByCategories(
                            $request->merge(['per_page' => 4]), $categoryIds, 'web'),
                     ]);
                }
        
                return response()->json([
                    'movies' => $this->moviesService->getFiltered($request->merge(['per_page' => 4]), 'web'),
                ]);
            }
        }
        

        if (  $request->has('categories')) {
            
            return view('landing.movies', [
                'app_settings' => $this->app_settings(),
                'movies' => $this->moviesService->getFilteredAndByCategories($request->merge(['per_page' => 4]), $categoryIds,'web'),
                'featured_movies' => collect([]),
                'festivals' => $this->blogModulesService->getFiltered(BlogModules::festivals, $request->merge(['per_page' => 3])),
                'news' => $this->blogModulesService->getFiltered(BlogModules::movie_news, $request->merge(['per_page' => 4])),
                'searchCategories' => SearchPages::getPagesTranslated(),
                'searchEnable' => true,
                'searchPage' => SearchPages::movies,
                'categories' => $categories,
            ]);
        }
        
        return view('landing.movies', [
            'app_settings' => $this->app_settings(),
            'movies' => $this->moviesService->getFiltered($request->merge(['per_page' => 4]), 'web'),
            'featured_movies' => $this->moviesService->getFeatured(2, 'web'),
            'festivals' => $this->blogModulesService->getFiltered(BlogModules::festivals, $request->merge(['per_page' => 3])),
            'news' => $this->blogModulesService->getFiltered(BlogModules::movie_news, $request->merge(['per_page' => 4])),
            'searchCategories' => SearchPages::getPagesTranslated(),
            'searchEnable' => true,
            'searchPage' => SearchPages::movies,
            'categories' => $categories,
        ]);
    }

    public function showMovie($lang, $slug, Request $request)
    {
        $cookie_name = (Str::replace('.', '', ($request->ip())) . '-' . $lang . '-' . $slug);
        $movie = $this->moviesService->getSlugableMovieDetails($slug);
        if (Cookie::get($cookie_name) == '') { //check if cookie is set
            $cookie = cookie($cookie_name, '1', 60); //set the cookie
            $this->blogModulesService->eventWebView($slug); //count the view

            return response()
                ->view('landing.single_movie', [
                    'app_settings' => $this->app_settings(),
                    'model' => $movie,
                    'recommended_modules' => $this->moviesService->getRecommendation(),
                    'breadcrumb' => BreadcrumbService::getModelBreadcrumb($movie),
                ])->withCookie($cookie); //store the cookie
        } else {
            return view('landing.single_movie', [
                'app_settings' => $this->app_settings(),
                'model' => $movie,
                'recommended_modules' => $this->moviesService->getRecommendation(),
                'breadcrumb' => BreadcrumbService::getModelBreadcrumb($movie),
            ]); //this view is not counted
        }
    }

    public function festival(Request $request)
    {
        return response()->json([
            'festivals' => $this->blogModulesService->getFiltered(BlogModules::festivals, $request->merge(['per_page' => 3])),
        ]);
    }

    public function news(Request $request)
    {
        return response()->json([
            'news' => $this->blogModulesService->getFiltered(BlogModules::movie_news, $request->merge(['per_page' => 4])),
        ]);
    }

    public function workshop(Request $request): View
    {
        return view('landing.workshops', [
            'current_workshops' => $this->workshopsService->getCurrent($request, 'web'),
            'passed_workshops' => $this->workshopsService->getPassed($request, 'web'),
            'app_settings' => $this->app_settings(),
            'searchCategories' => SearchPages::getPagesTranslated(),
            'searchEnable' => true,
            'searchPage' => SearchPages::workshops,
        ]);
    }

    public function showWorkshop($lang, $slug): View
    {
        $workshop = $this->workshopsService->getSlugableWorkshopDetails($slug);

        return view('landing.single_workshop', [
            'model' => $workshop,
            'most_applied' => $this->workshopsService->getMostApplied(2),
            'app_settings' => $this->app_settings(),
            'breadcrumb' => BreadcrumbService::getModelBreadcrumb($workshop),
        ]);
    }

    public function shareWorkshop($lang, $workshop): void
    {
        $this->workshopsService->eventShare($workshop);
    }

    public function registerWorkshop($lang, $slug): view
    {
        return view('landing.apply_for_workshop', [
            'model' => $this->workshopsService->getSlugableWorkshopDetails($slug),
            'app_settings' => $this->app_settings(),
        ]);
    }

    public function postRegisterWorkshop($lang, $slug, ApplyForWorkshopRequest $request)
    {
        try {
            $workshop = Workshop::where('slug_' . app()->getLocale(), $slug)->firstOrFail();
            if ($workshop) {
                $workshopRequest = WorkshopRequest::create([
                    'workshop_id' => $workshop->id,
                    'name' => $request->get('name'),
                    'age' => $request->get('age'),
                    'phone_number' => $request->get('phone_number'),
                    'email' => $request->get('email'),
                    'address' => $request->get('address'),
                    'why_join_us' => $request->get('why_join_us'),
                ]);
                foreach ($request->file('files', []) as $file) {
                    WorkshopRequestAttachment::create([
                        'workshop_request_id' => $workshopRequest->id,
                        'attachment' => $file,
                    ]);
                }
                Workshop::where('id', $workshop->id)->update([
                    'total_requests' => DB::raw('total_requests + 1'),
                ]);

                return back()->with([
                    'status' => 'success',
                ]);
            }
        } catch (Exception $e) {
            return back()->with([
                'status' => 'error',
                'message' => $e->getMessage(),
            ]);
        }
    }

    public function story(Request $request)
    {
        try {
            if ($request->has('page')) {
                return response()->json([
                    'stories' => $this->storiesService->getFiltered($request, 'web'),
                ]);
            }

            return view('landing.stories', [
                'app_settings' => $this->app_settings(),
                'stories' => $this->storiesService->getFiltered($request, 'web'),
                'most_played' => $this->storiesService->getMostPlayed(4, 'web'),
                'featured_stories' => $this->storiesService->getFeatured(2, 'web'),
                'recommended_blogs' => $this->blogModulesService->getRecommendation(BlogModules::blogs, 3, 'web'),
                'recommended_stories' => $this->storiesService->getRecommendation(1, 'web'),
                'recommended_nadaras' => $this->nadaraService->getRecommendation(1, 'web'),
                'searchCategories' => SearchPages::getPagesTranslated(),
                'categories' => Category::with('children')->canBeParent()->where('module', CategoryModules::stories)->where('is_active', 1)->get(),
                'searchEnable' => true,
                'searchPage' => SearchPages::stories,
            ]);
        } catch (Exception $ex) {
            Log::error($ex);
        }
    }

    public function showStory($lang, $slug): View
    {
        $story = $this->storiesService->getSlugableStoryDetails($slug);

        return view('landing.single_story', [
            'app_settings' => $this->app_settings(),
            'model' => $story,
            'most_played' => $this->storiesService->getRecommendation(),
            'recommended_blogs' => $this->blogModulesService->getRecommendation(BlogModules::blogs),
            'recommended_stories' => $this->storiesService->getRecommendation(1, 'web'),
            'recommended_nadaras' => $this->nadaraService->getRecommendation(1, 'web'),
            'other_stories' => $this->storiesService->getReadToo($this->storiesService->getSlugableStoryDetails($slug)->category_id, 2),
            'breadcrumb' => BreadcrumbService::getModelBreadcrumb($story),
        ]);
    }

    public function shareStory($lang, $story): void
    {
        $this->storiesService->eventShare($story);
    }

    public function playStory($lang, $story): void
    {
        $this->storiesService->eventPlay($story);
    }

    public function postContact(ContactUsRequest $request)
    {
        ContactUs::create($request->validated());

        return back()->with(['status' => 'success']);
    }

    public function authors()
    {
        return view('landing.authors', [
            'app_settings' => $this->app_settings(),
            'authors' => Author::where('is_published', 1)
                ->where('writing_type', WritingTypes::writer)
                ->where('type', AuthorTypes::individual)
                ->where('is_public', 1)
                ->get(),
        ]);
    }

    public function showAuthor($lang, $slug, Request $request)
    {
        $author = Author::where('slug_' . app()->getLocale(), $slug)->firstOrFail();

        return view('landing.single_author', [
            'app_settings' => $this->app_settings(),
            'model' => $author,
            'blogs' => $this->blogModulesService->getFiltered(BlogModules::blogs, $request->merge(['author' => $author->id, 'per_page' => 200])),
            'stories' => $this->storiesService->getFiltered($request->merge(['author' => $author->id, 'per_page' => 200])),
            'nadaras' => $this->nadaraService->getFiltered($request->merge(['author' => $author->id, 'per_page' => 200])),
            'books' => $this->booksService->getFiltered($request->merge(['author' => $author->id, 'per_page' => 200])),
            'workshops' => $this->workshopsService->getFiltered($request->merge(['author' => $author->id, 'per_page' => 200])),
            'breadcrumb' => BreadcrumbService::getModelBreadcrumb($author),
        ]);
    }

    public function shareAuthor($lang, $author): void
    {
        Author::where('id', $author)->update(['total_shares' => DB::raw('total_shares + 1')]);
    }

    public function nadara(Request $request)
    {
        return view('landing.nadara', [
            'app_settings' => $this->app_settings(),
            'featured_reels' => $this->nadaraService->getFeaturedReels(6, 'web'),
            'featured_photos' => $this->nadaraService->getDistinct(2, 'web'),
            'nadaras' => $request->category ? $this->nadaraService->getFiltered($request, 'web') : $this->nadaraService->getFiltered($request, 'web', 1),
            'recommended_blogs' => $this->blogModulesService->getRecommendation(BlogModules::blogs, 3, 'web'),
            'recommended_stories' => $this->storiesService->getRecommendation(1, 'web'),
            'recommended_nadaras' => $this->nadaraService->getRecommendation(1, 'web'),
            'categories' => Category::with('children')->canBeParent()->where('module', CategoryModules::nadara)->get(),
            'searchCategories' => SearchPages::getPagesTranslated(),
            'searchEnable' => true,
        ]);
    }

    public function nadaraReerls(Request $request)
    {
        return view('landing.nadara_reels', [
            'app_settings' => $this->app_settings(),
            'nadaras' => $this->nadaraService->getFilteredReels($request, 'web'),
            'recommended_blogs' => $this->blogModulesService->getRecommendation(BlogModules::blogs, 3, 'web'),
            'recommended_stories' => $this->storiesService->getRecommendation(1, 'web'),
            'recommended_nadaras' => $this->nadaraService->getRecommendation(1, 'web'),
            'categories' => Category::with('children')->canBeParent()->where('module', CategoryModules::nadara)->where('is_active', 1)->get(),
        ]);
    }

    public function showNadara($lang, $slug, Request $request)
    {
        $nadara = Nadara::where('slug_' . app()->getLocale(), $slug)->firstOrFail();

        $cookie_name = (Str::replace('.', '', ($request->ip())) . '-' . $lang . '-' . $slug);
        if (Cookie::get($cookie_name) == '') { //check if cookie is set
            $cookie = cookie($cookie_name, '1', 60); //set the cookie
            $this->nadaraService->eventView($nadara->id); //count the view
            if ($nadara->type == NadaraTypes::reels) {
                $this->nadaraService->eventPlay($nadara->id); //count the view
            }

            return response()
                ->view('landing.single_nadara', [
                    'app_settings' => $this->app_settings(),
                    'model' => $nadara,
                    'recommended_blogs' => $this->blogModulesService->getRecommendation(BlogModules::blogs),
                    'recommended_stories' => $this->storiesService->getRecommendation(1, 'web'),
                    'recommended_nadaras' => $this->nadaraService->getRecommendation(1, 'web'),
                    'breadcrumb' => BreadcrumbService::getModelBreadcrumb($nadara),
                ])->withCookie($cookie); //store the cookie
        } else {
            return view('landing.single_nadara', [
                'app_settings' => $this->app_settings(),
                'model' => $nadara,
                'recommended_blogs' => $this->blogModulesService->getRecommendation(BlogModules::blogs),
                'recommended_stories' => $this->storiesService->getRecommendation(1, 'web'),
                'recommended_nadaras' => $this->nadaraService->getRecommendation(1, 'web'),
                'breadcrumb' => BreadcrumbService::getModelBreadcrumb($nadara),
            ]); //this view is not counted
        }
    }

    public function shareNadara($lang, $nadara): void
    {
        $this->nadaraService->eventShare($nadara);
    }

    public function playNadara($lang, $nadara): void
    {
        $this->nadaraService->eventPlay($nadara);
    }

    public function viewNadara($lang, $nadara): void
    {
        $this->nadaraService->eventView($nadara);
    }
}
