<?php

namespace App\Http\Controllers\Webhooks;

use App\Enum\PaymentStatus;
use App\Events\OnlinePaymentPaid;
use App\Http\Controllers\Controller;
use App\Models\OnlinePayment;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class Paymob extends Controller
{
    public function processedCallback(Request $request): RedirectResponse
    {
        Log::channel('paymob')->info('Paymob::processedCallback', ['request' => $request]);

        return $this->completePaymobProcess($request);
    }

    public function responseCallback(Request $request): RedirectResponse
    {
        Log::channel('paymob')->info('Paymob::responseCallback', ['request' => $request]);

        return $this->completePaymobProcess($request);
    }

    private function completePaymobProcess(Request $request): RedirectResponse
    {
        if (! $this->checkRequestHmac($request)) {
            return to_route('api.callbacks.payment-failure', ['message' => __('payment.not-processable')]);
        }

        $route = 'api.callbacks.payment-failure';
        $message = __('payment.not-processable');

        $onlinePayment = OnlinePayment::where('gateway_tracking', $request['id'])->first();
        if ($onlinePayment) {
            if ($onlinePayment->status == PaymentStatus::pending) {
                if ($onlinePayment->amount_in_cents == $request['amount_cents'] && $request['success'] == true) {
                    $onlinePayment->update(['status' => PaymentStatus::purchased]);
                    $route = 'api.callbacks.payment-success';
                    $message = __('payment.paid-success');
                    event(new OnlinePaymentPaid($onlinePayment));
                } else {
                    $onlinePayment->update(['status' => PaymentStatus::failed]);
                    $route = 'api.callbacks.payment-failure';
                    $message = __('payment.not-processable');
                }
            } elseif ($onlinePayment->status == PaymentStatus::purchased) {
                $route = 'api.callbacks.payment-success';
                $message = __('payment.paid-before');
            }
        }

        return to_route($route, ['message' => $message]);
    }

    private function checkRequestHmac(Request $request): bool
    {
        $string = $request['amount_cents'].
            $request['created_at'].
            $request['currency'].
            $request['error_occured'].
            $request['has_parent_transaction'].
            $request['id'].
            $request['integration_id'].
            $request['is_3d_secure'].
            $request['is_auth'].
            $request['is_capture'].
            $request['is_refunded'].
            $request['is_standalone_payment'].
            $request['is_voided'].
            $request['order'].
            $request['owner'].
            $request['pending'].
            $request['source_data_pan'].
            $request['source_data_sub_type'].
            $request['source_data_type'].
            $request['success'];

        $calculatedHmac = hash_hmac('sha512', $string, config('paymob.hmac_secret'));

        return $request['hmac'] == $calculatedHmac;
    }
}
