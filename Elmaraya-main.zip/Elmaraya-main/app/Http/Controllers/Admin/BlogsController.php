<?php

namespace App\Http\Controllers\Admin;

use App\Models\Blog;
use App\Models\Category;
use App\Enum\BlogModules;
use Illuminate\Http\Request;
use App\Enum\CategoryModules;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Traits\BlogModulesControllerTrait;
use Illuminate\Database\Eloquent\Collection;

class BlogsController extends Controller
{
    use BlogModulesControllerTrait;

    private bool $showTranslator = true;

    private function getPageTitle(): string
    {
        return 'المدونات';
    }

    private function getCategories(): Collection
    {
        return Category::where('module', CategoryModules::blogs)->get(['id', 'name_ar']);
    }

    private function getShowCategories(): bool
    {
        return true;
    }

    private function getModuleName(): string
    {
        return 'مدونة';
    }

    private function getRouteParent(): string
    {
        return 'blogs';
    }

    private function getModuleType(): string
    {
        return BlogModules::blogs;
    }

    private function getChecksData(): array
    {
        return [
            'is_home' => [
                'key' => 'يظهر في الصفحة الرئيسية',
                'values' => [
                    '0' => 'لا',
                    '1' => 'نعم',
                    
                ],
            ],
            'is_featured' => [
                'key' => 'مدونة رئيسية',
                'values' => [
                    '0' => 'لا',
                    '1' => 'نعم',
                    
                ],
            ],
            'is_recommended' => [
                'key' => 'تظهر كمقترح',
                'values' => [
                    '0' => 'لا',
                    '1' => 'نعم',
                    
                ],
            ],
            'is_home_slider' => [
                'key' => 'تظهر كسلايدر في الرئيسية',
                'values' => [
                    '0' => 'لا',
                    '1' => 'نعم',
                    
                ],
            ],
            'publish_type' => [
                'key' => 'نوع النشر',
                'values' => [
                    'all' => 'الكل',
                    'web' => 'الويب',
                    'mobile' => 'الموبايل',
                ],
            ],
            'linked_data' => [
                'key' => 'مدونات إقرأوا أيضاً',
                'is_multiple' => true,
                'values' => Blog::moduleType($this->getModuleType())->select('id', 'title_ar')->get()->pluck('title_ar', 'id')->toArray(),
            ],
        ];
    }

    public function changedistinctive(Request $request)
    {
        try {
            $model = Blog::find($request->id);

    // Toggle the value of the is_distinctive attribute
                $model->is_distinctive = !$model->is_distinctive;
                $model->save();
    
            return response()->json(['success' => true]);
        }catch(\Exception $ex) {
            Log::error($ex);
            return response()->json(['success' => false, 'message' => 'failed to change', 'details' => $ex->getMessage()]);

        }
    
    }

}
