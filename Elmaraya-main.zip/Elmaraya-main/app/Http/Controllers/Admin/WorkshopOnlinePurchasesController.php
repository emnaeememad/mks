<?php

namespace App\Http\Controllers\Admin;

use App\Models\Orders;
use App\Enum\OrderType;
use App\Models\BookPurchase;
use Illuminate\Contracts\View\View;
use App\Http\Controllers\Controller;

class WorkshopOnlinePurchasesController extends Controller
{
    public function index(): View
    {
        $orders_workshop_online = Orders::ofType(OrderType::workshoponline)->with([
            'orderBooks.book.author' => function ($query) {
                $query->withTrashed();
            }, 'orderBooks.book.category' => function ($query) {
                $query->withTrashed();
            },
            'payment' => fn ($q) => $q->withTrashed(),
            'customer',
        ])
            ->descOrder()
            ->paginate(20);

        return view('dashboard.orders_workshop_online.index', [
            'collection' =>  $orders_workshop_online,
        ]);
    }

    public function show($id): View
    {
        $orders_workshop_online = Orders::ofType(OrderType::workshoponline)
            ->with([
                'orderWorkshopsOnline.workshoponline.author' => function ($query) {
                    $query->withTrashed();
                }, 
                'payment' => fn ($q) => $q->withTrashed(),
                'customer',
            ])
            ->find($id);

        if ($orders_workshop_online == null) {
            abort(404);
        }


        return view('dashboard.orders_workshop_online.show', [
            'model' =>  $orders_workshop_online,
        ]);
    }
}
