<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\WorkshopRequest;
use Illuminate\Contracts\View\View;

class WorkshopRequestsController extends Controller
{
    public function index(): View
    {
        return view('dashboard.workshop_requests.index', [
            'collection' => WorkshopRequest::with([
                'workshop' => fn ($q) => $q->withTrashed()->select('id', 'title_ar', 'author_id')->with([
                    'author' => fn ($a) => $a->withTrashed()->select('id', 'name_ar'),
                ]),
            ])->paginate(20),
        ]);
    }

    public function show(WorkshopRequest $workshopRequest): View
    {
        return view('dashboard.workshop_requests.show', [
            'model' => $workshopRequest->load([
                'workshop' => fn ($q) => $q->withTrashed()->with([
                    'author' => fn ($a) => $a->withTrashed(),
                ]),
                'attachments',
            ]),
        ]);
    }
}
