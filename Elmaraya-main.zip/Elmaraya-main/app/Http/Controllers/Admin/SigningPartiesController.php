<?php

namespace App\Http\Controllers\Admin;

use App\Enum\BlogModules;
use App\Http\Controllers\Controller;
use App\Traits\BlogModulesControllerTrait;
use Illuminate\Support\Collection;

class SigningPartiesController extends Controller
{
    use BlogModulesControllerTrait;

    private function getPageTitle(): string
    {
        return 'حفلات التوقيع';
    }

    private function getCategories(): Collection
    {
        return collect([]);
    }

    private function getShowCategories(): bool
    {
        return false;
    }

    private function getModuleName(): string
    {
        return 'حفلة توقيع';
    }

    private function getRouteParent(): string
    {
        return 'signing_parties';
    }

    private function getModuleType(): string
    {
        return BlogModules::signing_parties;
    }

    private function getChecksData(): array
    {
        return [
            'is_recommended' => [
                'key' => 'تظهر كمقترح',
                'values' => [
                    '1' => 'نعم',
                    '0' => 'لا',
                ],
            ],
        ];
    }
}
