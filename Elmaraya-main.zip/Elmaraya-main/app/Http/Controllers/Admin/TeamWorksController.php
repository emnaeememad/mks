<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\TeamWork\StoreTeamWorkRequest;
use App\Http\Requests\Admin\TeamWork\UpdateTeamWorkRequest;
use App\Models\TeamWork;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;

class TeamWorksController extends Controller
{
    public function index(): View
    {
        $collection = TeamWork::descOrder()->paginate(20);

        return view('dashboard.team_works.index', ['collection' => $collection]);
    }

    public function create(): View
    {
        return view('dashboard.team_works.create');
    }

    public function store(StoreTeamWorkRequest $request): RedirectResponse
    {
        $data = $request->validated();
        $data['is_featured'] = $request->has('is_featured');

        TeamWork::create($data);
        Alert::success('عملية ناجحة', 'تم إضافة العضو إلي فريق العمل بنجاح');

        return redirect(route('admin.team_works.index'));
    }

    public function show(TeamWork $teamWork): View
    {
        return view('dashboard.team_works.show', ['model' => $teamWork]);
    }

    public function edit(TeamWork $teamWork): View
    {
        return view('dashboard.team_works.edit', ['model' => $teamWork]);
    }

    public function update(UpdateTeamWorkRequest $request, TeamWork $teamWork): RedirectResponse
    {
        $data = $request->validated();
        $data['is_featured'] = $request->has('is_featured');
        $teamWork->update($data);
        Alert::success('عملية ناجحة', 'تم تعديل بيانات العضو في فريق العمل بنجاح');

        return back();
    }

    public function destroy(TeamWork $teamWork): RedirectResponse
    {
        $teamWork->delete();
        Alert::success('عملية ناجحة', 'تم حذف العضو من فريق العمل بنجاح');

        return back();
    }
}
