<?php

namespace App\Http\Controllers\Admin;

use App\Models\Role;
use App\Models\Permission;
use Illuminate\Contracts\View\View;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Requests\Admin\Role\StoreRoleRequest;
use App\Http\Requests\Admin\Role\UpdateRoleRequest;

class RolesController extends Controller
{
    public function index(): View
    {
        return view('dashboard.roles.index', [
            'collection' => Role::editable()->descOrder()->paginate(20),
        ]);
    }

    public function create(): View
    {
        return view('dashboard.roles.create', [
            'permissions' => Permission::all()->groupBy('module_name'),
        ]);
    }

    public function store(StoreRoleRequest $request): RedirectResponse
    {
        $role = Role::create([
            'name_ar' => $request->get('name_ar'),
            'name_en' => $request->get('name_en'),
            'editable' => true,
        ]);
        $role->permissions()->attach($request->get('permissions'));
        Alert::success('عملية ناجحة', 'تم إضافة الصلاحية بنجاح');

        return redirect(route('admin.roles.index'));
    }

    public function show(Role $role): View
    {
        $role->load('permissions');

        return view('dashboard.roles.show', [
            'permissions' => Permission::all()->groupBy('module_name'),
            'model' => $role,
            'rolePermissions' => $role->permissions->pluck('id')->toArray(),
        ]);
    }

    public function edit(Role $role): View
    {
        $role->load('permissions');

        return view('dashboard.roles.edit', [
            'permissions' => Permission::all()->groupBy('module_name'),
            'model' => $role,
            'rolePermissions' => $role->permissions->pluck('id')->toArray(),
        ]);
    }

    public function update(UpdateRoleRequest $request, Role $role): RedirectResponse
    {
        $role->update([
            'name_ar' => $request->get('name_ar'),
            'name_en' => $request->get('name_en'),
        ]);
        $role->permissions()->sync($request->get('permissions'));
        Alert::success('عملية ناجحة', 'تم تعديل بيانات الصلاحية بنجاح');

        return back();
    }

    public function destroy(Role $role): RedirectResponse
    {
        if ($role->admins()->count() > 0) {
            Alert::error('عملية فاشلة', 'لا يمكن حذف الصلاحية لان يوجد مسؤولين لديهم تلم الصلاحية');
        } else {
            $role->delete();
            Alert::success('عملية ناجحة', 'تم حذف بيانات الصلاحية بنجاح');
        }

        return back();
    }
}
