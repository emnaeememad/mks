<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Trainer\StoreTrainerRequest;
use App\Http\Requests\Admin\Trainer\UpdateTrainerRequest;
use App\Services\TrainerService;
use Exception;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class TrainerController extends Controller
{
    private TrainerService $trainerService;

    public function __construct(TrainerService $trainerService)
    {
        $this->trainerService = $trainerService;
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {
            return view('dashboard.trainers.index', [
                'collection' => $this->trainerService->getTrainers(),
            ]);
        } catch (\Exception $e) {
            throw $e->getMessage();
        }
        
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('dashboard.trainers.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreTrainerRequest $request)
    {
        try {
            $this->trainerService->createTrainer($request->validated());
            Alert::success('عملية ناجحة', 'تم إضافة المدرب إلي قائمة المدربين بنجاح');
            return redirect()->route('admin.trainers.index');
        } catch (\Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    /**
     * Display the specified resource.
     */
    public function show($trainer)
    {
        try {
            return view('dashboard.trainers.show', [
                'model' => $this->trainerService->find($trainer),
            ]);
        } catch (\Exception $e) {
            throw $e->getMessage();
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($trainer)
    {
        try {
            return view('dashboard.trainers.edit', [
                'model' => $this->trainerService->find($trainer),
            ]);
        } catch (\Exception $e) {
            throw $e->getMessage();
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateTrainerRequest $request, $trainer)
    {
        try {
            $this->trainerService->update($request->validated(), $trainer);
            Alert::success('عملية ناجحة', 'تم تعديل المدرب بنجاح');
            return redirect()->route('admin.trainers.index');
        } catch (\Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($trainer)
    {
        try {
            $this->trainerService->find($trainer)->delete();
            Alert::success('عملية ناجحة', 'تم حذف المدرب بنجاح');
            return redirect()->route('admin.trainers.index');
        } catch (\Exception $e) {
            throw $e->getMessage();
        }
    }
}
