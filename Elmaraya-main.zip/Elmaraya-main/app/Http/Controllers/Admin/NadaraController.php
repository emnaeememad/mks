<?php

namespace App\Http\Controllers\Admin;

use App\Models\Author;
use App\Models\Nadara;
use App\Models\Category;
use App\Enum\NadaraTypes;
use App\Enum\PublishType;
use App\Enum\PublishStatus;
use App\Models\NadaraImage;
use Illuminate\Http\Request;
use App\Enum\CategoryModules;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Requests\Admin\Nadara\StoreNadaraRequest;
use App\Http\Requests\Admin\Nadara\UpdateNadaraRequest;

class NadaraController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('dashboard.nadara.index', [
            'collection' => Nadara::descOrder()->paginate(20),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('dashboard.nadara.create', [
            'authors' => Author::individuals()->get(['id', 'name_ar']),
            'categories' => Category::where('module', CategoryModules::nadara)->get(['id', 'name_ar']),
            'publishStatuses' => PublishStatus::getStatusesTranslated(),
            'types' => NadaraTypes::getTypesTranslated(),
            'publishTypes' => PublishType::getTypesTranslated(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreNadaraRequest $request)
    {
        $slugs = [
            'slug_ar' => Nadara::slug($request->get('title_ar')),
            'slug_en' => Nadara::slug($request->get('title_en')),
        ];
        if (Nadara::isNotSlugable($slugs)) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        $nadara = Nadara::create([
            ...$request->validated(),
            ...$slugs,
        ]);
        foreach ($request->file('files', []) as $file) {
            NadaraImage::create([
                'file' => $file,
                'nadara_id' => $nadara->id,
            ]);
        }
        Alert::success('عملية ناجحة', 'تم إضافة نضارة بنجاح');

        return to_route('admin.nadara.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(Nadara $nadara)
    {
        return view('dashboard.nadara.show', [
            'model' => $nadara->load('images'),
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Nadara $nadara)
    {
        return view('dashboard.nadara.edit', [
            'authors' => Author::individuals()->get(['id', 'name_ar']),
            'categories' => Category::where('module', CategoryModules::nadara)->get(['id', 'name_ar']),
            'publishStatuses' => PublishStatus::getStatusesTranslated(),
            'types' => NadaraTypes::getTypesTranslated(),
            'model' => $nadara->load('images'),
            'publishTypes' => PublishType::getTypesTranslated(),
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateNadaraRequest $request, Nadara $nadara)
    {
        $slugs = [
            'slug_ar' => Nadara::slug($request->get('title_ar')),
            'slug_en' => Nadara::slug($request->get('title_en')),
        ];
        if (Nadara::isNotSlugable($slugs, $nadara->id)) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        $removedImageIds = array_filter(explode(',', $request->get('removeImages', '')));
        NadaraImage::whereIn('id', $removedImageIds)->get()->map(fn ($nadaraImage) => $nadaraImage->delete());
        $nadara->update([
            ...$request->validated(),
            ...$slugs,
        ]);
        foreach ($request->file('files', []) as $file) {
            NadaraImage::create([
                'file' => $file,
                'nadara_id' => $nadara->id,
            ]);
        }
        Alert::success('عملية ناجحة', 'تم تعديل بيانات نضارة بنجاح');

        return back();
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Nadara $nadara)
    {
        $nadara->delete();
        Alert::success('عملية ناجحة', 'تم حذف نضارة بنجاح');

        return back();
    }
    public function changedistinctive(Request $request)
    {
        try {
            $model = Nadara::find($request->id);

    // Toggle the value of the is_distinctive attribute
                $model->is_distinctive = !$model->is_distinctive;
                $model->save();
    
            return response()->json(['success' => true]);
        }catch(\Exception $ex) {
            Log::error($ex);
            return response()->json(['success' => false, 'message' => 'failed to change', 'details' => $ex->getMessage()]);

        }
    
    }
}
