<?php

namespace App\Http\Controllers\Admin;

use App\Enum\Genders;
use App\Models\Author;
use App\Enum\AuthorTypes;
use Illuminate\Contracts\View\View;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Requests\Admin\AuthorCompany\StoreAuthorCompanyRequest;
use App\Http\Requests\Admin\AuthorCompany\UpdateAuthorCompanyRequest;

class AuthorCompaniesController extends Controller
{
    public function index(): View
    {
        return view('dashboard.authors_companies.index', [
            'collection' => Author::companies()->descOrder()->paginate(20),
        ]);
    }

    public function create(): View
    {
        return view('dashboard.authors_companies.create');
    }

    public function store(StoreAuthorCompanyRequest $request): RedirectResponse
    {
        $slugs = [
            'slug_ar' => Author::slug($request->get('name_ar')),
            'slug_en' => Author::slug($request->get('name_en')),
        ];
        if (
            Author::isNotSlugable(
                data: $slugs,
                extraConditions: ['type' => AuthorTypes::company]
            )
        ) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان الإسم مميز و غير موجود (الإسم عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        Author::create([
            'type' => AuthorTypes::company,
            'gender' => Genders::male['name_en'],
            ...$request->validated(),
            ...$slugs,
        ]);
        Alert::success('عملية ناجحة', 'تم إضافة دار النشر بنجاح');

        return to_route('admin.authors_companies.index');
    }

    public function show(Author $author): View
    {
        return view('dashboard.authors_companies.show', [
            'model' => $author,
        ]);
    }

    public function edit(Author $author): View
    {
        return view('dashboard.authors_companies.edit', [
            'model' => $author,
        ]);
    }

    public function update(UpdateAuthorCompanyRequest $request, Author $author): RedirectResponse
    {
        $slugs = [
            'slug_ar' => Author::slug($request->get('name_ar')),
            'slug_en' => Author::slug($request->get('name_en')),
        ];
        if (Author::isNotSlugable($slugs, $author->id, ['type' => AuthorTypes::company])) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان الإسم مميز و غير موجود (الإسم عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        $author->update([
            ...$request->validated(),
            ...$slugs,
        ]);
        Alert::success('عملية ناجحة', 'تم تعديل بيانات دار النشر بنجاح');

        return back();
    }

    public function destroy(Author $author): RedirectResponse
    {
        $author->delete();
        Alert::success('عملية ناجحة', 'تم حذف دار النشر بنجاح');

        return to_route('admin.authors_companies.index');
    }
}
