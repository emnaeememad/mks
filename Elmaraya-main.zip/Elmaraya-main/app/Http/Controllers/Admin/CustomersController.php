<?php

namespace App\Http\Controllers\Admin;

use App\Models\Customer;
use App\Models\BookPurchase;
use App\Models\CustomerBook;
use Illuminate\Http\Request;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Models\CustomerSubscription;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Requests\Admin\Customer\StoreCustomerRequest;
use App\Http\Requests\Admin\Customer\UpdateCustomerRequest;

class CustomersController extends Controller
{
    public function index(): View
    {
        return view('dashboard.customers.index', [
            'collection' => Customer::descOrder()->paginate(20),
        ]);
    }

    public function create(): View
    {
        return view('dashboard.customers.create');
    }

    public function store(StoreCustomerRequest $request): RedirectResponse
    {
        Customer::create($request->validated());
        Alert::success('عملية ناجحة', 'تم إضافة العميل بنجاح');

        return to_route('admin.customers.index');
    }

    public function show(Customer $customer): View
    {
        $bookPurchases = BookPurchase::where('customer_id', $customer->id)
            ->with(['book' => fn ($b) => $b->withTrashed()])
            ->paginate(perPage: 5, pageName: 'purchases');
        $customerBooks = CustomerBook::where('customer_id', $customer->id)
            ->with(['book' => fn ($b) => $b->withTrashed()])
            ->paginate(perPage: 5, pageName: 'books');
        $customerSubscriptions = CustomerSubscription::where('customer_id', $customer->id)
            ->with(['subscription' => fn ($b) => $b->withTrashed()])
            ->paginate(perPage: 5, pageName: 'subscriptions');

        return view('dashboard.customers.show', [
            'customer' => $customer,
            'bookPurchases' => $bookPurchases,
            'customerBooks' => $customerBooks,
            'customerSubscriptions' => $customerSubscriptions,
        ]);
    }

    public function edit(Customer $customer): View
    {
        return view('dashboard.customers.edit', ['model' => $customer]);
    }

    public function update(UpdateCustomerRequest $request, Customer $customer): RedirectResponse
    {
        $customer->update($request->validated());
        Alert::success('عملية ناجحة', 'تم تعديل بيانات العميل بنجاح');

        return back();
    }

    public function destroy(Customer $customer): RedirectResponse
    {
        $customerDeleted = false;
        if ($customer->bookPurchases()->count() > 0) {
            $msg = 'لا يمكن حذف العميل لان لديه مجموعة كتب';
        } elseif ($customer->customerBooks()->count() > 0) {
            $msg = 'لا يمكن حذف العميل لان لديه مجموعة كتب';
        } elseif ($customer->customerSubscriptions()->count() > 0) {
            $msg = 'لا يمكن حذف العميل لان لديه إشتاركات (مسبقة او حالية)';
        } else {
            $customerDeleted = true;
            $msg = 'تم حذف بيانات العميل نهائيا بنجاح';
            $customer->delete();
        }

        $customerDeleted ? Alert::success('عملية ناجحة', $msg) : Alert::error('عملية فاشلة', $msg);

        return back();
    }

    public function changeverify(Request $request)
    {
        try {
            $model = Customer::find($request->id);
            $model->verified_at = $model->verified_at ? null : now();
            $model->save();
    
            return response()->json(['success' => true]);
        }catch(\Exception $ex) {
            Log::error($ex);
            return response()->json(['success' => false, 'message' => 'failed to verify', 'details' => $ex->getMessage()]);

        }
    
    }
}
