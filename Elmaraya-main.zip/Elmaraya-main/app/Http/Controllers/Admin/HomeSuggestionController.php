<?php

namespace App\Http\Controllers\Admin;

use App\Enum\BlogModules;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\UpdateHomeSuggestion;
use App\Models\Author;
use App\Models\Blog;
use App\Models\Book;
use App\Models\HomeRelatedModels;
use App\Models\Movie;
use App\Models\Nadara;
use App\Models\Story;
use App\Models\Workshop;
use Illuminate\Contracts\View\View;

class HomeSuggestionController extends Controller
{
    public function getForm(): View
    {
        $homeRelatedModels = HomeRelatedModels::where('section_name', 'home-suggestion')->get();
		    $sectionNames = [
        'seminars' => 'الندوات',     
        'signing_parties' => 'حفلات التوقيع',
		'exhibitions' => 'المعارض',
        'festivals' => 'المهرجانات',
        'movie_news' => 'أخبار الأفلام'
    ];
	
		$collect = collect();
		$collect = $collect->merge(Blog::where('module_type', BlogModules::seminars)->get());
		$collect = $collect->merge(Blog::where('module_type', BlogModules::signing_parties)->get());
		$collect = $collect->merge(Blog::where('module_type', BlogModules::exhibitions)->get());
		$collect = $collect->merge(Blog::where('module_type', BlogModules::festivals)->get());
		$collect = $collect->merge(Blog::where('module_type', BlogModules::movie_news)->get());		

        return view('dashboard.home-suggestion', [
            'nadara' => Nadara::select('id', 'title_ar')->get(),
            'books' => Book::select('id', 'name_ar')->get(),
            'signing_parties' => Blog::where('module_type', BlogModules::seminars)->get(),
            'blogs' => Blog::moduleType(BlogModules::blogs)->select('id', 'title_ar')->get(),
            'stories' => Story::select('id', 'title_ar')->get(),
            'authors' => Author::select('id', 'name_ar')->get(),
			'seminars' => $collect,
			'signing_parties' => $collect,
			'sectionNames' => $sectionNames,
            'homeRelatedModels' => $homeRelatedModels,
        ]);
    }

    public function update(UpdateHomeSuggestion $request)
    {
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'blog_1'], ['relatedable_type' => Blog::class, 'relatedable_id' => $request->get('blog_1')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'blog_2'], ['relatedable_type' => Blog::class, 'relatedable_id' => $request->get('blog_2')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'blog_3'], ['relatedable_type' => Blog::class, 'relatedable_id' => $request->get('blog_3')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'blog_4'], ['relatedable_type' => Blog::class, 'relatedable_id' => $request->get('blog_4')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'blog_5'], ['relatedable_type' => Blog::class, 'relatedable_id' => $request->get('blog_5')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'blog_6'], ['relatedable_type' => Blog::class, 'relatedable_id' => $request->get('blog_6')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'blog_7'], ['relatedable_type' => Blog::class, 'relatedable_id' => $request->get('blog_7')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'author'], ['relatedable_type' => Author::class, 'relatedable_id' => $request->get('author')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'author1'], ['relatedable_type' => Author::class, 'relatedable_id' => $request->get('author1')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'author2'], ['relatedable_type' => Author::class, 'relatedable_id' => $request->get('author2')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'author3'], ['relatedable_type' => Author::class, 'relatedable_id' => $request->get('author3')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'author4'], ['relatedable_type' => Author::class, 'relatedable_id' => $request->get('author4')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'author5'], ['relatedable_type' => Author::class, 'relatedable_id' => $request->get('author5')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'author6'], ['relatedable_type' => Author::class, 'relatedable_id' => $request->get('author6')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'story'], ['relatedable_type' => Story::class, 'relatedable_id' => $request->get('story')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'nadara'], ['relatedable_type' => Nadara::class, 'relatedable_id' => $request->get('nadara')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'signing_parties'], ['relatedable_type' => Blog::class, 'relatedable_id' => $request->get('signing_parties')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'book2'], ['relatedable_type' => Book::class, 'relatedable_id' => $request->get('book2')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'book3'], ['relatedable_type' => Book::class, 'relatedable_id' => $request->get('book3')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'seminars'], ['relatedable_type' => Blog::class, 'relatedable_id' => $request->get('seminars')]);
        HomeRelatedModels::updateOrCreate(['section_name' => 'home-suggestion', 'section_key' => 'book4'], ['relatedable_type' => Book::class, 'relatedable_id' => $request->get('book4')]);
        alert()->success('عملية ناجحة', 'تم تعديل محتوي الإقتراحات بالصفحة الرئيسية');

        return to_route('admin.home-suggestion.show');
    }
}
