<?php

namespace App\Http\Controllers\Admin;

use App\Enum\BlogModules;
use App\Enum\CategoryModules;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Traits\BlogModulesControllerTrait;
use Illuminate\Database\Eloquent\Collection;

class MarayaBlogsController extends Controller
{
    use BlogModulesControllerTrait;

    private function getPageTitle(): string
    {
        return 'مدونات المرايا';
    }

    private function getCategories(): Collection
    {
        return Category::where('module', CategoryModules::maraya_blogs)->get(['id', 'name_ar']);
    }

    private function getShowCategories(): bool
    {
        return true;
    }

    private function getModuleName(): string
    {
        return 'مدونة المرايا';
    }

    private function getRouteParent(): string
    {
        return 'maraya_blogs';
    }

    private function getModuleType(): string
    {
        return BlogModules::maraya_blogs;
    }

    private function getChecksData(): array
    {
        return [
            'is_recommended' => [
                'key' => 'تظهر كمقترح',
                'values' => [
                    '1' => 'نعم',
                    '0' => 'لا',
                ],
            ],
        ];
    }
}
