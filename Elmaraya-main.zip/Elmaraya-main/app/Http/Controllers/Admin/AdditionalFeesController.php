<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Models\MarayaSetting;
use App\Models\AdditionalFees;
use App\Models\PaymentMethodType;
use Illuminate\Contracts\View\View;
use App\Http\Controllers\Controller;
use Illuminate\Validation\Validator;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;
use RealRashid\SweetAlert\Facades\Alertw;
use App\Http\Requests\Admin\Blog\StoreBlogRequest;
use App\Http\Requests\Admin\UpdateSettingsRequest;

class AdditionalFeesController extends Controller
{
    public function index(): View
    {

        return view('dashboard.additional_fees.index', [
            'collection' => AdditionalFees::descOrder()->paginate(40),
            'pageTitle' => $this->getPageTitle(),
            'moduleName' => $this->getModuleName(),
            'routeParent' => $this->getRouteParent(),
            'routeModelName' => 'additionalfees',
        ]);
    }

    public function create(): View
    {
        return view('dashboard.additional_fees.create', [

            'pageTitle' => $this->getPageTitle(),
            'moduleName' => $this->getModuleName(),
            'routeParent' => $this->getRouteParent(),
            'routeModelName' => 'getRouteParent',
        ]);
    }

    public function store(Request $request): RedirectResponse
    {



        $validatedData = $request->validate([
            'min_price' => 'required|numeric|min:0',
            'max_price' => ['required', 'numeric', 'min:0', 'gt:min_price'],
            'fee' => 'required|numeric|min:0',
        ], [
            'min_price.required' => 'حقل السعر الأدنى مطلوب',
            'min_price.numeric' => 'حقل السعر الأدنى يجب أن يكون رقمًا',
            'min_price.min' => 'حقل السعر الأدنى يجب أن يكون أكبر من أو يساوي الصفر',
            'max_price.required' => 'حقل السعر الأعلى مطلوب',
            'max_price.numeric' => 'حقل السعر الأعلى يجب أن يكون رقمًا',
            'max_price.min' => 'حقل السعر الأعلى يجب أن يكون أكبر من الصفر',
            'max_price.gt' => 'حقل السعر الأعلى يجب أن يكون أكبر من السعر الأدنى',
            'fee.required' => 'حقل الرسوم مطلوب',
            'fee.numeric' => 'حقل الرسوم يجب أن يكون رقمًا',
            'fee.min' => 'حقل الرسوم يجب أن يكون أكبر من أو يساوي الصفر',
        ]);

        AdditionalFees::create($validatedData);

        Alert::success('عملية ناجحة', 'تم إضافة ' . $this->getModuleName() . ' بنجاح');

        return to_route('admin.' . $this->getRouteParent() . '.index');
    }


    public function edit($id): View
    {
        $model = AdditionalFees::where('id', $id)->first();

        return view('dashboard.additional_fees.edit', [

            'model' => $model,
            'pageTitle' => $this->getPageTitle(),
            'moduleName' => $this->getModuleName(),
            'routeParent' => $this->getRouteParent(),
            'routeModelName' => 'additionalfees',
        ]);
    }

    public function update(Request $request, $id): RedirectResponse
    {

        $validatedData = $request->validate([
            'min_price' => 'required|numeric|min:0',
            'max_price' => ['required', 'numeric', 'min:0', 'gt:min_price'],
            'fee' => 'required|numeric|min:0',
        ], [
            'min_price.required' => 'حقل السعر الأدنى مطلوب',
            'min_price.numeric' => 'حقل السعر الأدنى يجب أن يكون رقمًا',
            'min_price.min' => 'حقل السعر الأدنى يجب أن يكون أكبر من أو يساوي الصفر',
            'max_price.required' => 'حقل السعر الأعلى مطلوب',
            'max_price.numeric' => 'حقل السعر الأعلى يجب أن يكون رقمًا',
            'max_price.min' => 'حقل السعر الأعلى يجب أن يكون أكبر من الصفر',
            'max_price.gt' => 'حقل السعر الأعلى يجب أن يكون أكبر من السعر الأدنى',
            'fee.required' => 'حقل الرسوم مطلوب',
            'fee.numeric' => 'حقل الرسوم يجب أن يكون رقمًا',
            'fee.min' => 'حقل الرسوم يجب أن يكون أكبر من أو يساوي الصفر',
        ]);


        $additionalFees = AdditionalFees::find($id);

        $additionalFees->update($validatedData);

        Alert::success('عملية ناجحة', 'تم إضافة ' . $this->getModuleName() . ' بنجاح');

        return to_route('admin.' . $this->getRouteParent() . '.index');
    }
    public function destroy($id): RedirectResponse
    {
        $additionalFees = AdditionalFees::where('id', $id);
        $additionalFees->delete();
        Alert::success('عملية ناجحة', 'تم حذف ' . $this->getModuleName() . ' بنجاح');

        return back();
    }

    private function getPageTitle(): string
    {
        return '   مصاريف اضافيه - الدفع عند الاستلام  ';
    }

    private function getModuleName(): string
    {
        return 'مصاريف اضافيه';
    }

    private function getRouteParent(): string
    {
        return 'additionalfees';
    }
}
