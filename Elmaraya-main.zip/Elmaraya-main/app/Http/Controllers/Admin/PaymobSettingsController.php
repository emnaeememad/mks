<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests\Admin\Blog\StoreBlogRequest;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\UpdateSettingsRequest;
use App\Models\MarayaSetting;
use App\Models\PaymentMethodType;
 use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;

class PaymobSettingsController extends Controller
{
    public function index(): View
    {

        return view('dashboard.settings_paymob.index', [
            'collection' => PaymentMethodType::descOrder()->paginate(40),
            'pageTitle' => $this->getPageTitle(),
            'moduleName' => $this->getModuleName(),
            'routeParent' => $this->getRouteParent(),
            'routeModelName' => 'paymob',
        ]);
    }

    public function create(): View
    {
        return view('dashboard.settings_paymob.create', [

            'pageTitle' => $this->getPageTitle(),
            'moduleName' => $this->getModuleName(),
            'routeParent' => $this->getRouteParent(),
            'routeModelName' => 'paymob',
        ]);
    }

    public function store(Request $request): RedirectResponse
    {


        $validatedData = $request->validate([
            'name_ar' => ['required', 'unique:payment_method_types', 'max:255'],
            'integration_id' => ['required', 'unique:payment_method_types', 'max:255'],
            'iframe_id' => [ 'unique:payment_method_types', 'max:255'],
            'type' => [ 'required'], 
            'image' => [ 'image'],
        ], [
            'name_ar.required' => 'حقل الاسم بالعربية مطلوب',
            'name_ar.unique' => 'حقل الاسم بالعربية يجب أن يكون فريدًا',
            'name_ar.max' => 'حقل الاسم بالعربية يجب أن لا يتجاوز 255 حرفًا',
            'integration_id.required' => 'حقل معرّف التكامل مطلوب',
            'integration_id.unique' => 'حقل معرّف التكامل يجب أن يكون فريدًا',
            'integration_id.max' => 'حقل معرّف التكامل يجب أن لا يتجاوز 255 حرفًا',
            'iframe_id.unique' => 'حقل معرّف الإطار يجب أن يكون فريدًا',
            'iframe_id.max' => 'حقل معرّف الإطار يجب أن لا يتجاوز 255 حرفًا',
            'image.required' => 'حقل الصورة مطلوب',
            'type.required' => 'حقل النوع مطلوب',
            'image.image' => 'يجب أن يكون حقل الصورة صورة',
        ]);

        $paymentMethodType = new PaymentMethodType();
        $paymentMethodType->name_ar = $validatedData['name_ar'];
        $paymentMethodType->integration_id = $validatedData['integration_id'];
        $paymentMethodType->iframe_id = $validatedData['iframe_id'];
        $paymentMethodType->name =  $validatedData['name_ar'];;
        $paymentMethodType->type =  $validatedData['type'];;
        $paymentMethodType->payment_method_id =  2;


        // Handle image upload
        if ($request->hasFile('image')) {
            $image = $request->file('image'); 
            $paymentMethodType->image = $image;
        }

        $paymentMethodType->save();

        Alert::success('عملية ناجحة', 'تم إضافة ' . $this->getModuleName() . ' بنجاح');

        return to_route('admin.' . $this->getRouteParent() . '.index');
    }

    public function show(Blog $blog): View
    {
        return view('dashboard.blog_modules.show', [
            'model' => $blog->load([
                'category' => fn ($q) => $q->withTrashed(),
                'author' => fn ($q) => $q->withTrashed(),
            ]),
            'moduleName' => $this->getModuleName(),
            'checks' => $this->getChecksData(),
        ]);
    }

    public function edit($paymentMethodType): View
    {
        $paymentMethodType = PaymentMethodType::where('id', $paymentMethodType)->first();

        return view('dashboard.settings_paymob.edit', [

            'paymentMethodType' => $paymentMethodType,
            'pageTitle' => $this->getPageTitle(),
            'moduleName' => $this->getModuleName(),
            'routeParent' => $this->getRouteParent(),
            'routeModelName' => 'paymob',
        ]);
    }
 
    public function update(Request $request, $paymentMethodTypeId): RedirectResponse
    {

         $validatedData = $request->validate([
            'name_ar' => ['required', 'max:255'],
            'integration_id' => ['required',  'max:255'],
            'iframe_id' => [ 'max:255'],
            'image' => [  'image'],
            'type' => [  'required'],
        ], [
            'name_ar.required' => 'حقل الاسم بالعربية مطلوب',
            'name_ar.unique' => 'حقل الاسم بالعربية يجب أن يكون فريدًا',
            'name_ar.max' => 'حقل الاسم بالعربية يجب أن لا يتجاوز 255 حرفًا',
            'integration_id.required' => 'حقل معرّف التكامل مطلوب',
            'integration_id.unique' => 'حقل معرّف التكامل يجب أن يكون فريدًا',
            'integration_id.max' => 'حقل معرّف التكامل يجب أن لا يتجاوز 255 حرفًا',
            'iframe_id.unique' => 'حقل معرّف الإطار يجب أن يكون فريدًا',
            'iframe_id.max' => 'حقل معرّف الإطار يجب أن لا يتجاوز 255 حرفًا',
            'image.required' => 'حقل الصورة مطلوب',
            'image.image' => 'يجب أن يكون حقل الصورة صورة',
            'type.required' => 'حقل النوع مطلوب',
        ]);

         $paymentMethodType = PaymentMethodType::find($paymentMethodTypeId);
        $paymentMethodType->name_ar = $validatedData['name_ar'];
        $paymentMethodType->integration_id = $validatedData['integration_id'];
        $paymentMethodType->iframe_id = $validatedData['iframe_id'];
        $paymentMethodType->name =  $validatedData['name_ar'];;
        $paymentMethodType->payment_method_id =  2;
        $paymentMethodType->type =  $validatedData['type'];;

 
        // Handle image upload
        if ($request->hasFile('image')) {
            $image = $request->file('image'); 
            $paymentMethodType->image = $image;
        }

        $paymentMethodType->save();

        Alert::success('عملية ناجحة', 'تم إضافة ' . $this->getModuleName() . ' بنجاح');

        return to_route('admin.' . $this->getRouteParent() . '.index');
    }
    public function destroy( $paymentMethodType): RedirectResponse
    {
        $paymentMethodType = PaymentMethodType::where('id', $paymentMethodType);
        $paymentMethodType->delete();
        Alert::success('عملية ناجحة', 'تم حذف ' . $this->getModuleName() . ' بنجاح');

        return back();
    }

    private function getPageTitle(): string
    {
        return 'اعدادات باي موب';
    }

    private function getModuleName(): string
    {
        return 'باي موب';
    }

    private function getRouteParent(): string
    {
        return 'paymob_settings';
    }

 
}
