<?php

namespace App\Http\Controllers\Admin;

use App\Enum\BookType;
use App\Models\Orders;
use App\Enum\OrderType;
use App\Models\BookRequest;
use Illuminate\Http\Request;
use App\Enum\BookRequestStatus;
use Illuminate\Contracts\View\View;
use App\Http\Controllers\Controller;
use RealRashid\SweetAlert\Facades\Alert;

class BookRequestsController extends Controller
{
    public function index(): View
    {
        // return view('dashboard.book_requests.index', [
        //     'collection' => BookRequest::descOrder()->with([
        //         'book' => fn ($q) => $q->withTrashed()->with([
        //             'author' => fn ($a) => $a->withTrashed(),
        //             'category' => fn ($a) => $a->withTrashed(),
        //         ]),
        //     ])->paginate(20),
        // ]);

        $orders_books = Orders::ofType(OrderType::book)
            ->where('book_type', BookType::physical)->with([
                'orderBooks.book.author' => function ($query) {
                    $query->withTrashed();
                }, 'orderBooks.book.category' => function ($query) {
                    $query->withTrashed();
                },
                'payment' => fn ($q) => $q->withTrashed(),
                'customer',
            ])
            ->descOrder()
            ->paginate(20);

        return view('dashboard.orders_book_requests.index', [
            'collection' =>  $orders_books,
        ]);
    }

    public function show($id): View
    {
        $order_books = Orders::with([
            'orderBooks.book.author' => function ($query) {
                $query->withTrashed();
            }, 'orderBooks.book.category' => function ($query) {
                $query->withTrashed();
            },
            'payment' => fn ($q) => $q->withTrashed(),
            'customer',
            'shippingDetails.shipping',
            'additionalFee'
            
        ])
            ->find($id);

         if ($order_books == null) {
            abort(404);
        }

        return view('dashboard.orders_book_requests.show', [
            'model' =>  $order_books,
            'statuses' => BookRequestStatus::getTypesAndTranslated(),
        ]);

        // $bookRequest->update([
        //     'read_at' => now()->toDateTimeString(),
        //     'read_by' => auth('admins')->id(),
        // ]);

        // return view('dashboard.book_requests.show', [
        //     'model' => $bookRequest->load([
        //         'book' => fn ($q) => $q->withTrashed()->with([
        //             'author' => fn ($a) => $a->withTrashed(),
        //             'category' => fn ($a) => $a->withTrashed(),
        //         ]),
        //     ]),
        //     'statuses' => BookRequestStatus::getTypesAndTranslated(),
        // ]);
    }

    public function update(Orders $order, Request $request)
    {
        $order->update([
            'status' => $request->status,
        ]);
        Alert::success('success', 'تم تحديث حالة الطلب بنجاح');

        return back();
    }
}
