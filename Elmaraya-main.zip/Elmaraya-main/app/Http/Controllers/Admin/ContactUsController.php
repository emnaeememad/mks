<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ContactUs;
use Illuminate\Contracts\View\View;

class ContactUsController extends Controller
{
    public function index(): View
    {
        return view('dashboard.contact_us.index', [
            'collection' => ContactUs::descOrder()->paginate(20),
        ]);
    }

    public function show(ContactUs $contactUs): View
    {
        $contactUs->update([
            'read_at' => now(),
            'read_by' => auth('admins')->id(),
        ]);

        return view('dashboard.contact_us.show', [
            'model' => $contactUs,
        ]);
    }
}
