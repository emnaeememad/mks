<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\DigitalTraining\StoreDigitalTrainingRequest;
use App\Http\Requests\Admin\DigitalTraining\UpdateDigitalTrainingRequest;
use App\Models\Trainer;
use App\Services\DigitalTrainingService;
use Exception;
use RealRashid\SweetAlert\Facades\Alert;

class DigitalTrainingController extends Controller
{
    private DigitalTrainingService $digitalTrainingService;

    public function __construct(DigitalTrainingService $digitalTrainingService)
    {
        $this->digitalTrainingService = $digitalTrainingService;
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {
            return view('dashboard.digital_trainings.index', [
                'collection' => $this->digitalTrainingService->getDigtals(),
            ]);
        } catch (\Exception $e) {
            throw $e->getMessage();
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('dashboard.digital_trainings.create', [
            'trainers' => Trainer::all(),
            'digitals' => $this->digitalTrainingService->getAllDigtals(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreDigitalTrainingRequest $request)
    {
        try {
            $this->digitalTrainingService->createDigitalTraining($request->validated());
            Alert::success('عملية ناجحة', 'تم إضافة المحاضرة إلي قائمة المحاضرات بنجاح');
            return redirect()->route('admin.digital-training.index');
        } catch (\Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    /**
     * Display the specified resource.
     */
    public function show($digital_training)
    {
        try {
            return view('dashboard.digital_trainings.show', [
                'model' => $this->digitalTrainingService->find($digital_training),
            ]);
        } catch (\Exception $e) {
            throw $e->getMessage();
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($digital_training)
    {
        try {
            return view('dashboard.digital_trainings.edit', [
                'model' => $this->digitalTrainingService->find($digital_training),
                'trainers' => Trainer::all(),
                'digitals' => $this->digitalTrainingService->getAllDigtalsIgnorCurrent($digital_training),
            ]);
        } catch (\Exception $e) {
            throw $e->getMessage();
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDigitalTrainingRequest $request, $digital_training)
    {
        try {
            $this->digitalTrainingService->update($request->validated(), $digital_training);
            Alert::success('عملية ناجحة', 'تم تعديل المحاضرة بنجاح');
            return redirect()->route('admin.digital-training.index');
        } catch (\Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($digital_training)
    {
        try {
            $this->digitalTrainingService->find($digital_training)->delete();
            Alert::success('عملية ناجحة', 'تم حذف المحاضرة بنجاح');
            return redirect()->route('admin.digital-training.index');
        } catch (\Exception $e) {
            throw $e->getMessage();
        }
    }
    
}
