<?php

namespace App\Http\Controllers\Admin;

use Throwable;
use App\Models\Author;
use App\Models\Workshop;
use App\Enum\PublishType;
use Illuminate\Http\Request;
use App\Models\WorkshopOnline;
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Models\WorkshopOnlineVideos;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Requests\Admin\WorkshopOnline\StoreWorkshopOnlineRequest;
use App\Http\Requests\Admin\WorkshopOnline\UpdateWorkshopOnlineRequest;

class WorkshopsOnlineController extends Controller
{
    public function index(): View
    {
        return view('dashboard.workshops_online.index', [
            'collection' => WorkshopOnline::descOrder()->paginate(20),
        ]);
    }

    public function create(): View
    {
        return view('dashboard.workshops_online.create', [
            'authors' => Author::individuals()->get(['id', 'name_ar']),
        ]);
    }

    public function store(StoreWorkshopOnlineRequest $request): RedirectResponse
    {
        DB::beginTransaction();

        try {
            $workshop = new WorkshopOnline();
            $workshop->title = $request->title;
            $workshop->price = $request->price;
            $workshop->author_id = $request->author_id;
            $workshop->availability_start_date = $request->availability_start_date;
            $workshop->availability_end_date = $request->availability_end_date;
            $workshop->description = $request->description;
            $workshop->save();

            // Store videos if available
            if ($request->hasFile('videos')) {
                foreach ($request->file('videos') as $video) {
                    $workshopVideo = new WorkshopOnlineVideos();
                    $workshopVideo->workshop_online_id = $workshop->id;
                    $workshopVideo->title = $video->getClientOriginalName(); // Or any other logic to get video title
                    $workshopVideo->url = $video; // Store video file
                    $workshopVideo->save();
                }
            }

            DB::commit();
        } catch (Throwable $e) {
            DB::rollBack();
            // Log or handle the exception as needed
            return redirect()->back()->with('error', 'An error occurred while saving the workshop. Please try again.');
        }

        return redirect()->route('admin.workshopsonline.index')->with('success', 'Workshop created successfully');
    }

    public function show(WorkshopOnline $workshoponline): View
    {
        return view('dashboard.workshops_online.show', [
            'model' => $workshoponline->load('videos'),
        ]);
    }

    public function edit(WorkshopOnline $workshoponline): View
    {

        $workshoponline->load('videos');

        return view('dashboard.workshops_online.edit', [
            'authors' => Author::individuals()->get(['id', 'name_ar']),
            'model' => $workshoponline,
            'existingVideos' => $workshoponline->videos,
        ]);
    }

    public function update(UpdateWorkshopOnlineRequest $request, WorkshopOnline $workshoponline): RedirectResponse
    {

        DB::beginTransaction();

        try {
            $workshop = $workshoponline->load('videos');
            $workshop->title = $request->title;
            $workshop->price = $request->price;
            $workshop->author_id = $request->author_id;
            $workshop->availability_start_date = $request->availability_start_date;
            $workshop->availability_end_date = $request->availability_end_date;
            $workshop->description = $request->description;
            $workshop->save();
            $existingVideoIds = collect($request->existing_videos)->pluck('id')->toArray();

            // Retrieve all existing video IDs from the database
            $allExistingVideoIds = $workshoponline->videos->pluck('id')->toArray();
            $videosToDelete = null;
            if (!$request->has('existing_videos')) {
                foreach ($allExistingVideoIds as $videoId) {
                    // Delete video by ID
                    $video = WorkshopOnlineVideos::find($videoId);
                    $video->deleteVideo($videoId);

                    $video->delete();
                }
            } else {
                // Find video IDs to delete (those that are in $allExistingVideoIds but not in $existingVideoIds)
                $videosToDelete = array_diff($allExistingVideoIds, $request->existing_videos);
            }

            if ($request->existing_videos == $allExistingVideoIds) {
                $videosToDelete = null;
            }
            // Delete videos from the database and disk
            if ($videosToDelete) {
                foreach ($videosToDelete as $videoId) {
                    // Delete video by ID
                    $video = WorkshopOnlineVideos::find($videoId);
                    $video->deleteVideo($videoId);

                    $video->delete();
                }
            }


            // Store videos if available
            if ($request->hasFile('videos')) {
                foreach ($request->file('videos') as $video) {
                    $workshopVideo = new WorkshopOnlineVideos();
                    $workshopVideo->workshop_online_id = $workshop->id;
                    $workshopVideo->title = $video->getClientOriginalName(); // Or any other logic to get video title
                    $workshopVideo->url = $video; // Store video file
                    $workshopVideo->save();
                }
            }

            DB::commit();
        } catch (Throwable $e) {
            DB::rollBack();
            Log::error($e);
            Alert::error('عملية فاشلة', 'فشل في التعديل');
            // Log or handle the exception as needed
            return redirect()->back()->with('error', 'An error occurred while saving the workshop. Please try again.');
        }

        return redirect()->route('admin.workshopsonline.index')->with('success', 'Workshop created successfully');
    }

    public function destroy(WorkshopOnline $workshoponline): RedirectResponse
    {
        $workshoponline->delete();
        Alert::success('عملية ناجحة', 'تم حذف بيانات التدريب بنجاح');

        return back();
    }
    public function changedistinctive(Request $request)
    {
        try {
            $model = WorkshopOnline::find($request->id);

            // Toggle the value of the is_distinctive attribute
            $model->is_distinctive = !$model->is_distinctive;
            $model->save();

            return response()->json(['success' => true]);
        } catch (\Exception $ex) {
            Log::error($ex);
            return response()->json(['success' => false, 'message' => 'failed to change', 'details' => $ex->getMessage()]);
        }
    }
}
