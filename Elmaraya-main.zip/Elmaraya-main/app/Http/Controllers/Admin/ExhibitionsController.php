<?php

namespace App\Http\Controllers\Admin;

use App\Enum\BlogModules;
use App\Http\Controllers\Controller;
use App\Traits\BlogModulesControllerTrait;
use Illuminate\Support\Collection;

class ExhibitionsController extends Controller
{
    use BlogModulesControllerTrait;

    private function getPageTitle(): string
    {
        return 'المعارض';
    }

    private function getCategories(): Collection
    {
        return collect([]);
    }

    private function getShowCategories(): bool
    {
        return false;
    }

    private function getModuleName(): string
    {
        return 'المعرض';
    }

    private function getRouteParent(): string
    {
        return 'exhibitions';
    }

    private function getModuleType(): string
    {
        return BlogModules::exhibitions;
    }

    private function getChecksData(): array
    {
        return [
            'is_recommended' => [
                'key' => 'تظهر كمقترح',
                'values' => [
                    '1' => 'نعم',
                    '0' => 'لا',
                ],
            ],
        ];
    }
}
