<?php

namespace App\Http\Controllers\Admin;

use App\Models\Book;
use App\Models\Author;
use App\Models\Category;
use App\Models\Shipping;
use App\Enum\PublishStatus;
use Illuminate\Http\Request;
use App\Enum\BookRequestType;
use App\Enum\CategoryModules;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Requests\Admin\Book\StoreBookRequest;
use App\Http\Requests\Admin\Book\UpdateBookRequest;
use App\Http\Requests\Admin\Shipping\StoreShippingRequest;
use App\Http\Requests\Admin\Shipping\UpdateShippingRequest;

class ShippingController extends Controller
{
    public function index(): View
    {
        return view('dashboard.shipping.index', [
            'collection' => Shipping::descOrder()->paginate(20),
        ]);
    }

    public function create(): View
    {
        return view('dashboard.shipping.create');
    }

    public function store(StoreShippingRequest $request): RedirectResponse
    {
        Shipping::create([
            ...$request->validated(),
        ]);
        Alert::success('عملية ناجحة', 'تم اضافة منطقة الشحن بنجاح');

        return to_route('admin.shipping.index');
    }

    public function edit(Shipping $shipping): View
    {
        return view('dashboard.shipping.edit', [
            'model' => $shipping
        ]);
    }

    public function update(UpdateShippingRequest $request,Shipping $shipping): RedirectResponse
    {
       
        $shipping->update([
            ...$request->validated(),
         ]);
        Alert::success('عملية ناجحة', 'تم تعديل منطقة الشحن بنجاح');

        return back();
    }

    public function destroy(Shipping $shipping): RedirectResponse
    {
        $shipping->delete();
        Alert::success('عملية ناجحة', 'تم حذف منطقة الشحن بنجاح');

        return to_route('admin.shipping.index');
    } 
}
