<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\UpdateHomeHtmlRequest;
use App\Models\HomeHtml;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;

class HomeHtmlController extends Controller
{
    public function getForm(): View
    {
        return view('dashboard.home-html-section', [
            'html' => HomeHtml::first() ?? HomeHtml::create([
                'html' => '',
            ])->first(),
        ]);
    }

    public function update(UpdateHomeHtmlRequest $request): RedirectResponse
    {
        HomeHtml::first()->update(
            $request->validated()
        );
        alert()->success('تم التعديل بنجاح');

        return back();

    }
}
