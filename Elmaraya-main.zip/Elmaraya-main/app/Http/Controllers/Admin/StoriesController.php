<?php

namespace App\Http\Controllers\Admin;

use App\Models\Story;
use App\Models\Author;
use App\Models\Category;
use App\Enum\PublishType;
use App\Enum\PublishStatus;
use Illuminate\Http\Request;
use App\Enum\CategoryModules;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Requests\Admin\Story\StoreStoryRequest;
use App\Http\Requests\Admin\Story\UpdateStoryRequest;

class StoriesController extends Controller
{
    public function index(): View
    {
        return view('dashboard.stories.index', [
            'collection' => Story::descOrder()->paginate(20),
        ]);
    }

    public function create(): View
    {
        return view('dashboard.stories.create', [
            'authors' => Author::individuals()->get(['id', 'name_ar']),
            'categories' => Category::where('module', CategoryModules::stories)->get(['id', 'name_ar']),
            'publishStatuses' => PublishStatus::getStatusesTranslated(),
            'publishTypes' => PublishType::getTypesTranslated(),
        ]);
    }

    public function store(StoreStoryRequest $request): RedirectResponse
    {
        $slugs = [
            'slug_ar' => Story::slug($request->get('title_ar')),
            'slug_en' => Story::slug($request->get('title_en')),
        ];
        if (Story::isNotSlugable($slugs)) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        Story::create([
            ...$request->validated(),
            ...$slugs,
            'file_length' => "{$request->get('hours', '0')}:{$request->get('minutes', '0')}:{$request->get('seconds', '0')}",
        ]);
        Alert::success('عملية ناجحة', 'تم إضافة الحكاية بنجاح');

        return to_route('admin.stories.index');
    }

    public function show(Story $story): View
    {
        return view('dashboard.stories.show', [
            'model' => $story,
        ]);
    }

    public function edit(Story $story): View
    {
        return view('dashboard.stories.edit', [
            'authors' => Author::individuals()->get(['id', 'name_ar']),
            'categories' => Category::where('module', CategoryModules::stories)->get(['id', 'name_ar']),
            'publishStatuses' => PublishStatus::getStatusesTranslated(),
            'model' => $story,
            'publishTypes' => PublishType::getTypesTranslated(),
        ]);
    }

    public function update(UpdateStoryRequest $request, Story $story): RedirectResponse
    {
        $slugs = [
            'slug_ar' => Story::slug($request->get('title_ar')),
            'slug_en' => Story::slug($request->get('title_en')),
        ];
        if (Story::isNotSlugable($slugs, $story->id)) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        $story->update([
            ...$request->validated(),
            ...$slugs,
            'file_length' => "{$request->get('hours', '0')}:{$request->get('minutes', '0')}:{$request->get('seconds', '0')}",
        ]);
        Alert::success('عملية ناجحة', 'تم تعديل بيانات الحكاية بنجاح');

        return back();
    }

    public function destroy(Story $story): RedirectResponse
    {
        $story->delete();
        Alert::success('عملية ناجحة', 'تم حذف بيانات الحكاية بنجاح');

        return back();
    }
    public function changedistinctive(Request $request)
    {
        try {
            $model = Story::find($request->id);

    // Toggle the value of the is_distinctive attribute
                $model->is_distinctive = !$model->is_distinctive;
                $model->save();
    
            return response()->json(['success' => true]);
        }catch(\Exception $ex) {
            Log::error($ex);
            return response()->json(['success' => false, 'message' => 'failed to change', 'details' => $ex->getMessage()]);

        }
    
    }
}
