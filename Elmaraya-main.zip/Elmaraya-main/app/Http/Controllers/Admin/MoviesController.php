<?php

namespace App\Http\Controllers\Admin;

use App\Models\Movie;
use App\Models\Category;
use App\Enum\PublishType;
use App\Models\MovieImage;
use App\Models\MovieVideo;
use App\Enum\PublishStatus;
use Illuminate\Http\Request;
use App\Enum\CategoryModules;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Database\Eloquent\Collection;
use App\Http\Requests\Admin\Movie\StoreMovieRequest;
use App\Http\Requests\Admin\Movie\UpdateMovieRequest;

class MoviesController extends Controller
{
    public function index(): View
    {
        return view('dashboard.movies.index', [
            'collection' => Movie::descOrder()->paginate(20),
        ]);
    }
    private function getCategories(): Collection
    {
        return Category::where('module', CategoryModules::movies)->get(['id', 'name_ar']);
    }
    public function create(): View
    {
        $categories = $this->getCategories();
        return view('dashboard.movies.create', [
            'publishStatuses' => PublishStatus::getStatusesTranslated(),
            'publishTypes' => PublishType::getTypesTranslated(),
            'categories' => $categories,
        ]);
    }

    public function store(StoreMovieRequest $request): RedirectResponse
    {
        $slugs = [
            'slug_ar' => Movie::slug($request->get('name_ar')),
            'slug_en' => Movie::slug($request->get('name_en')),
        ];
        if (
            Movie::isNotSlugable(data: $slugs)
        ) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        $movie = Movie::create([
            ...$request->validated(),
            ...$slugs,
        ]);
        // Attach categories to the movie
        $movie->categories()->sync($request->input('categories', []));

        foreach ($request->file('files', []) as $file) {
            MovieImage::create([
                'file' => $file,
                'movie_id' => $movie->id,
            ]);
        }

        foreach ($request->file('videos', []) as $video) {
            MovieVideo::create([
                'file' => $video,
                'movie_id' => $movie->id,
            ]);
        }

        Alert::success('عملية ناجحة', 'تم إضافة الفليم بنجاح');

        return to_route('admin.movies.index');
    }

    public function show(Movie $movie): View
    {
        return view('dashboard.movies.show', [
            'model' => $movie->load('images', 'videos'),
        ]);
    }

    public function edit(Movie $movie): View
    {
        $categories = $this->getCategories();

        return view('dashboard.movies.edit', [
            'model' => $movie->load('images', 'videos'),
            'publishStatuses' => PublishStatus::getStatusesTranslated(),
            'publishTypes' => PublishType::getTypesTranslated(),
            'categories' => $categories,

        ]);
    }

    public function update(UpdateMovieRequest $request, Movie $movie): RedirectResponse
    {
        $slugs = [
            'slug_ar' => Movie::slug($request->get('name_ar')),
            'slug_en' => Movie::slug($request->get('name_en')),
        ];
        if (
            Movie::isNotSlugable(
                data: $slugs,
                ignoredId: $movie->id,
            )
        ) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        $removedImageIds = array_filter(explode(',', $request->get('removeImages', '')));
        MovieImage::whereIn('id', $removedImageIds)->get()->map(fn ($moveImage) => $moveImage->delete());
        $removedVideoIds = array_filter(explode(',', $request->get('removeVideos', '')));
        MovieVideo::whereIn('id', $removedVideoIds)->get()->map(fn ($moveVideo) => $moveVideo->delete());
        $movie->update([
            ...$request->validated(),
            ...$slugs,
        ]);
        foreach ($request->file('files', []) as $file) {
            MovieImage::create([
                'file' => $file,
                'movie_id' => $movie->id,
            ]);
        }

        foreach ($request->file('videos', []) as $video) {
            MovieVideo::create([
                'file' => $video,
                'movie_id' => $movie->id,
            ]);
        }
        // Attach categories to the movie
        $movie->categories()->sync($request->input('categories', []));
    

        Alert::success('عملية ناجحة', 'تم تعديل الفليم بنجاح');

        return back();
    }

    public function destroy(Movie $movie): RedirectResponse
    {
        $movie->delete();
        Alert::success('عملية ناجحة', 'تم حذف الفليم بنجاح');

        return to_route('admin.movies.index');
    }
    public function changedistinctive(Request $request)
    {
        try {
            $model = Movie::find($request->id);

    // Toggle the value of the is_distinctive attribute
                $model->is_distinctive = !$model->is_distinctive;
                $model->save();
    
            return response()->json(['success' => true]);
        }catch(\Exception $ex) {
            Log::error($ex);
            return response()->json(['success' => false, 'message' => 'failed to change', 'details' => $ex->getMessage()]);

        }
    
    }
}
