<?php

namespace App\Http\Controllers\Admin;

use App\Enum\CategoryModules;
use App\Enum\PublishStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\MarayaBook\StoreMarayaBookRequest;
use App\Http\Requests\Admin\MarayaBook\UpdateMarayaBookRequest;
use App\Models\Author;
use App\Models\Category;
use App\Models\MarayaBook;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;

class MarayaBooksController extends Controller
{
    public function index(): View
    {
        return view('dashboard.maraya_books.index', [
            'collection' => MarayaBook::with([
                'category' => fn ($c) => $c->withTrashed()->select('id', 'name_ar'),
                'author' => fn ($c) => $c->withTrashed()->select('id', 'name_ar'),
            ])->descOrder()->paginate(20),
        ]);
    }

    public function create(): View
    {
        return view('dashboard.maraya_books.create', [
            'categories' => Category::where('module', CategoryModules::maraya_books)->get(['id', 'name_ar']),
            'authors' => Author::individuals()->get(['id', 'name_ar']),
            'publishStatuses' => PublishStatus::getStatusesTranslated(),
        ]);
    }

    public function store(StoreMarayaBookRequest $request): RedirectResponse
    {
        $slugs = [
            'slug_ar' => MarayaBook::slug($request->get('title_ar')),
            'slug_en' => MarayaBook::slug($request->get('title_en')),
        ];
        if (MarayaBook::isNotSlugable(data: $slugs)) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        MarayaBook::create([
            ...$request->validated(),
            ...$slugs,
        ]);
        Alert::success('عملية ناجحة', 'تم إضافة كتاب المرايا بنجاح');

        return to_route('admin.maraya_books.index');
    }

    public function show(MarayaBook $marayaBook): View
    {
        return view('dashboard.maraya_books.show', [
            'model' => $marayaBook->load([
                'category' => fn ($c) => $c->withTrashed()->select('id', 'name_ar'),
                'author' => fn ($c) => $c->withTrashed()->select('id', 'name_ar'),
            ]),
        ]);
    }

    public function edit(MarayaBook $marayaBook): View
    {
        return view('dashboard.maraya_books.edit', [
            'model' => $marayaBook,
            'categories' => Category::where('module', CategoryModules::maraya_books)->get(['id', 'name_ar']),
            'authors' => Author::individuals()->get(['id', 'name_ar']),
            'publishStatuses' => PublishStatus::getStatusesTranslated(),
        ]);
    }

    public function update(UpdateMarayaBookRequest $request, MarayaBook $marayaBook): RedirectResponse
    {
        $slugs = [
            'slug_ar' => MarayaBook::slug($request->get('title_ar')),
            'slug_en' => MarayaBook::slug($request->get('title_en')),
        ];
        if (MarayaBook::isNotSlugable($slugs, $marayaBook->id)) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        $marayaBook->update([
            ...$request->validated(),
            ...$slugs,
        ]);
        Alert::success('عملية ناجحة', 'تم تعديل بيانات كتاب المرايا بنجاح');

        return back();
    }

    public function destroy(MarayaBook $marayaBook): RedirectResponse
    {
        $marayaBook->delete();
        Alert::success('عملية ناجحة', 'تم حذف كتاب المرايا بنجاح');

        return back();
    }
}
