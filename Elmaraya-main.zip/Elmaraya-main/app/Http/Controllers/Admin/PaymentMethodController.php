<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\PaymentMethod\StorePaymentMethodRequest;
use App\Http\Requests\Admin\PaymentMethod\UpdatePaymentMethodRequest;
use App\Models\PaymentMethod;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;

class PaymentMethodController extends Controller
{
    public function index(): View
    {
        $collection = PaymentMethod::descOrder()->paginate(20);

        return view('dashboard.payment_methods.index', ['collection' => $collection]);
    }

    public function create(): View
    {
        return view('dashboard.payment_methods.create');
    }

    public function store(StorePaymentMethodRequest $request): RedirectResponse
    {
        PaymentMethod::create($request->validated());
        Alert::success('عملية ناجحة', 'تم إضافة وسيلة الدفع بنجاح');

        return to_route('admin.payment_methods.index');
    }

    public function show(PaymentMethod $paymentMethod): View
    {
        return view('dashboard.payment_methods.show', ['model' => $paymentMethod]);
    }

    public function edit(PaymentMethod $paymentMethod): View
    {
        return view('dashboard.payment_methods.edit', [
            'model' => $paymentMethod,
        ]);
    }

    public function update(UpdatePaymentMethodRequest $request, PaymentMethod $paymentMethod): RedirectResponse
    {
        $paymentMethod->update($request->validated());
        Alert::success('عملية ناجحة', "تم تعديل وسيلة الدفع ({$paymentMethod->name_ar}) بنجاح");

        return back();
    }

    public function destroy(PaymentMethod $paymentMethod): RedirectResponse
    {
        $paymentMethod->delete();
        $msg = 'تم حذف وسيلة الدفع بنجاح';
        Alert::success('عملية ناجحة', $msg);

        return back();
    }
}
