<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Admin\StoreAdminRequest;
use App\Http\Requests\Admin\Admin\UpdateAdminRequest;
use App\Http\Requests\Admin\Admin\UpdatePasswordRequest;
use App\Http\Requests\Admin\Admin\UpdateProfileRequest;
use App\Models\Admin;
use App\Models\Role;
use Exception;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Hash;
use RealRashid\SweetAlert\Facades\Alert;

class AdminsController extends Controller
{
    public function index(): View
    {
        return view('dashboard.admins.index', [
            'collection' => Admin::where('id', '!=', auth('admins')->id())->with('role')->descOrder()->paginate(20),
        ]);
    }

    public function create(): View
    {
        return view('dashboard.admins.create', [
            'roles' => Role::get(['id', 'name_ar']),
        ]);
    }

    public function store(StoreAdminRequest $request): RedirectResponse
    {
        Admin::create($request->validated());
        Alert::success('عملية ناجحة', 'تم إضافة المسؤول بنجاح');

        return redirect(route('admin.admins.index'));
    }

    public function show(Admin $admin): View
    {
        return view('dashboard.admins.show', [
            'model' => $admin->load('role'),
        ]);
    }

    public function edit(Admin $admin): View
    {
        return view('dashboard.admins.edit', [
            'roles' => Role::get(['id', 'name_ar']),
            'model' => $admin,
        ]);
    }

    public function update(UpdateAdminRequest $request, Admin $admin): RedirectResponse
    {
        $admin->update($request->validated());
        Alert::success('عملية ناجحة', 'تم تعديل بيانات المسؤول بنجاح');

        return back();
    }

    public function destroy(Admin $admin): RedirectResponse
    {
        $admin->deletePhoto();
        $admin->delete();
        Alert::success('عملية ناجحة', 'تم حذف المسؤول بنجاح');

        return back();
    }

    public function getProfile(): View
    {
        return view('dashboard.admins.profile', [
            'roles' => Role::get(['id', 'name_ar']),
        ]);
    }

    public function updateProfile(UpdateProfileRequest $request): RedirectResponse
    {
        $admin = auth('admins')->user();
        $admin->update($request->validated());
        Alert::success('عملية ناجحة', 'تم تعديل بياناتك بنجاح');

        return back();
    }

    public function updatePassword(UpdatePasswordRequest $request): RedirectResponse
    {
        $admin = auth('admins')->user();
        try {
            if (Hash::check($request->get('old_password'), $admin->password)) {
                $admin->password = $request->password;
                $admin->save();
                Alert::success('عملية ناجحة', 'تم تعديل كلمة المرور بنجاح');

                return back();
            } else {
                Alert::error('خطاء', 'كلمة المرور القديمة غير صحيحة');

                return back();
            }
        } catch (Exception $e) {
            Alert::error('خطاء', $e->getMessage());

            return back();
        }
    }
}
