<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Subscription\StoreSubscriptionRequest;
use App\Http\Requests\Admin\Subscription\UpdateSubscriptionRequest;
use App\Models\Subscription;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;

class SubscriptionsController extends Controller
{
    public function index(): View
    {
        return view('dashboard.subscriptions.index', [
            'collection' => Subscription::descOrder()->paginate(20),
        ]);
    }

    public function create(): View
    {
        return view('dashboard.subscriptions.create');
    }

    public function store(StoreSubscriptionRequest $request): RedirectResponse
    {
        $data = $request->validated();
        // Set the value of 'use_price_after' based on the checkbox
        $data['use_price_after'] = $request->has('use_price_after');
        Subscription::create($data);
        Alert::success('عملية ناجحة', 'تم اضافة الاشتراك بنجاح');

        return to_route('admin.subscriptions.index');
    }

    public function show(Subscription $subscription): View
    {
        return view('dashboard.subscriptions.show', [
            'model' => $subscription,
        ]);
    }

    public function edit(Subscription $subscription): View
    {
        return view('dashboard.subscriptions.edit', [
            'model' => $subscription,
        ]);
    }

    public function update(UpdateSubscriptionRequest $request, Subscription $subscription): RedirectResponse
    {
        $data = $request->validated();

        // Set the value of 'use_price_after' based on the checkbox
        $data['use_price_after'] = $request->has('use_price_after');

        $subscription->update($data);
        Alert::success('عملية ناجحة', 'تم تعديل الاشتراك بنجاح');

        return back();
    }

    public function destroy(Subscription $subscription): RedirectResponse
    {
        $subscription->delete();
        Alert::success('عملية ناجحة', 'تم حذف الاشتراك بنجاح');

        return to_route('admin.subscriptions.index');
    }
}
