<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\UpdateAboutRequest;
use App\Models\MarayaAbout;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;

class MarayaAboutController extends Controller
{
    public function index(): View
    {
        return view('dashboard.maraya-about.index', [
            'marayaAbout' => MarayaAbout::first() ?? MarayaAbout::create([
                'about_ar' => '',
                'about_en' => '',
            ])->first(),
        ]);
    }

    public function editAbout(UpdateAboutRequest $request): RedirectResponse
    {
        MarayaAbout::first()->update(
            $request->validated()
        );
        alert()->success('تم التعديل بنجاح');

        return back();
    }
}
