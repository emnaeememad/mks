<?php

namespace App\Http\Controllers\Admin;

use App\Models\Book;
use App\Models\Author;
use App\Models\Category;
use App\Enum\PublishStatus;
use Illuminate\Http\Request;
use App\Enum\BookRequestType;
use App\Enum\CategoryModules;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Requests\Admin\Book\StoreBookRequest;
use App\Http\Requests\Admin\Book\UpdateBookRequest;

class BooksController extends Controller
{
    public function index(Request $request): View
    {
        return view('dashboard.books.index', [
            'collection' => Book::descOrder()
            ->when($request->has('filter'), function ($query) use ($request) {
                $filter = $request->input('filter');
                $query->where('request_type',   $filter);
            })
            ->paginate(20),
        ]);
    }

    public function create(): View
    {
        
        return view('dashboard.books.create', [
            'publishStatuses' => PublishStatus::getStatusesTranslated(),
            'categories' => Category::where('module', CategoryModules::books)->get(['id', 'name_ar']),
            'authors' => Author::individuals()->get(['id', 'name_ar']),
            'requestTypes' => BookRequestType::getTypesTranslated(),
            'authorCompanies' => Author::companies()->get(),
        ]);
    }

    public function store(StoreBookRequest $request): RedirectResponse
    {
        $slugs = [
            'slug_ar' => Book::slug($request->get('name_ar')),
            'slug_en' => Book::slug($request->get('name_en')),
        ];
        if (
            Book::isNotSlugable(data: $slugs)
        ) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        Book::create([
            ...$request->validated(),
            ...$slugs,
        ]);
        Alert::success('عملية ناجحة', 'تم اضافة الكتاب بنجاح');

        return to_route('admin.books.index');
    }

    public function show(Book $book): View
    {
        return view('dashboard.books.show', [
            'model' => $book->load([
                'category' => fn ($q) => $q->withTrashed(),
                'author' => fn ($q) => $q->withTrashed(),
            ]),
        ]);
    }

    public function edit(Book $book): View
    {
        return view('dashboard.books.edit', [
            'model' => $book,
            'publishStatuses' => PublishStatus::getStatusesTranslated(),
            'categories' => Category::where('module', CategoryModules::books)->get(['id', 'name_ar']),
            'authors' => Author::individuals()->get(['id', 'name_ar']),
            'requestTypes' => BookRequestType::getTypesTranslated(),
            'authorCompanies' => Author::companies()->get(),

        ]);
    }

    public function update(UpdateBookRequest $request, Book $book): RedirectResponse
    {
        $slugs = [
            'slug_ar' => Book::slug($request->get('name_ar')),
            'slug_en' => Book::slug($request->get('name_en')),
        ];
        if (
            Book::isNotSlugable(data: $slugs, ignoredId: $book->id)
        ) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        $book->update([
            ...$request->validated(),
            ...$slugs,
        ]);
        Alert::success('عملية ناجحة', 'تم تعديل الكتاب بنجاح');

        return back();
    }

    public function destroy(Book $book): RedirectResponse
    {
        $book->delete();
        Alert::success('عملية ناجحة', 'تم حذف الكتاب بنجاح');

        return to_route('admin.books.index');
    }
    public function changedistinctive(Request $request)
    {
        try {
            $model = Book::find($request->id);

    // Toggle the value of the is_distinctive attribute
                $model->is_distinctive = !$model->is_distinctive;
                $model->save();
    
            return response()->json(['success' => true]);
        }catch(\Exception $ex) {
            Log::error($ex);
            return response()->json(['success' => false, 'message' => 'failed to change', 'details' => $ex->getMessage()]);

        }
    
    }
}
