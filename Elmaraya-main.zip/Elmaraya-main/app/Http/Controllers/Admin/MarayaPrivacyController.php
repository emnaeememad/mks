<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\UpdatePrivacyRequest;
use App\Models\MarayaPrivacy;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;

class MarayaPrivacyController extends Controller
{
    public function index(): View
    {
        return view('dashboard.maraya-privacy.index', [
            'marayaPrivacy' => MarayaPrivacy::first() ?? MarayaPrivacy::create([
                'privacy_ar' => '',
                'privacy_en' => '',
            ])->first(),
        ]);
    }

    public function editPrivacy(UpdatePrivacyRequest $request): RedirectResponse
    {
        MarayaPrivacy::first()->update(
            $request->validated()
        );
        alert()->success('تم التعديل بنجاح');

        return back();
    }
}
