<?php

namespace App\Http\Controllers\Admin;

use App\Enum\BlogModules;
use App\Http\Controllers\Controller;
use App\Traits\BlogModulesControllerTrait;
use Illuminate\Support\Collection;

class SeminarsController extends Controller
{
    use BlogModulesControllerTrait;

    private function getPageTitle(): string
    {
        return 'الندوات';
    }

    private function getCategories(): Collection
    {
        return collect([]);
    }

    private function getShowCategories(): bool
    {
        return false;
    }

    private function getModuleName(): string
    {
        return 'ندوة';
    }

    private function getRouteParent(): string
    {
        return 'seminars';
    }

    private function getModuleType(): string
    {
        return BlogModules::seminars;
    }

    private function getChecksData(): array
    {
        return [
            'is_recommended' => [
                'key' => 'تظهر كمقترح',
                'values' => [
                    '1' => 'نعم',
                    '0' => 'لا',
                ],
            ],
        ];
    }
}
