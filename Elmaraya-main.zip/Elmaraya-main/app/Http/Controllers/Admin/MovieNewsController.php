<?php

namespace App\Http\Controllers\Admin;

use App\Enum\BlogModules;
use App\Http\Controllers\Controller;
use App\Traits\BlogModulesControllerTrait;
use Illuminate\Support\Collection;

class MovieNewsController extends Controller
{
    use BlogModulesControllerTrait;

    private function getPageTitle(): string
    {
        return 'الأخبار';
    }

    private function getCategories(): Collection
    {
        return collect([]);
    }

    private function getShowCategories(): bool
    {
        return false;
    }

    private function getModuleName(): string
    {
        return 'خبر';
    }

    private function getRouteParent(): string
    {
        return 'movie_news';
    }

    private function getModuleType(): string
    {
        return BlogModules::movie_news;
    }

    private function getChecksData(): array
    {
        return [
            'is_recommended' => [
                'key' => 'تظهر كمقترح',
                'values' => [
                    '1' => 'نعم',
                    '0' => 'لا',
                ],
            ],
        ];
    }
}
