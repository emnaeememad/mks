<?php

namespace App\Http\Controllers\Admin;

use App\Models\Movie;
use App\Models\Category;
use App\Enum\PublishType;
use App\Enum\MovieModules;
use App\Models\MovieImage;
use App\Models\MovieVideo;
use App\Enum\PublishStatus;
use Illuminate\Http\Request;
use App\Enum\CategoryModules;
use App\Enum\LongMovieModules;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Scopes\NullMovieModuleScope;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Database\Eloquent\Collection;
use App\Http\Requests\Admin\LongMovie\StoreMovieRequest;
use App\Http\Requests\Admin\LongMovie\UpdateMovieRequest;

class LongMoviesController extends Controller
{
    public function index(): View
    {
        // dd(Movie::descOrder()->paginate(20));
        return view('dashboard.longmovies.index', [
            'collection' => Movie::withoutGlobalScope(NullMovieModuleScope::class)
                ->where('module_type', $this->getModuleType())->descOrder()->paginate(20),
        ]);
    }
    private function getModuleType(): string
    {
        return LongMovieModules::longmovies;
    }

    private function getCategories(): Collection
    {
        return Category::where('module', CategoryModules::longmovies)->get(['id', 'name_ar']);
    }
    public function create(): View
    {
        $categories = $this->getCategories();
        return view('dashboard.longmovies.create', [
            'publishStatuses' => PublishStatus::getStatusesTranslated(),
            'publishTypes' => PublishType::getTypesTranslated(),
            'categories' => $categories,
        ]);
    }

    public function store(StoreMovieRequest $request ): RedirectResponse
    {
           // Validate the request data
        $slug_ar = Movie:: slug($request->get('name_ar'));
        $slug_en = Movie:: slug($request->get('name_en'));
         $slugs = [
            'slug_ar' => $slug_ar,
            'slug_en' => $slug_en,
        ];
        if (
            Movie::isNotSlugable(data: $slugs)
        ) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }

        $movie = Movie::create([
            ...$request->validated(),
            ...$slugs,
        ]);
        $movie->update([
            'module_type' => $this->getModuleType(),

        ]);
         // Attach categories to the movie
         if($request->has('categories')){
            $movie->categories()->sync($request->input('categories', []));

         }


        foreach ($request->file('files', []) as $file) {
            MovieImage::create([
                'file' => $file,
                'movie_id' => $movie->id,
            ]);
        }

        foreach ($request->file('videos', []) as $video) {
            MovieVideo::create([
                'file' => $video,
                'movie_id' => $movie->id,
            ]);
        }

        Alert::success('عملية ناجحة', 'تم إضافة الفليم بنجاح');

        return to_route('admin.longmovies.index');
    }

    public function show($movie): View
    {
        $movie = Movie::withoutGlobalScope(NullMovieModuleScope::class)->find($movie);

        return view('dashboard.longmovies.show', [
            'model' => $movie->load('images', 'videos'),
        ]);
    }

    public function edit($movie): View
    {
        $categories = $this->getCategories();
        $movie = Movie::withoutGlobalScope(NullMovieModuleScope::class)->find($movie);
        return view('dashboard.longmovies.edit', [
            'model' => $movie->load('images', 'videos'),
            'publishStatuses' => PublishStatus::getStatusesTranslated(),
            'publishTypes' => PublishType::getTypesTranslated(),
            'categories' => $categories,

        ]);
    }

    public function update(UpdateMovieRequest $request, $movie): RedirectResponse
    {
        $movie = Movie::withoutGlobalScope(NullMovieModuleScope::class)->find($movie);

        $slugs = [
            'slug_ar' => Movie::slug($request->get('name_ar')),
            'slug_en' => Movie::slug($request->get('name_en')),
        ];
        if (
            Movie::isNotSlugable(
                data: $slugs,
                ignoredId: $movie->id,
            )
        ) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        $removedImageIds = array_filter(explode(',', $request->get('removeImages', '')));
        MovieImage::whereIn('id', $removedImageIds)->get()->map(fn ($moveImage) => $moveImage->delete());
        $removedVideoIds = array_filter(explode(',', $request->get('removeVideos', '')));
        MovieVideo::whereIn('id', $removedVideoIds)->get()->map(fn ($moveVideo) => $moveVideo->delete());
        $movie->update([
            ...$request->validated(),
            ...$slugs,
        ]);
        foreach ($request->file('files', []) as $file) {
            MovieImage::create([
                'file' => $file,
                'movie_id' => $movie->id,
            ]);
        }

        foreach ($request->file('videos', []) as $video) {
            MovieVideo::create([
                'file' => $video,
                'movie_id' => $movie->id,
            ]);
        }
        // Attach categories to the movie
        if($request->has('categories')){
            $movie->categories()->sync($request->input('categories', []));

        }


        Alert::success('عملية ناجحة', 'تم تعديل الفليم بنجاح');

        return back();
    }

    public function destroy($movie): RedirectResponse
    {
        $movie = Movie::withoutGlobalScope(NullMovieModuleScope::class)->find($movie);
        $movie->delete();
        Alert::success('عملية ناجحة', 'تم حذف الفليم بنجاح');

        return to_route('admin.longmovies.index');
    }
    public function changedistinctive(Request $request)
    {
        try {
            $model = Movie::withoutGlobalScope(NullMovieModuleScope::class)->find($request->id);

            // Toggle the value of the is_distinctive attribute
            $model->is_distinctive = !$model->is_distinctive;
            $model->save();

            return response()->json(['success' => true]);
        } catch (\Exception $ex) {
            Log::error($ex);
            return response()->json(['success' => false, 'message' => 'failed to change', 'details' => $ex->getMessage()]);
        }
    }
}
