<?php

namespace App\Http\Controllers\Admin;

use App\Enum\BookType;
use App\Models\Orders;
use App\Enum\OrderType;
use App\Models\BookPurchase;
use Illuminate\Contracts\View\View;
use App\Http\Controllers\Controller;

class BookPurchasesController extends Controller
{
    public function index(): View
    {
        $orders_books = Orders::ofType(OrderType::book)
        ->where('book_type', BookType::digital)->with([
            'orderBooks.book.author' => function ($query) {
                $query->withTrashed();
            }, 'orderBooks.book.category' => function ($query) {
                $query->withTrashed();
            },
            'payment' => fn ($q) => $q->withTrashed(),
            'customer',
        ])
            ->descOrder()
            ->paginate(20);

        return view('dashboard.orders.index', [
            'collection' =>  $orders_books,
        ]);

       
    }

    public function show($id): View
    {
        $order_books = Orders::with([
            'orderBooks.book.author' => function ($query) {
                $query->withTrashed();
            }, 'orderBooks.book.category' => function ($query) {
                $query->withTrashed();
            },
            'payment' => fn ($q) => $q->withTrashed(),
            'customer',
        ])
            ->find($id);

        if ($order_books == null) {
            abort(404);
        }

 
        return view('dashboard.orders.show', [
            'model' =>  $order_books,
        ]);

    
    }
}
