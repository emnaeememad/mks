<?php

namespace App\Http\Controllers\Admin;

use App\Enum\BlogModules;
use App\Http\Controllers\Controller;
use App\Traits\BlogModulesControllerTrait;
use Illuminate\Support\Collection;

class FestivalsController extends Controller
{
    use BlogModulesControllerTrait;

    private function getPageTitle(): string
    {
        return 'المهرجانات';
    }

    private function getCategories(): Collection
    {
        return collect([]);
    }

    private function getShowCategories(): bool
    {
        return false;
    }

    private function getModuleName(): string
    {
        return 'مهرجان';
    }

    private function getRouteParent(): string
    {
        return 'festivals';
    }

    private function getModuleType(): string
    {
        return BlogModules::festivals;
    }

    private function getChecksData(): array
    {
        return [
            'is_recommended' => [
                'key' => 'تظهر كمقترح',
                'values' => [
                    '1' => 'نعم',
                    '0' => 'لا',
                ],
            ],
        ];
    }
}
