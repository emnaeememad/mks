<?php

namespace App\Http\Controllers\Admin;

use App\Models\Author;
use App\Models\Workshop;
use App\Enum\PublishType;
use Illuminate\Http\Request;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Requests\Admin\Workshop\StoreWorkshopRequest;
use App\Http\Requests\Admin\Workshop\UpdateWorkshopRequest;

class WorkshopsController extends Controller
{
    public function index(): View
    {
        return view('dashboard.workshops.index', [
            'collection' => Workshop::descOrder()->paginate(20),
        ]);
    }

    public function create(): View
    {
        return view('dashboard.workshops.create', [
            'authors' => Author::individuals()->get(['id', 'name_ar']),
            'publishTypes' => PublishType::getTypesTranslated(),
        ]);
    }

    public function store(StoreWorkshopRequest $request): RedirectResponse
    {
        $slugs = [
            'slug_ar' => Workshop::slug($request->get('title_ar')),
            'slug_en' => Workshop::slug($request->get('title_en')),
        ];
        if (Workshop::isNotSlugable($slugs)) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        Workshop::create([
            ...$request->validated(),
            ...$slugs,
        ]);
        Alert::success('عملية ناجحة', 'تم إضافة التدريب بنجاح');

        return to_route('admin.workshops.index');
    }

    public function show(Workshop $workshop): View
    {
        return view('dashboard.workshops.show', [
            'model' => $workshop,
        ]);
    }

    public function edit(Workshop $workshop): View
    {
        return view('dashboard.workshops.edit', [
            'authors' => Author::individuals()->get(['id', 'name_ar']),
            'model' => $workshop,
            'publishTypes' => PublishType::getTypesTranslated(),
        ]);
    }

    public function update(UpdateWorkshopRequest $request, Workshop $workshop): RedirectResponse
    {
        $slugs = [
            'slug_ar' => Workshop::slug($request->get('title_ar')),
            'slug_en' => Workshop::slug($request->get('title_en')),
        ];
        if (Workshop::isNotSlugable($slugs, $workshop->id)) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        $workshop->update([
            ...$request->validated(),
            ...$slugs,
        ]);
        Alert::success('عملية ناجحة', 'تم تعديل بيانات التدريب بنجاح');

        return back();
    }

    public function destroy(Workshop $workshop): RedirectResponse
    {
        $workshop->delete();
        Alert::success('عملية ناجحة', 'تم حذف بيانات التدريب بنجاح');

        return back();
    }
    public function changedistinctive(Request $request)
    {
        try {
            $model = Workshop::find($request->id);

    // Toggle the value of the is_distinctive attribute
                $model->is_distinctive = !$model->is_distinctive;
                $model->save();
    
            return response()->json(['success' => true]);
        }catch(\Exception $ex) {
            Log::error($ex);
            return response()->json(['success' => false, 'message' => 'failed to change', 'details' => $ex->getMessage()]);

        }
    
    }
}
