<?php

namespace App\Http\Controllers\Admin;

use App\Enum\CategoryModules;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Category\StoreCategoryRequest;
use App\Http\Requests\Admin\Category\UpdateCategoryRequest;
use App\Models\Category;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Storage;
use RealRashid\SweetAlert\Facades\Alert;

class CategoriesController extends Controller
{
    public function index(): View
    {
        $collection = Category::orderPositionAsc()->get();

        return view('dashboard.categories.index', ['collection' => $collection]);
    }

    public function create(): View
    {
        return view('dashboard.categories.create', [
            'categories' => Category::canBeParent()->descOrder()->select('id', 'name_ar', 'module')->get(),
            'modules' => CategoryModules::getModulesTranslated(),
        ]);
    }

    public function store(StoreCategoryRequest $request): RedirectResponse
    {
        if ($request->has('parent_id') && $request->has('module')) {
            $parentCategory = Category::find($request->get('parent_id'));
            if ($parentCategory && $parentCategory->module != $request->get('module')) {
                Alert::error('عملية فاشلة', 'يرجي إختيار قسم رئيسي تابع لنفس القسم يتبع');

                return back()->withInput();
            }
        }
        $data = $request->validated();
        if($request->hasFile('image')){
            $data['image'] = Storage::disk('public')->put('categories', $request->file('image'));
        }
        Category::create($data);

        Alert::success('عملية ناجحة', 'تم إضافة القسم بنجاح');

        return redirect(route('admin.categories.index'));
    }

    public function show(Category $category): View
    {
        return view('dashboard.categories.show', ['model' => $category->load('parentCategory')]);
    }

    public function edit(Category $category): View
    {
        return view('dashboard.categories.edit', [
            'categories' => Category::where('id', '!=', $category->id)->canBeParent()->descOrder()->select('id', 'name_ar', 'module')->get(),
            'modules' => CategoryModules::getModulesTranslated(),
            'model' => $category,
        ]);
    }

    public function update(UpdateCategoryRequest $request, Category $category): RedirectResponse
    {
        if ($request->has('parent_id') && $request->has('module')) {
            $parentCategory = Category::find($request->get('parent_id'));
            if ($parentCategory && $parentCategory->module != $request->get('module')) {
                Alert::error('عملية فاشلة', 'يرجي إختيار قسم رئيسي تابع لنفس القسم يتبع');

                return back()->withInput();
            }
        }
        $data = $request->validated();
        if($request->hasFile('image')){
            $data['image'] = Storage::disk('public')->put('categories', $request->file('image'));
        }
        $category->update($data);
        Alert::success('عملية ناجحة', "تم تعديل القسم ({$category->name_ar}) بنجاح");

        return back();
    }

    public function destroy(Category $category): RedirectResponse
    {
        $msg = '';
        $deleted = false;
        if ($category->blogs()->count() > 0) {
            $msg = 'لا يمكن حذف القسم لان يوجد به مدونات او ندوات او اخبار إلخ...';
        } elseif ($category->books()->count() > 0) {
            $msg = 'لا يمكن حذف القسم لان يوجد به كتب';
        } elseif ($category->marayaBooks()->count() > 0) {
            $msg = 'لا يمكن حذف القسم لان يوجد به كتب المرايا';
        } elseif ($category->stories()->count() > 0) {
            $msg = 'لا يمكن حذف القسم لان يوجد به حكايات';
        } else {
            $msg = 'تم حذف القسم بنجاح';
            $deleted = true;
            $category->delete();
        }

        $deleted ? Alert::success('عملية ناجحة', $msg) : Alert::success('عملية فاشلة', $msg);

        return back();
    }

    public function ordering()
    {
        collect(request()->get('categories', []))->each(function ($category) {
            if (isset($category['id']) && isset($category['position']) && is_numeric($category['position'])) {
                Category::where('id', $category['id'])->update(['position' => $category['position']]);
            }
        });

        return response()->json(['message' => 'تم تعديل الترتيب بنجاح!', 'status' => 'success']);
    }
}
