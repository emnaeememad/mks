<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Blog;
use App\Models\BookPurchase;
use App\Models\BookRequest;
use App\Models\WorkshopRequest;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use RealRashid\SweetAlert\Facades\Alert;

class LoginController extends Controller
{
    public function showLoginForm(): View
    {
        return view('auth.login');
    }

    public function postLogin(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);

        if (Auth::guard('admins')->attempt(['email' => $request->email, 'password' => $request->password], $request->get('remember'))) {
            return redirect()->intended(route('admin.dashboard'));
        }

        Alert::error('خطأ', 'البيانات المدخلة غير صحيحة');

        return to_route('admin.login');
    }

    public function dashboard()
    {
        $mostBlogsViews = Blog::where('module_type', 'blogs')->orderByDesc('total_views')->take(7)->get(['title_ar', 'total_views']);

        return view('dashboard.dashboard.index', [
            'book_request' => BookRequest::descOrder()->take(5)->get(),
            'book_purchase' => BookPurchase::descOrder()->take(5)->get(),
            'workshop_training_request' => WorkshopRequest::descOrder()->take(5)->get(),
            'most_views_names' => $mostBlogsViews->pluck('title_ar')->toArray(),
            'most_views_numbers' => $mostBlogsViews->pluck('total_views')->toArray(),
        ]);
    }

    public function logout()
    {
        Auth::guard('admins')->logout();
        Session::flush();
        Alert::success('تم الخروج بنجاح');

        return redirect()->route('admin.login');
    }

    public function upload(Request $request)
    {
        $fileName = $request->file('file')->getClientOriginalName();
        $path = $request->file('file')->storeAs('uploads', $fileName, 'public');

        return response()->json(['location' => "/storage/$path"]);
    }
}
