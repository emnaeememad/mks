<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\UpdateSettingsRequest;
use App\Models\MarayaSetting;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;

class MarayaSettingsController extends Controller
{
    public function index(): View
    {
        return view('dashboard.settings.index', [
            'collection' => MarayaSetting::all(),
        ]);
    }

    public function editSettings(UpdateSettingsRequest $request): RedirectResponse
    {
        foreach ($request->validated() as $key => $value) {
            MarayaSetting::updateOrCreate([
                'key' => $key,
            ], [
                'input_label' => MarayaSetting::getInputLabel($key),
                'value' => $value,
                'input_type' => MarayaSetting::getInputType($key),
            ]);
        }
        Alert::success('تم تحديث الاعدادات بنجاح', 'تم تحديث الاعدادات بنجاح');

        return back();
    }
}
