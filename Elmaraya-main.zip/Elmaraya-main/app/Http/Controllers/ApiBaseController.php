<?php

namespace App\Http\Controllers;

use Illuminate\Http\JsonResponse;

class ApiBaseController extends Controller
{
    protected function successResponse(
        mixed $data,
        ?string $message = null
    ): JsonResponse {
        return response()->json([
            'data' => $data,
            'message' => $message ?? __('api.success'),
            'statusCode' => 200,
        ]);
    }

    protected function failResponse(
        ?string $message = null,
        ?int $code = 400
    ): JsonResponse {
        return response()->json([
            'data' => [],
            'message' => $message ?? __('api.failure'),
            'statusCode' => $code,
        ], $code);
    }
}
