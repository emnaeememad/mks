<?php

namespace App\Models;

use App\Enum\CategoryModules;
use App\Traits\NameAttributeTrait;
use App\Traits\SortingTrait;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;

class Category extends Model
{
    use HasFactory, NameAttributeTrait, SoftDeletes, SortingTrait;

    protected $fillable = [
        'name_ar',
        'name_en',
        'image',
        'parent_id',
        'module',
        'position',
        'is_active'
    ];

    public function parentCategory(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function blogs(): HasMany
    {
        return $this->hasMany(Blog::class, 'category_id');
    }

    public function books(): HasMany
    {
        return $this->hasMany(Book::class, 'category_id');
    }
    public function nadaras(): HasMany
    {
        return $this->hasMany(Nadara::class, 'category_id');
    }

    public function marayaBooks(): HasMany
    {
        return $this->hasMany(MarayaBook::class, 'category_id');
    }

    public function stories(): HasMany
    {
        return $this->hasMany(Story::class, 'category_id');
    }

    public function scopeCanBeParent(Builder $query): Builder
    {
        return $query->whereNull('parent_id')->orderBy('position', 'asc');
    }

    public function moduleName(): Attribute
    {
        return Attribute::make(
            get: fn () => CategoryModules::getModule($this->module)
        );
    }

    public function isParent(): bool
    {
        return self::class::where('parent_id', $this->id)->exists();
    }

    public function children()
    {
        return $this->hasMany(self::class, 'parent_id')->orderBy('position', 'asc');
    }

    public function scopeOrderPositionAsc(Builder $query): Builder
    {
        return $query->orderBy('position', 'asc');
    }

    public function scopeOrderPositionDesc(Builder $query): Builder
    {
        return $query->orderBy('position', 'desc');
    }

    public function getImageUrlAttribute(){
        return $this->image ? url('storage/' . $this->image) : null;
    }
}
