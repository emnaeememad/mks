<?php

namespace App\Models;

use App\Enum\NadaraTypes;
use App\Enum\PublishType;
use App\Traits\DatesFormat;
use App\Traits\ImageCopyrightsAttributeTrait;
use App\Traits\Published;
use App\Traits\SearchableTrait;
use App\Traits\SlugableTrait;
use App\Traits\SortingTrait;
use App\Traits\TitleAttributeTrait;
use App\Traits\UploadTrait;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\UploadedFile;

class Nadara extends Model
{
    use DatesFormat,
        HasFactory,
        ImageCopyrightsAttributeTrait,
        Published,
        SearchableTrait,
        SlugableTrait,
        SoftDeletes,
        SortingTrait,
        TitleAttributeTrait,
        UploadTrait;

    protected $fillable = [
        'cover',
        'main_image',
        'thumb_image',
        'video',
        'slug_ar',
        'slug_en',
        'description_ar',
        'description_en',
        'title_ar',
        'title_en',
        'category_id',
        'author_id',
        'total_views',
        'total_plays',
        'total_shares',
        'status',
        'type',
        'is_featured',
        'is_home',
        'is_recommended',
        'is_home_slider',
        'video_duration',
        'post_date',
        'publish_type',
        'main_image_copyrights_ar',
        'main_image_copyrights_en',
        'thumb_image_copyrights_ar',
        'thumb_image_copyrights_en',
        'cover_copyrights_ar',
        'cover_copyrights_en',
        'featured_group',
        'youtube_link'
    ];

    protected $appends = [
        'thumb_image_url',
        'main_image_url',
        'cover_url',
        'created_format',
        'small_title',
        'slug_translated',
    ];

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'category_id')->withTrashed();
    }

    public function author(): BelongsTo
    {
        return $this->belongsTo(Author::class, 'author_id')->withTrashed();
    }

    public function scopeType(Builder $query, string $type): Builder
    {
        return $query->where('type', $type);
    }

    public function scopeMostRead(Builder $query): Builder
    {
        return $query->orderBy('total_views', 'desc');
    }

    public function getSearchableColumns(): array
    {
        return [
            'title_ar',
            'title_en',
        ];
    }

    public function SetCoverAttribute($image)
    {
        if ($this->cover) {
            $this->deleteFromPublic($this->cover);
        }

        return $this->attributes['cover'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'nadara/cover-images') :
            $image;
    }

    public function coverUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->cover)
        );
    }

    public function SetMainImageAttribute($image)
    {
        if ($this->main_image) {
            $this->deleteFromPublic($this->main_image);
        }

        return $this->attributes['main_image'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'nadara/main-images') :
            $image;
    }

    public function mainImageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->main_image)
        );
    }

    public function SetThumbImageAttribute($image)
    {
        if ($this->thumb_image) {
            $this->deleteFromPublic($this->thumb_image);
        }

        return $this->attributes['thumb_image'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'nadara/thumb-images') :
            $image;
    }

    public function thumbImageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->thumb_image)
        );
    }

    public function SetVideoAttribute($file)
    {
        if ($this->file) {
            $this->deleteFromPublic($this->file);
        }

        return $this->attributes['video'] = $file instanceof UploadedFile ?
            $this->moveFileToPublic($file, 'nadara/videos') :
            $file;
    }

    public function videoUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->video)
        );
    }

    public function scopeMostPlayed(Builder $query): Builder
    {
        return $query->orderBy('total_plays', 'desc');
    }

    public function images()
    {
        return $this->hasMany(NadaraImage::class, 'nadara_id');
    }

    public function typeText(): Attribute
    {
        return Attribute::make(
            get: fn () => NadaraTypes::getTypesTranslated()[$this->type]
        );
    }

    public function scopeAll(Builder $query): Builder
    {
        return $query->where('publish_type', PublishType::all);
    }

    public function scopeMobile(Builder $query): Builder
    {
        return $query->whereIn('publish_type', [PublishType::mobile, PublishType::all]);
    }

    public function scopeWeb(Builder $query): Builder
    {
        return $query->whereIn('publish_type', [PublishType::mobile, PublishType::all]);
    }

    public function publishTypeText(): Attribute
    {
        return Attribute::make(
            get: fn () => PublishType::getTypesTranslated()[$this->publish_type]
        );
    }
}
