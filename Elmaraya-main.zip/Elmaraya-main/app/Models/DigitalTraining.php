<?php

namespace App\Models;

use App\Traits\SearchableTrait;
use App\Traits\SlugableTrait;
use App\Traits\SortingTrait;
use App\Traits\UploadTrait;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class DigitalTraining extends Model
{
    use HasFactory, SlugableTrait, SoftDeletes, SortingTrait, UploadTrait, SearchableTrait;

    const storageDisk = 'local';

    protected $fillable = [
        'slug_ar',
        'slug_en',
        'title_ar',
        'title_en',
        'description_ar',
        'description_en',
        'what_will_learn_ar',
        'what_will_learn_en',
        'intro',
        'trainer_id',
    ];

    protected $appends = [
        'intro_url',
        'slug_translated',
    ];



    public function introUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->intro)
        );
    }


    public function getSearchableColumns(): array
    {
        return [
            'slug_ar',
            'slug_en',
            'title_ar',
            'title_en',
        ];
    }

    public function trainer():BelongsTo
    {
        return $this->belongsTo(Trainer::class);
    }

    public function similars():BelongsToMany
    {
        return $this->belongsToMany(DigitalTraining::class, 'digital_training_similars', 'digital_training_id', 'similar_id');
    }

    public function lessons():HasMany
    {
        return $this->hasMany(DigitalTrainingLesson::class);
    }
}
