<?php

namespace App\Models;

use App\Traits\SortingTrait;
use App\Traits\UploadTrait;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\UploadedFile;

class AdditionalFees extends Model
{
    use HasFactory,  SortingTrait   ;

    protected $guarded = [];
    protected $table = 'additional_fees';
    
 
 

    
}
