<?php

namespace App\Models;

use App\Enum\CustomerBookStatus;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CustomerBook extends Model
{
    use HasFactory;

    protected $fillable = [
        'customer_id',
        'book_id',
        'book_access',
    ];

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class, 'customer_id');
    }

    public function book(): BelongsTo
    {
        return $this->belongsTo(Book::class, 'book_id');
    }

    public function bookAccessName(): Attribute
    {
        return Attribute::make(
            get: function () {
                return match ($this->book_access) {
                    CustomerBookStatus::full_time => 'مدي الحياة',
                    CustomerBookStatus::subscription => 'خلال الإشتراك فقط',
                    default => ''
                };
            }
        );
    }
}
