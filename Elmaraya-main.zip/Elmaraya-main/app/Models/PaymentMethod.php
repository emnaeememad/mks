<?php

namespace App\Models;

use App\Traits\UploadTrait;
use App\Traits\SortingTrait;
use Illuminate\Http\UploadedFile;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PaymentMethod extends Model
{
    use HasFactory, SoftDeletes, SortingTrait, UploadTrait;

    protected $fillable = [
        'name_ar',
        'name_en',
        'is_editable',
        'is_active',
        'slug',
        'payable_module',
        'image',
    ];

    public function SetFileAttribute($image)
    {
        if ($this->image) {
            $this->deleteFromPublic($this->image);
        }

        return $this->attributes['image'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'payment-methods') :
            $image;
    }

    public function imageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->image)
        );
    }

    public function scopePayableModule(Builder $query, string $payableModule): Builder
    {
        return $query->where('payable_module', $payableModule);
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    public function types () :HasMany
    {
        return $this->hasMany(PaymentMethodType::class, 'payment_method_id');
    }
}
 