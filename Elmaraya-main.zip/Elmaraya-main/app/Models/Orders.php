<?php

namespace App\Models;

use App\Traits\SortingTrait;
use App\Models\ShippingDetails;
use App\Traits\PaymentStatusAttribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Orders extends Model
{
    use HasFactory, PaymentStatusAttribute, SoftDeletes, SortingTrait;
    protected $table = 'orders';

    protected $guarded = [];

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class, 'customer_id');
    }
 
    public function payment(): BelongsTo
    {
        return $this->belongsTo(PaymentMethod::class, 'payment_id');
    }

    public function getStatusAttributeName()
    {
        return 'status';
    }

    public function orderBooks(): HasMany
    {
        return $this->hasMany(OrdersBooks::class, 'order_id');
    }
    public function orderWorkshopsOnline(): HasMany
    {
        return $this->hasMany(OrdersWorkshopsOnline::class, 'order_id');
    }

    public function scopeOfType(Builder $query, $order_type){
        return $query->where('order_type', $order_type);
    }
    /**
     * Get the shipping details associated with the order.
     */
    public function shippingDetails()
    {
        return $this->hasOne(ShippingDetails::class, 'order_id');
    }

    /**
     * Get the additional fee for the order.
     */
    public function additionalFee()
    {
        return $this->hasOne(AdditionalFees::class, 'id', 'additional_fee_id');
    }
}
