<?php

namespace App\Models;

use Carbon\Carbon;
use App\Traits\UploadTrait;
use App\Traits\SortingTrait;
use Laravel\Sanctum\HasApiTokens;
use App\Models\WorkshoponlinePurchase;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Customer extends Authenticatable
{
    use HasApiTokens,
        HasFactory,
        Notifiable,
        SortingTrait,
        UploadTrait;

    protected $table = 'customers';
    protected $fillable = [
        'name',
        'email',
        'phone_number',
        'password',
        'code',
        'code_valid_till',
        'verified_at',
        'sms_count',
        'last_sms_time',
        'verification_request_id',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    public function bookPurchases(): HasMany
    {
        return $this->hasMany(BookPurchase::class, 'customer_id');
    }

    public function workshoponlinePurchases(): HasMany
    {
        return $this->hasMany(WorkshoponlinePurchase::class, 'customer_id');
    }

    public function hasPurchasedWorkshoponline($Workshoponlineid)
    {
        return $this->workshoponlinePurchases()
            ->where('workshop_id', $Workshoponlineid)
            ->whereIn('status', ['purchased'])
            ->exists();
    }

    public function purchasedWorkshoponline()
    {
        // Retrieve the book IDs from purchased books
        $purchasedWorkshoponlineIds = $this->workshoponlinePurchases()
            ->whereIn('status', ['purchased'])
            ->pluck('workshop_id');

        // Retrieve the corresponding books using the Book model
        $workshopsonline = WorkshopOnline:: 
          whereIn('id', $purchasedWorkshoponlineIds)
            ->paginate(10);

        return $workshopsonline;
    }

    public function customerBooks(): HasMany
    {
        return $this->hasMany(CustomerBook::class, 'customer_id');
    }

    public function customerSubscriptions(): HasMany
    {
        return $this->hasMany(CustomerSubscription::class, 'customer_id');
    }

    public function SetPasswordAttribute($password)
    {
        return $password ? ($this->attributes['password'] = bcrypt($password)) : null;
    }

    public function canSendSms(): bool
    {
        if ($this->sms_count < 3) {
            return true;
        }

        return Carbon::parse($this->last_sms_time ?? now())->diffInMinutes(now()) >= 60;
    }

    public function codeStillValid(): bool
    {
        return Carbon::parse($this->code_valid_till) >= now();
    }

    public function scopePhone(Builder $query, string $phoneNumber): Builder
    {
        return $query->where('phone_number', $phoneNumber);
    }

    public function scopeEmail(Builder $query, string $email): Builder
    {
        return $query->where('email', $email);
    }

    public function scopeCode(Builder $query, string $code): Builder
    {
        return $query->where('code', $code);
    }

    public function scopeVerified(Builder $query): Builder
    {
        return $query->whereNotNull('verified_at');
    }
    public function imageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->image)
        );
    }

    public function hasPurchasedBook($bookId)
    {
        return $this->bookPurchases()
            ->where('book_id', $bookId)
            ->whereIn('status', ['purchased'])
            ->exists();
    }
    public function purchasedBooksAll()
    {
        // Retrieve the book IDs from purchased books
        $purchasedBooksIds = $this->bookPurchases()
            ->whereIn('status', ['purchased'])
            ->pluck('book_id');

        // Retrieve the corresponding books using the Book model
        $books = Book::published()
            ->whereIn('id', $purchasedBooksIds)
            ->paginate(10);

        return $books;
    }
}
