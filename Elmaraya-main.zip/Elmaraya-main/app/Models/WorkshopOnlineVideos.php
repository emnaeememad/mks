<?php

namespace App\Models;

use Carbon\Carbon;
use App\Enum\PublishType;
use App\Traits\Published;
use App\Traits\DatesFormat;
use App\Traits\UploadTrait;
use App\Traits\SortingTrait;
use App\Contracts\Searchable;
use App\Traits\SlugableTrait;
use App\Models\WorkshopOnline;
use App\Traits\SearchableTrait;
use Illuminate\Http\UploadedFile;
use App\Traits\BriefAttributeTrait;
use App\Traits\TitleAttributeTrait;
use Illuminate\Database\Eloquent\Model;
use App\Traits\DescriptionAttributeTrait;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class WorkshopOnlineVideos extends Model
{
    use  UploadTrait;

    protected $guarded = [];
    protected $table = 'workshop_online_videos';
    public $timestamps = false;

    public function workshoponline(): BelongsTo
    {
        return $this->belongsTo(WorkshopOnline::class, 'workshop_online_id');
    }

    public function SetUrlAttribute($image)
    {
        if ($this->url) {
            $this->deleteFromPublic($this->url);
        }

        return $this->attributes['url'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'workshoponlinevideos/urls') :
            $image;
    }
    public function urlUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->url)
        );
    }

    public function scopeDeleteVideo()
    {
        // Delete video file from disk
        $this->deleteFromPublic($this->url);
    }
}
