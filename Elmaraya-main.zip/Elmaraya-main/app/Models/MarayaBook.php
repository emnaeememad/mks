<?php

namespace App\Models;

use App\Contracts\Searchable;
use App\Traits\Published;
use App\Traits\SearchableTrait;
use App\Traits\SlugableTrait;
use App\Traits\SortingTrait;
use App\Traits\UploadTrait;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\UploadedFile;

class MarayaBook extends Model implements Searchable
{
    use HasFactory, Published, SearchableTrait, SlugableTrait, SoftDeletes, SortingTrait, UploadTrait;

    protected $fillable = [
        'slug_ar',
        'slug_en',
        'title_ar',
        'title_en',
        'main_image',
        'file',
        'category_id',
        'author_id',
        'total_downloads',
        'total_views',
        'total_shares',
        'status',
    ];

    protected $appends = [
        'main_image_url',
        'file_url',
        'slug_translated',
    ];

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'category_id')->withTrashed();
    }

    public function author(): BelongsTo
    {
        return $this->belongsTo(Author::class, 'author_id')->withTrashed();
    }

    public function SetMainImageAttribute($image)
    {
        if ($this->main_image) {
            $this->deleteFromPublic($this->main_image);
        }

        return $this->attributes['main_image'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'maraya-books') :
            $image;
    }

    public function mainImageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->main_image)
        );
    }

    public function SetFileAttribute($file)
    {
        if ($this->file) {
            $this->deleteFromPublic($this->file);
        }

        return $this->attributes['file'] = $file instanceof UploadedFile ?
            $this->moveFileToPublic($file, 'maraya-books') :
            $file;
    }

    public function fileUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->file ? $this->filePublicUrl($this->file) : ''
        );
    }

    public function getSearchableColumns(): array
    {
        return [
            'title_ar',
            'title_en',
        ];
    }
}
