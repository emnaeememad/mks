<?php

namespace App\Models;

use App\Traits\PaymentStatusAttribute;
use App\Traits\SortingTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class WorkshoponlinePurchase extends Model
{
    use HasFactory, PaymentStatusAttribute, SoftDeletes, SortingTrait;

    protected $guarded = [ ];
    protected $table ='workshop_online_purchases';
    
    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class, 'customer_id');
    }

    public function workshoponline(): BelongsTo
    {
        return $this->belongsTo(WorkshopOnline::class, 'workshop_id');
    }

    public function payment(): BelongsTo
    {
        return $this->belongsTo(PaymentMethod::class, 'payment_id');
    }

    public function getStatusAttributeName()
    {
        return 'status';
    }
}
