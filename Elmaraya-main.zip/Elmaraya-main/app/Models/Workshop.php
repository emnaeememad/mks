<?php

namespace App\Models;

use App\Contracts\Searchable;
use App\Enum\PublishType;
use App\Traits\BriefAttributeTrait;
use App\Traits\DatesFormat;
use App\Traits\DescriptionAttributeTrait;
use App\Traits\SearchableTrait;
use App\Traits\SlugableTrait;
use App\Traits\SortingTrait;
use App\Traits\TitleAttributeTrait;
use App\Traits\UploadTrait;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\UploadedFile;
use App\Traits\Published;

class Workshop extends Model implements Searchable
{
    use BriefAttributeTrait,
        DatesFormat,
        DescriptionAttributeTrait,
        HasFactory,
        SearchableTrait,
        SlugableTrait,
        SoftDeletes,
        SortingTrait,
        TitleAttributeTrait,
        UploadTrait;

    protected $fillable = [
        'cover',
        'main_image',
        'thumb_image',
        'author_id',
        'start_date',
        'end_date',
        'slug_ar',
        'slug_en',
        'title_ar',
        'title_en',
        'brief_ar',
        'brief_en',
        'description_ar',
        'description_en',
        'is_bookable',
        'is_home',
        'is_recommended',
        'is_current',
        'total_shares',
        'total_requests',
        'publish_type',
    ];

    protected $appends = [
        'thumb_image_url',
        'start_date_format',
        'end_date_format',
    ];

    public function author(): BelongsTo
    {
        return $this->belongsTo(Author::class, 'author_id')->withTrashed();
    }

    public function requests(): HasMany
    {
        return $this->hasMany(WorkshopRequest::class, 'workshop_id');
    }

    public function SetCoverAttribute($image)
    {
        if ($this->cover) {
            $this->deleteFromPublic($this->cover);
        }

        return $this->attributes['cover'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'workshop/covers') :
            $image;
    }

    public function coverUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->cover)
        );
    }

    public function SetMainImageAttribute($image)
    {
        if ($this->main_image) {
            $this->deleteFromPublic($this->main_image);
        }

        return $this->attributes['main_image'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'workshop/main-images') :
            $image;
    }

    public function mainImageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->main_image)
        );
    }

    public function SetThumbImageAttribute($image)
    {
        if ($this->thumb_image) {
            $this->deleteFromPublic($this->thumb_image);
        }

        return $this->attributes['thumb_image'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'workshop/thumb-images') :
            $image;
    }

    public function thumbImageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->thumb_image)
        );
    }

    public function getSearchableColumns(): array
    {
        return [
            'title_ar',
            'title_en',
            'brief_ar',
            'brief_en',
            'description_ar',
            'description_en',
        ];
    }

    public function StartDateFormat(): Attribute
    {
        return Attribute::make(
            get: fn () => Carbon::parse($this->end_date)->locale(request('lang') ?? 'ar')->translatedFormat('j F Y')
        );
    }

    public function EndDateFormat(): Attribute
    {
        return Attribute::make(
            get: fn () => Carbon::parse($this->end_date)->locale(request('lang') ?? 'ar')->translatedFormat('j F Y')
        );
    }

    public function scopeMostApplied(Builder $query): Builder
    {
        return $query->orderBy('total_requests', 'desc');
    }

    public function scopeAll(Builder $query): Builder
    {
        return $query->where('publish_type', PublishType::all);
    }

    public function scopeMobile(Builder $query): Builder
    {
        return $query->whereIn('publish_type', [PublishType::mobile, PublishType::all]);
    }

    public function scopeWeb(Builder $query): Builder
    {
        return $query->whereIn('publish_type', [PublishType::mobile, PublishType::all]);
    }

    public function publishTypeText(): Attribute
    {
        return Attribute::make(
            get: fn () => PublishType::getTypesTranslated()[$this->publish_type]
        );
    }
}
