<?php

namespace App\Models;

use App\Traits\NameAttributeTrait;
use App\Traits\UploadTrait;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Http\UploadedFile;

class NadaraImage extends Model
{
    use HasFactory, NameAttributeTrait, uploadTrait;

    protected $fillable = [
        'file',
        'nadara_id',
        'text_ar',
        'text_en',
    ];

    protected static function boot()
    {
        parent::boot();
        self::deleted(function (NadaraImage $model) {
            if ($model->file) {
                $model->deleteFromPublic($model->file);
            }
        });
    }

    public function nadara(): BelongsTo
    {
        return $this->belongsTo(Nadara::class, 'nadara_id');
    }

    public function SetFileAttribute($attachment)
    {
        if ($this->file) {
            $this->deleteFromPublic($this->file);
        }

        return $this->attributes['file'] = $attachment instanceof UploadedFile ?
            $this->moveFileToPublic($attachment, 'nadara-images') :
            $attachment;
    }

    public function fileUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->file)
        );
    }
}
