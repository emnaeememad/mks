<?php

namespace App\Models;

use App\Contracts\Searchable;
use App\Enum\PublishType;
use App\Models\Attributes\BlogAttribute;
use App\Traits\BriefAttributeTrait;
use App\Traits\DatesFormat;
use App\Traits\DescriptionAttributeTrait;
use App\Traits\ImageCopyrightsAttributeTrait;
use App\Traits\Published;
use App\Traits\SearchableTrait;
use App\Traits\SlugableTrait;
use App\Traits\SortingTrait;
use App\Traits\TitleAttributeTrait;
use App\Traits\UploadTrait;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Blog extends Model implements Searchable
{
    use BlogAttribute,
        BriefAttributeTrait,
        DatesFormat,
        DescriptionAttributeTrait,
        HasFactory,
        ImageCopyrightsAttributeTrait,
        Published,
        SearchableTrait,
        SlugableTrait,
        SoftDeletes,
        SortingTrait,
        TitleAttributeTrait,
        UploadTrait;

    protected $fillable = [
        'cover',
        'main_image',
        'thumb_image',
        'slug_ar',
        'slug_en',
        'title_ar',
        'title_en',
        'brief_ar',
        'brief_en',
        'description_ar',
        'description_en',
        'category_id',
        'author_id',
        'total_views',
        'total_shares',
        'status',
        'module_type',
        'is_featured',
        'is_feature_blog',
        'is_home',
        'is_recommended',
        'is_home_slider',
        'post_date',
        'publish_type',
        'translator_ar',
        'translator_en',
        'main_image_copyrights_ar',
        'main_image_copyrights_en',
        'thumb_image_copyrights_ar',
        'thumb_image_copyrights_en',
        'cover_copyrights_ar',
        'cover_copyrights_en',
        'linked_data',
    ];

    protected $casts = [
        'linked_data' => 'array',
    ];

    protected $appends = [
        'thumb_image_url',
        'main_image_url',
        'cover_url',
        'created_format',
        'small_title',
        'small_brief',
        'small_des',
        'slug_translated',
    ];

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'category_id')->withTrashed();
    }

    public function author(): BelongsTo
    {
        return $this->belongsTo(Author::class, 'author_id')->withTrashed();
    }

    public function scopeModuleType(Builder $query, string $moduleType): Builder
    {
        return $query->where('module_type', $moduleType);
    }

    public function scopeMostRead(Builder $query): Builder
    {
        return $query->orderBy('total_views', 'desc');
    }

    public function getSearchableColumns(): array
    {
        return [
            'title_ar',
            'title_en',
            'brief_ar',
            'brief_en',
            'description_ar',
            'description_en',
        ];
    }

    public function scopeAll(Builder $query)
    {
        return $query->where('publish_type', PublishType::all);
    }

    public function scopeMobile(Builder $query): Builder
    {
        return $query->whereIn('publish_type', [PublishType::mobile, PublishType::all]);
    }

    public function scopeWeb(Builder $query): Builder
    {
        return $query->whereIn('publish_type', [PublishType::mobile, PublishType::all]);
    }

    public function translator(): Attribute
    {
        return Attribute::make(
            get: fn () => app()->getLocale() == 'ar' ? $this->translator_ar : $this->translator_en
        );
    }
}
