<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\UploadTrait;
use App\Traits\SortingTrait;
use App\Traits\SlugableTrait;
use App\Traits\SearchableTrait;
use Illuminate\Http\UploadedFile;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Casts\Attribute;

class Trainer extends Model
{
    use HasFactory, SlugableTrait, SoftDeletes, SortingTrait, UploadTrait, SearchableTrait;

    const storageDisk = 'local';

    protected $fillable = [
        'slug_ar',
        'slug_en',
        'name_ar',
        'name_en',
        'photo',
        'gender',
    ];

    protected $appends = [
        'image_url',
        'small_name',
        'slug_translated',
    ];


    public function SetPhotoAttribute($image)
    {
        if ($this->photo) {
            $this->deleteFromPublic($this->photo);
        }

        return $this->attributes['photo'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'author-'.$this->type) :
            $image;
    }

    public function imageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->photo)
        );
    }


    public function getSearchableColumns(): array
    {
        return [
            'slug_ar',
            'slug_en',
            'name_ar',
            'name_en',
        ];
    }
}
