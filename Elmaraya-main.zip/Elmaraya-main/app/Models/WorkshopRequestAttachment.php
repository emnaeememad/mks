<?php

namespace App\Models;

use App\Traits\UploadTrait;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\UploadedFile;

class WorkshopRequestAttachment extends Model
{
    use HasFactory, UploadTrait;

    protected $fillable = [
        'workshop_request_id',
        'attachment',
    ];

    public function workshopRequest()
    {
        return $this->belongsTo(WorkshopRequest::class, 'workshop_request_id');
    }

    public function SetAttachmentAttribute($attachment)
    {
        if ($this->attachment) {
            $this->deleteFromPublic($this->attachment);
        }

        return $this->attributes['attachment'] = $attachment instanceof UploadedFile ?
            $this->moveFileToPublic($attachment, 'workshop-requests') :
            $attachment;
    }

    public function attachmentUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->attachment)
        );
    }
}
