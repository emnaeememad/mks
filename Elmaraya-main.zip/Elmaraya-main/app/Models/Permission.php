<?php

namespace App\Models;

use App\Enum\PermissionActions;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Permission extends Model
{
    use HasFactory;

    protected $fillable = [
        'module_name',
        'action',
        'module',
    ];

    public function actionName(): Attribute
    {
        return Attribute::make(
            get: function () {
                return match ($this->action) {
                    PermissionActions::view => 'عرض',
                    PermissionActions::add => 'إضافة',
                    PermissionActions::edit => 'تعديل',
                    PermissionActions::delete => 'حذف',
                    default => ''
                };
            }
        );
    }
}
