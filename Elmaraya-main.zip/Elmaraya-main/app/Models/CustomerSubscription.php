<?php

namespace App\Models;

use App\Traits\PaymentStatusAttribute;
use Carbon\Carbon;
use Error;
use Exception;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CustomerSubscription extends Model
{
    use HasFactory, PaymentStatusAttribute;

    protected $fillable = [
        'customer_id',
        'subscription_id',
        'price',
        'payment_id',
        'gateway_tracking',
        'payment_status',
        'subscription_status',
        'subscription_start',
        'subscription_end',
    ];

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class, 'customer_id');
    }

    public function subscription(): BelongsTo
    {
        return $this->belongsTo(Subscription::class, 'subscription_id');
    }

    public function subscriptionStatusName(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->subscription_status ? 'حالية' : 'منتهية'
        );
    }

    public function subscriptionStartFormatted(): Attribute
    {
        return Attribute::make(
            get: function () {
                try {
                    return Carbon::parse($this->subscription_start)->toDateString();
                } catch (Error|Exception $e) {
                    return $this->subscription_start;
                }
            }
        );
    }

    public function subscriptionEndFormatted(): Attribute
    {
        return Attribute::make(
            get: function () {
                try {
                    return Carbon::parse($this->subscription_end)->toDateString();
                } catch (Error|Exception $e) {
                    return $this->subscription_end;
                }
            }
        );
    }

    public function getStatusAttributeName()
    {
        return 'payment_status';
    }

    public function scopeActive(Builder $query): Builder
    {
        $start = now()->startOfDay()->toDateTimeString();
        $end = now()->endOfDay()->toDateTimeString();
        $now = \Carbon\Carbon::now();

        return $query->where('subscription_status', 1)
        ->whereIn('payment_status', ['purchased'])
        ->where('subscription_start', '<=', $now) /// check if subs has started or already started
        ->where(function ($query) use ($now) {
            $query->where('subscription_end', '>', $now) /// check if subs has not ended
                ->orWhereDate('subscription_end', $now); /// Or by nested  where is today
        }); 
    }
}
