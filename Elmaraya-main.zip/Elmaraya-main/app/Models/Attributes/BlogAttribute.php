<?php

namespace App\Models\Attributes;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Http\UploadedFile;

trait BlogAttribute
{
    public function SetCoverAttribute($image)
    {
        if ($this->cover) {
            $this->deleteFromPublic($this->cover);
        }

        return $this->attributes['cover'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'blog-covers') :
            $image;
    }

    public function coverUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->cover)
        );
    }

    public function SetMainImageAttribute($image)
    {
        if ($this->main_image) {
            $this->deleteFromPublic($this->main_image);
        }

        return $this->attributes['main_image'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'blog-main-images') :
            $image;
    }

    public function mainImageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->main_image)
        );
    }

    public function SetThumbImageAttribute($image)
    {
        if ($this->thumb_image) {
            $this->deleteFromPublic($this->thumb_image);
        }

        return $this->attributes['thumb_image'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'blog-thumb-images') :
            $image;
    }

    public function thumbImageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->thumb_image)
        );
    }
}
