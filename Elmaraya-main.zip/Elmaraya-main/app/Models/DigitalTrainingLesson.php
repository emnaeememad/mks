<?php

namespace App\Models;

use App\Traits\SearchableTrait;
use App\Traits\SlugableTrait;
use App\Traits\SortingTrait;
use App\Traits\UploadTrait;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class DigitalTrainingLesson extends Model
{
    use HasFactory, SlugableTrait, SoftDeletes, SortingTrait, UploadTrait, SearchableTrait;

    const storageDisk = 'local';

    protected $fillable = [
        'slug_ar',
        'slug_en',
        'title_ar',
        'title_en',
        'description_ar',
        'description_en',
        'video',
        'duration',
        'digital_training_id',
    ];

    protected $appends = [
        'video_url',
        'small_name',
        'slug_translated',
    ];



    public function videoUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->video)
        );
    }


    public function getSearchableColumns(): array
    {
        return [
            'slug_ar',
            'slug_en',
            'title_ar',
            'title_en',
        ];
    }

    public function digitalTraining(): BelongsTo
    {
        return $this->belongsTo(DigitalTraining::class);
    }
}
