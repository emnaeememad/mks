<?php

namespace App\Models;

use App\Traits\UploadTrait;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Http\UploadedFile;

class MovieVideo extends Model
{
    use HasFactory, UploadTrait;

    protected $fillable = [
        'file',
        'movie_id',
    ];

    protected static function boot()
    {
        parent::boot();
        self::deleted(function (MovieVideo $model) {
            if ($model->file) {
                $model->deleteFromPublic($model->file);
            }
        });
    }

    public function movie(): BelongsTo
    {
        return $this->belongsTo(Movie::class, 'movie_id');
    }

    public function SetFileAttribute($attachment)
    {
        if ($this->file) {
            $this->deleteFromPublic($this->file);
        }

        return $this->attributes['file'] = $attachment instanceof UploadedFile ?
            $this->moveFileToPublic($attachment, 'movies-videos') :
            $attachment;
    }

    public function fileUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->file)
        );
    }
}
