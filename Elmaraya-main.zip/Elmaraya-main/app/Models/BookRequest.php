<?php

namespace App\Models;

use App\Enum\BookRequestStatus;
use App\Traits\SortingTrait;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class BookRequest extends Model
{
    use HasFactory, SoftDeletes, SortingTrait;

    protected $fillable = [
        'book_id',
        'first_name',
        'last_name',
        'address',
        'phone_number',
        'email',
        'read_at',
        'read_by',
        'status',
        'gateway_tracking',
        'total_price',
        'shipping_id'
    ];

    public function book(): BelongsTo
    {
        return $this->belongsTo(Book::class, 'book_id');
    }

    public function shipping(): BelongsTo
    {
        return $this->belongsTo(Shipping::class, 'shipping_id');
    }

    

    public function readBy(): BelongsTo
    {
        return $this->belongsTo(Admin::class, 'read_by');
    }

    public function name(): Attribute
    {
        return Attribute::make(
            get: fn () => "{$this->first_name} {$this->last_name}"
        );
    }

    public function statusText(): Attribute
    {
        return Attribute::make(
            get: fn () => BookRequestStatus::getTypesTranslated()[$this->status]
        );
    }
}
