<?php

namespace App\Models;

use App\Contracts\Searchable;
use App\Enum\PublishType;
use App\Traits\DatesFormat;
use App\Traits\ImageCopyrightsAttributeTrait;
use App\Traits\Published;
use App\Traits\SearchableTrait;
use App\Traits\SlugableTrait;
use App\Traits\SortingTrait;
use App\Traits\TitleAttributeTrait;
use App\Traits\UploadTrait;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\UploadedFile;

class Story extends Model implements Searchable
{
    use DatesFormat,
        HasFactory,
        ImageCopyrightsAttributeTrait,
        Published,
        SearchableTrait,
        SlugableTrait,
        SoftDeletes,
        SortingTrait,
        TitleAttributeTrait,
        UploadTrait;

    protected $fillable = [
        'cover',
        'main_image',
        'thumb_image',
        'slug_ar',
        'slug_en',
        'title_ar',
        'title_en',
        'file',
        'file_length',
        'category_id',
        'author_id',
		'description_ar',
        'description_en',
        'total_plays',
        'total_shares',
        'status',
        'is_home',
        'is_featured',
        'is_recommended',
        'post_date',
        'publish_type',
        'is_home_slider',
        'main_image_copyrights_ar',
        'main_image_copyrights_en',
        'thumb_image_copyrights_ar',
        'thumb_image_copyrights_en',
        'cover_copyrights_ar',
        'cover_copyrights_en',
        'soundcloud_url',
        'spotify_url',
        'anghami_url',
    ];

    protected $appends = [
        'main_image_url',
        'thumb_image_url',
        'cover_url',
        'small_title',
        'slug_translated',
    ];

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'category_id')->withTrashed();
    }

    public function author(): BelongsTo
    {
        return $this->belongsTo(Author::class, 'author_id')->withTrashed();
    }

    public function hours(): Attribute
    {
        return Attribute::make(
            get: fn () => explode(':', $this->file_length)[0] ?? ''
        );
    }

    public function minutes(): Attribute
    {
        return Attribute::make(
            get: fn () => explode(':', $this->file_length)[1] ?? ''
        );
    }

    public function seconds(): Attribute
    {
        return Attribute::make(
            get: fn () => explode(':', $this->file_length)[2] ?? ''
        );
    }

    public function SetCoverAttribute($image)
    {
        if ($this->cover) {
            $this->deleteFromPublic($this->cover);
        }

        return $this->attributes['cover'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'stories-covers') :
            $image;
    }

    public function coverUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->cover)
        );
    }

    public function SetMainImageAttribute($image)
    {
        if ($this->main_image) {
            $this->deleteFromPublic($this->main_image);
        }

        return $this->attributes['main_image'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'stories/main-images') :
            $image;
    }

    public function mainImageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->main_image)
        );
    }

    public function SetThumbImageAttribute($image)
    {
        if ($this->thumb_image) {
            $this->deleteFromPublic($this->thumb_image);
        }

        return $this->attributes['thumb_image'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'stories/thumb-images') :
            $image;
    }

    public function thumbImageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->thumb_image)
        );
    }

    public function SetFileAttribute($file)
    {
        if ($this->file) {
            $this->deleteFromPublic($this->file);
        }

        return $this->attributes['file'] = $file instanceof UploadedFile ?
            $this->moveFileToPublic($file, 'stories/files') :
            $file;
    }

    public function fileUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->file)
        );
    }

    public function fileLengthTrimmed(): Attribute
    {
        return Attribute::make(
            get: function () {
                $str = '';
                if ((int) $this->hours > 0) {
                    $str .= "{$this->hours}:";
                }
                $str .= (int) $this->minutes > 0 ? "{$this->minutes}:" : '00:';
                $str .= (int) $this->seconds > 0 ? "{$this->seconds}" : '00';

                return $str;
            }
        );
    }

    public function scopeMostPlayed(Builder $query): Builder
    {
        return $query->orderBy('total_plays', 'desc');
    }

    public function getSearchableColumns(): array
    {
        return [
            'title_ar',
            'title_en',
        ];
    }

    public function scopeAll(Builder $query)
    {
        return $query->where('publish_type', PublishType::all);
    }

    public function scopeMobile(Builder $query): Builder
    {
        return $query->whereIn('publish_type', [PublishType::mobile, PublishType::all]);
    }

    public function scopeWeb(Builder $query): Builder
    {
        return $query->whereIn('publish_type', [PublishType::mobile, PublishType::all]);
    }

    public function publishTypeText(): Attribute
    {
        return Attribute::make(
            get: fn () => PublishType::getTypesTranslated()[$this->publish_type]
        );
    }
}
