<?php

namespace App\Models;

use Carbon\Carbon;
use App\Models\Category;
use App\Enum\PublishType;
use App\Traits\Published;
use App\Traits\DatesFormat;
use App\Traits\UploadTrait;
use App\Traits\SortingTrait;
use App\Contracts\Searchable;
use App\Traits\SlugableTrait;
use App\Traits\SearchableTrait;
use Illuminate\Http\UploadedFile;
use App\Traits\BriefAttributeTrait;
use App\Traits\TitleAttributeTrait;
use App\Contracts\CartItemInterface;
use App\Models\WorkshopOnlineVideos;
use App\Models\WorkshoponlinePurchase;
use Illuminate\Database\Eloquent\Model;
use App\Traits\DescriptionAttributeTrait;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class WorkshopOnline extends Model implements CartItemInterface
{
    use BriefAttributeTrait,
        DatesFormat,
        DescriptionAttributeTrait,
         // SlugableTrait,
        SortingTrait,
        TitleAttributeTrait,
        UploadTrait;

    protected $guarded = [];
    protected $table = 'workshop_online';
    
    public function author(): BelongsTo
    {
        return $this->belongsTo(Author::class, 'author_id')->withTrashed();
    }
 
    public function videos(): HasMany
    {
        return $this->hasMany(WorkshopOnlineVideos::class,'workshop_online_id', 'id');
    }
    public function scopeAccessAvailability(Builder $query): Builder
    {
        $start = now()->startOfDay()->toDateTimeString();
        $end = now()->endOfDay()->toDateTimeString();
        $now = \Carbon\Carbon::now();

        return $query->where('availability_start_date', '<=', $now) /// check if subs has started or already started
        ->where(function ($query) use ($now) {
            $query->where('availability_end_date', '>', $now) /// check if subs has not ended
                ->orWhereDate('availability_end_date', $now); /// Or by nested  where is today
        }); 
    }
    public function workshoponlinePurchases(): HasMany
    {
        return $this->hasMany(WorkshoponlinePurchase::class, 'workshop_id');
    }
    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'category_id')->withTrashed();
    }
     //cart
    // related to interface (contract ) CartItemInterface
    public function findItem($itemId)
    {
        return self::find($itemId);
    }
    //end cart
}
