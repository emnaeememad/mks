<?php

namespace App\Models;

use App\Traits\SortingTrait;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ContactUs extends Model
{
    use HasFactory, SoftDeletes, SortingTrait;

    protected $fillable = [
        'first_name',
        'last_name',
        'phone_number',
        'email',
        'message',
        'read_at',
        'read_by',
    ];

    public function admin()
    {
        return $this->belongsTo(Admin::class, 'read_by', 'id');
    }

    public function readAtHuman(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->read_at ? $this->read_at->diffForHumans() : null
        );
    }

    public function fullName(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->first_name.' '.$this->last_name
        );
    }
}
