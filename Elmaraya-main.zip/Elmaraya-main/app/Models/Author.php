<?php

namespace App\Models;

use App\Enum\WritingTypes;
use App\Traits\UploadTrait;
use App\Traits\SortingTrait;
use App\Traits\SlugableTrait;
use App\Traits\SearchableTrait;
use Illuminate\Http\UploadedFile;
use App\Traits\NameAttributeTrait;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Author extends Model
{
    use HasFactory, NameAttributeTrait, SlugableTrait, SoftDeletes, SortingTrait, UploadTrait, SearchableTrait;

    const storageDisk = 'local';

    protected $fillable = [
        'slug_ar',
        'slug_en',
        'name_ar',
        'name_en',
        'photo',
        'gender',
        'is_public',
        'is_home',
        'type',
        'writing_type',
        'is_published',
    ];

    protected $appends = [
        'image_url',
        'small_name',
        'slug_translated',
    ];

    public function blogs(): HasMany
    {
        return $this->hasMany(Blog::class, 'author_id');
    }

    public function books(): HasMany
    {
        return $this->hasMany(Book::class, 'author_id');
    } 
    public function booksHouse(): HasMany
    {
        return $this->hasMany(Book::class, 'published_house_id');
    }
    public function booksHouseFeatured(): HasMany
    {
        return $this->hasMany(Book::class, 'published_house_id');
    }
    
    public function marayaBooks(): HasMany
    {
        return $this->hasMany(MarayaBook::class, 'author_id');
    }

    public function stories(): HasMany
    {
        return $this->hasMany(Story::class, 'author_id');
    }

    public function workshops(): HasMany
    {
        return $this->hasMany(Workshop::class, 'author_id');
    }

    public function scopeIndividuals($query)
    {
        return $query->where('type', 'individual');
    }

    public function scopeCompanies($query)
    {
        return $query->where('type', 'company');
    }

    public function SetPhotoAttribute($image)
    {
        if ($this->photo) {
            $this->deleteFromPublic($this->photo);
        }

        return $this->attributes['photo'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'author-'.$this->type) :
            $image;
    }

    public function imageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->photo)
        );
    }

    public function blogsCount(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->blogs()->count() ?? 0,
        );
    }

    public function workshopsCount(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->workshops()->count() ?? 0,
        );
    }

    public function booksCount(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->books()->count() ?? 0,
        );
    }

    public function storiesCount(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->stories()->count() ?? 0,
        );
    }

    public function totalPublication(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->stories()->count() + $this->books()->count() + $this->blogs()->count() + $this->workshops()->count() ?? 0,
        );
    }

    public function writingTypeText(): Attribute
    {
        return Attribute::make(
            get: fn () => WritingTypes::getTypesTranslated()[$this->writing_type] ?? '',
        );
    }

    public function getSearchableColumns(): array
    {
        return [
            'slug_ar',
            'slug_en',
            'name_ar',
            'name_en',
        ];
    }

    public function scopeLoadAllRelations(Builder $query): Builder
    {
        return $query->with([
            'blogs' => fn ($blogd) => $blogd->withTrashed(),
            'books' => fn ($books) => $books->withTrashed(),
        ]);
    }
}
