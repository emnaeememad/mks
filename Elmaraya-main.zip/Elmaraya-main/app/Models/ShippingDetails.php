<?php

namespace App\Models;

use App\Models\Orders;
use App\Models\Shipping;
use App\Traits\Published;
use App\Traits\DatesFormat;
use App\Traits\UploadTrait;
use App\Traits\SortingTrait;
use App\Contracts\Searchable;
use App\Enum\BookRequestType;
use App\Traits\SlugableTrait;
use App\Traits\SearchableTrait;
use Illuminate\Http\UploadedFile;
use App\Traits\NameAttributeTrait;
use App\Traits\BriefAttributeTrait;
use App\Traits\TitleAttributeTrait;
use Illuminate\Database\Eloquent\Model;
use App\Traits\DescriptionAttributeTrait;
use Illuminate\Database\Eloquent\Builder;
use App\Traits\ImageCopyrightsAttributeTrait;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ShippingDetails  extends Model 
{
    use BriefAttributeTrait,
        DatesFormat,
        DescriptionAttributeTrait,
        HasFactory,
        SlugableTrait,
         SortingTrait,
        TitleAttributeTrait,
        UploadTrait;   

    protected $guarded = [];

 
    protected $table = "order_shipping_details";

    public $timestamps = true;

     /**
     * Get the order associated with the shipping details.
     */
    public function order()
    {
        return $this->belongsTo(Orders::class);
    }

    /**
     * Get the shipping associated with the shipping details.
     */
    public function shipping()
    {
        return $this->belongsTo(Shipping::class);
    }
    
}
