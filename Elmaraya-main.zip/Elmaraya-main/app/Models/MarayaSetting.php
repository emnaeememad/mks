<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MarayaSetting extends Model
{
    use HasFactory;

    protected $fillable = [
        'key',
        'value',
        'input_type',
        'input_label',
    ];

    public static function getInputType(string $key): string
    {
        return match ($key) {
            'facebook_url' => 'input',
            'linkedin_url' => 'input',
            'instagram_url' => 'input',
            'twitter_url' => 'input',
            'youtube_url' => 'input',
            'tiktok_url' => 'input',
            'address_ar' => 'input',
            'address_en' => 'input',
            'phone_1' => 'input',
            'phone_2' => 'input',
            'phone_3' => 'input',
            'phone_4' => 'input',
            'phone_5' => 'input',
            'email' => 'input',
            'android_url' => 'input',
            'ios_url' => 'input',
            'footer_about_ar' => 'textarea',
            'footer_about_en' => 'textarea',
            default => 'input',
        };
    }

    public static function getInputLabel(string $key): string
    {
        return match ($key) {
            'facebook_url' => 'رابط الفيسبوك',
            'linkedin_url' => 'رابط لينكدإن',
            'instagram_url' => 'رابط انستجرام',
            'twitter_url' => 'رابط تويتر',
            'youtube_url' => 'رابط يوتيوب',
            'tiktok_url' => 'رابط تيك توك',
            'address_ar' => 'العنوان بالعربي',
            'address_en' => 'العنوان بالانجليزية',
            'phone_1' => 'رقم الهاتف',
            'phone_2' => 'رقم الهاتف',
            'phone_3' => 'رقم الهاتف',
            'phone_4' => 'رقم الهاتف',
            'phone_5' => 'رقم الهاتف',
            'email' => 'البريد الإلكتروني',
            'android_url' => 'رابط تطبيق Android',
            'ios_url' => 'رابط تطبيق iOS',
            'footer_about_ar' => 'وصف الفوتر العربي',
            'footer_about_en' => 'وصف الفوتر الانجليزي',
            default => '',
        };
    }
}
