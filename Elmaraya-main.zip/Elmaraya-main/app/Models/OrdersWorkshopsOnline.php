<?php

namespace App\Models;

use App\Models\Book;
use App\Models\Orders;
use App\Traits\SortingTrait;
use App\Traits\PaymentStatusAttribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
 
class OrdersWorkshopsOnline extends Model
{
    use HasFactory, PaymentStatusAttribute,   SortingTrait;

    protected $table = 'ordersworkshoponline';

    protected $guarded = [];

    public function order(): BelongsTo
    {
        return $this->belongsTo(Orders::class, 'order_id');
    }

    public function workshoponline(): BelongsTo
    {
        return $this->belongsTo(WorkshopOnline::class, 'workshop_online_id');
    }
}
