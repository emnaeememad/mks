<?php

namespace App\Models;

use App\Enum\PublishType;
use App\Traits\Published;
use App\Traits\DatesFormat;
use App\Traits\UploadTrait;
use App\Traits\SortingTrait;
use App\Contracts\Searchable;
use App\Traits\SlugableTrait;
use App\Traits\SearchableTrait;
use Illuminate\Http\UploadedFile;
use App\Traits\NameAttributeTrait;
use App\Traits\BriefAttributeTrait;
use App\Contracts\CartItemInterface;
use App\Scopes\NullMovieModuleScope;
use Illuminate\Database\Eloquent\Model;
use App\Traits\DescriptionAttributeTrait;
use Illuminate\Database\Eloquent\Builder;
use App\Traits\ImageCopyrightsAttributeTrait;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Movie extends Model implements Searchable, CartItemInterface
{
    use BriefAttributeTrait,
        DatesFormat,
        DescriptionAttributeTrait,
        HasFactory,
        ImageCopyrightsAttributeTrait,
        NameAttributeTrait,
        Published,
        SearchableTrait,
        SlugableTrait,
        SoftDeletes,
        SortingTrait,
        UploadTrait;

    protected $fillable = [
        'cover',
        'main_image',
        'thumb_image',
        'slug_ar',
        'slug_en',
        'name_ar',
        'name_en',
        'brief_ar',
        'brief_en',
        'description_ar',
        'description_en',
        'total_views',
        'total_shares',
        'status',
        'is_featured',
        'is_home',
        'post_date',
        'publish_type',
        'main_image_copyrights_ar',
        'main_image_copyrights_en',
        'thumb_image_copyrights_ar',
        'thumb_image_copyrights_en',
        'cover_copyrights_ar',
        'cover_copyrights_en',
        'module_type',
    ];

    protected $appends = [
        'main_image_url',
        'thumb_image_url',
        'cover_url',
        'small_name',
        'slug_translated',
    ];
    // Use the NullMovieModuleScope global scope
    protected static function booted()
    {
        static::addGlobalScope(new NullMovieModuleScope());
    } 
    public function categories()
    {
        return $this->belongsToMany(Category::class);
    }
    
    public function images(): HasMany
    {
        return $this->hasMany(MovieImage::class, 'movie_id');
    }

    public function videos(): HasMany
    {
        return $this->hasMany(MovieVideo::class, 'movie_id');
    }

    public function SetCoverAttribute($image)
    {
        if ($this->cover) {
            $this->deleteFromPublic($this->cover);
        }

        return $this->attributes['cover'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'movie-covers') :
            $image;
    }

    public function coverUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->cover)
        );
    }

    public function SetMainImageAttribute($image)
    {
        if ($this->main_image) {
            $this->deleteFromPublic($this->main_image);
        }

        return $this->attributes['main_image'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'movie-main-images') :
            $image;
    }

    public function mainImageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->main_image)
        );
    }

    public function SetThumbImageAttribute($image)
    {
        if ($this->thumb_image) {
            $this->deleteFromPublic($this->thumb_image);
        }

        return $this->attributes['thumb_image'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'movie-thumb-images') :
            $image;
    }

    public function thumbImageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->thumb_image)
        );
    }

    public function getSearchableColumns(): array
    {
        return [
            'name_ar',
            'name_en',
            'brief_ar',
            'brief_en',
            'description_ar',
            'description_en',
        ];
    }

    public function scopeAll(Builder $query): Builder
    {
        return $query->where('publish_type', PublishType::all);
    }

    public function scopeMobile(Builder $query): Builder
    {
        return $query->whereIn('publish_type', [PublishType::mobile, PublishType::all]);
    }

    public function scopeWeb(Builder $query): Builder
    {
        return $query->whereIn('publish_type', [PublishType::mobile, PublishType::all]);
    }

    public function publishTypeText(): Attribute
    {
        return Attribute::make(
            get: fn () => PublishType::getTypesTranslated()[$this->publish_type]
        );
    }
    //cart
    // related to interface (contract ) CartItemInterface
    public function findItem($itemId)
    {
        return self::find($itemId);
    }
    //end cart
}
