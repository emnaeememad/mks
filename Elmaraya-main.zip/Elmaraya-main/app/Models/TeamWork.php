<?php

namespace App\Models;

use App\Traits\SortingTrait;
use App\Traits\UploadTrait;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\UploadedFile;

class TeamWork extends Model
{
    use HasFactory, SoftDeletes, SortingTrait, UploadTrait;

    const storageDisk = 'local';

    protected $fillable = [
        'image',
        'title_ar',
        'title_en',
        'name',
        'is_featured',
    ];

    public function SetImageAttribute($image)
    {
        if ($this->image) {
            $this->deleteFromPublic($this->image);
        }

        return $this->attributes['image'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'team-works') :
            $image;
    }

    public function imageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->image)
        );
    }

    public function scopeFeatured(Builder $quer): Builder
    {
        return $quer->where('is_featured', 1);
    }

    public function scopeNotFeatured(Builder $quer): Builder
    {
        return $quer->where('is_featured', 0);
    }
}
