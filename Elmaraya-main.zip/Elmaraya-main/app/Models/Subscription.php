<?php

namespace App\Models;

use App\Traits\SortingTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Subscription extends Model
{
    use HasFactory, SoftDeletes, SortingTrait;

    protected $fillable = [
        'title_ar',
        'title_en',
        'description_ar',
        'description_en',
        'price',
        'price_after',
        'use_price_after',
    ];
}
