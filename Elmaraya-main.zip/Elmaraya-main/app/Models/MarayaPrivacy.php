<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MarayaPrivacy extends Model
{
    use HasFactory;

    protected $fillable = [
        'privacy_ar',
        'privacy_en',
    ];
}
