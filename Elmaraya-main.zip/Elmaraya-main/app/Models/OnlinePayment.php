<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OnlinePayment extends Model
{
    use HasFactory;

    protected $fillable = [
        'amount_in_cents',
        'gateway_tracking',
        'gateway_status',
        'related_model',
        'related_model_id',
    ];
}
