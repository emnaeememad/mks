<?php

namespace App\Models;

use App\Traits\SortingTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class WorkshopRequest extends Model
{
    use HasFactory, SoftDeletes, SortingTrait;

    protected $fillable = [
        'workshop_id',
        'name',
        'age',
        'phone_number',
        'email',
        'address',
        'why_join_us',
        'customer_id',
    ];

    public function workshop(): BelongsTo
    {
        return $this->belongsTo(Workshop::class, 'workshop_id');
    }

    public function attachments()
    {
        return $this->hasMany(WorkshopRequestAttachment::class, 'workshop_request_id');
    }
}
