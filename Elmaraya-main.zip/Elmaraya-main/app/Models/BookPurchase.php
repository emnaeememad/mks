<?php

namespace App\Models;

use App\Traits\PaymentStatusAttribute;
use App\Traits\SortingTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class BookPurchase extends Model
{
    use HasFactory, PaymentStatusAttribute, SoftDeletes, SortingTrait;

    protected $fillable = [
        'book_id',
        'customer_id',
        'payment_id',
        'gateway_tracking',
        'price',
        'status',
    ];

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class, 'customer_id');
    }

    public function book(): BelongsTo
    {
        return $this->belongsTo(Book::class, 'book_id');
    }

    public function payment(): BelongsTo
    {
        return $this->belongsTo(PaymentMethod::class, 'payment_id');
    }

    public function getStatusAttributeName()
    {
        return 'status';
    }
}
