<?php

namespace App\Models;

use App\Traits\SortingTrait;
use App\Traits\UploadTrait;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Http\UploadedFile;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Admin extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SortingTrait, UploadTrait;

    protected $fillable = [
        'name',
        'email',
        'phone_number',
        'photo',
        'role_id',
        'password',
    ];

    public function role(): BelongsTo
    {
        return $this->belongsTo(Role::class, 'role_id');
    }

    public function SetPasswordAttribute($password)
    {
        if ($password) {
            return $this->attributes['password'] = bcrypt($password);
        }
    }

    public function SetPhotoAttribute($photo)
    {
        if ($this->photo) {
            $this->deleteFromPublic($this->photo);
        }

        return $this->attributes['photo'] = $photo instanceof UploadedFile ?
            $this->moveFileToPublic($photo, 'admins') :
            $photo;
    }

    public function photoUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->photo)
        );
    }

    public function deletePhoto()
    {
        if ($this->photo) {
            $this->deleteFromPublic($this->photo);
        }
    }
}
