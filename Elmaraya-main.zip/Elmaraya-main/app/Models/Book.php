<?php

namespace App\Models;

use App\Traits\Published;
use App\Traits\DatesFormat;
use App\Traits\UploadTrait;
use App\Traits\SortingTrait;
use App\Contracts\Searchable;
use App\Enum\BookRequestType;
use App\Traits\SlugableTrait;
use App\Traits\SearchableTrait;
use Illuminate\Http\UploadedFile;
use App\Traits\NameAttributeTrait;
use App\Contracts\CartItemInterface;
use Illuminate\Database\Eloquent\Model;
use App\Traits\DescriptionAttributeTrait;
use Illuminate\Database\Eloquent\Builder;
use App\Traits\ImageCopyrightsAttributeTrait;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Book extends Model implements Searchable, CartItemInterface
{
    use DatesFormat,
        DescriptionAttributeTrait,
        HasFactory,
        ImageCopyrightsAttributeTrait,
        NameAttributeTrait,
        Published,
        SearchableTrait,
        SlugableTrait,
        SoftDeletes,
        SortingTrait,
        UploadTrait;

    protected $fillable = [
        'main_image',
        'slug_ar',
        'slug_en',
        'name_ar',
        'name_en',
        'hard_copy_price',
        'epob_price',
        'description_ar',
        'description_en',
        'amazon_link',
        'category_id',
        'author_id',
        'number_of_pages',
        'bar_code',
        'apple_store_id',
        'file',
        'total_soft_purchased',
        'total_hard_purchased',
        'total_views',
        'total_shares',
        'status',
        'reviewer',
        'is_home',
        'is_featured',
        'is_recommended',
        'request_type',
        'extra_details_en',
        'extra_details_ar',
        'post_date',
        'main_image_copyrights_ar',
        'main_image_copyrights_en',
        'published_house_id',
    ];

    protected $appends = [
        'main_image_url',
        'small_name',
        'slug_translated',
    ];

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'category_id')->withTrashed();
    }

    public function author(): BelongsTo
    {
        return $this->belongsTo(Author::class, 'author_id')->withTrashed();
    }

    public function bookPurchases(): HasMany
    {
        return $this->hasMany(BookPurchase::class, 'book_id');
    }

    public function bookRequests(): HasMany
    {
        return $this->hasMany(BookRequest::class, 'book_id');
    }

    public function customerBooks(): HasMany
    {
        return $this->hasMany(CustomerBook::class, 'book_id');
    }

    public function SetMainImageAttribute($image)
    {
        if ($this->main_image) {
            $this->deleteFromPublic($this->main_image);
        }

        return $this->attributes['main_image'] = $image instanceof UploadedFile ?
            $this->moveFileToPublic($image, 'books/images') :
            $image;
    }

    public function mainImageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->main_image)
        );
    }

    public function SetFileAttribute($file)
    {
        if ($this->file) {
            $this->deleteFromPublic($this->file);
        }

        return $this->attributes['file'] = $file instanceof UploadedFile ?
            $this->moveFileToPublic($file, 'books/files') :
            $file;
    }

    public function fileUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->filePublicUrl($this->file)
        );
    }

    public function bookRequestType(): Attribute
    {
        return Attribute::make(
            get: fn () => match ($this->request_type ?? '') {
                BookRequestType::buy_only => BookRequestType::getTypesTranslated()[BookRequestType::buy_only] ?? '',
                BookRequestType::subscription_only => BookRequestType::getTypesTranslated()[BookRequestType::subscription_only] ?? '',
                BookRequestType::all => BookRequestType::getTypesTranslated()[BookRequestType::all] ?? '',
                default => '',
            }
        );
    }

    public function getSearchableColumns(): array
    {
        return [
            'name_ar',
            'name_en',
            'description_ar',
            'description_en',
        ];
    }

    public function scopeMostRead(Builder $query): Builder
    {
        return $query->orderBy('total_views', 'desc');
    }

    public function scopeMostSold(Builder $query): Builder
    {
        return $query->orderBy('total_soft_purchased', 'desc');
    }

    public function scopeIsHome(Builder $query): Builder
    {
        return $query->where('is_home', true);
    }

    public function scopeIsFeatured(Builder $query): Builder
    {
        return $query->where('is_featured', true);
    }  
     public function scopeIsDistinctive(Builder $query): Builder
    {
        return $query->where('is_distinctive', 1);
    }

    public function scopeIsRecommended(Builder $query): Builder
    {
        return $query->where('is_recommended', true);
    }

    public function scopeLoadAllRelations(Builder $query): Builder
    {
        return $query->with([
            'author' => fn ($a) => $a->withTrashed(),
            'category' => fn ($c) => $c->withTrashed(),
        ]);
    }

    public function scopeRequestTypeSubscription(Builder $query): Builder
    {
        return $query->where('request_type', BookRequestType::subscription_only);
    }

    public function scopeRequestTypeAll(Builder $query): Builder
    {
        return $query->where('request_type', BookRequestType::all);
    }

    public function scopeRequestTypePurchased(Builder $query): Builder
    {
        return $query->where('request_type', BookRequestType::buy_only);
    }


    // cart
    /**
     * Get all of the carts that own the book.
     */
    public function carts()
    {
        return $this->morphMany(Cart::class, 'items');
    }

    // related to interface (contract ) CartItemInterface
    public function findItem($itemId)
    {
        return self::find($itemId);
    }
    //end cart
}
