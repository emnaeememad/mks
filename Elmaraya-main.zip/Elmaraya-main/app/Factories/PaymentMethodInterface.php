<?php


namespace App\Factories;

use App\Models\Book;
use App\Models\Movie;
use Illuminate\Http\Request;
use App\Contracts\CartItemInterface;

interface PaymentMethodInterface
{
    public function checkingOut();
    public function callback(Request $r, $bookPurchase);
}
