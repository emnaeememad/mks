<?php


namespace App\Factories;

use App\Models\Book;
use App\Models\Movie;
use App\Bll\CODPaymentMethod;
use App\Models\PaymentMethod;
use App\Services\CartService;
use App\Contracts\CartItemInterface;
use App\Services\Api\Orders\OrderService;
use App\PaymentMethods\PaymobPaymentMethod;
use App\PaymentMethods\PaymobCheckoutHandler;

class PaymentMethodFactory
{
    public  static function create(
        $total_price,
        $paymentId,
        $parameters
    ) {
        $paymentMethod = PaymentMethod::find($paymentId);
        $paymentMethodSlug = $paymentMethod->slug;
        switch ($paymentMethodSlug) {
            case 'cash':
                return new CODPaymentMethod($total_price,$paymentId,  $parameters);
                // Add more cases for other payment types  case 'cash':
                    
            case 'paymob-visa':
                 $integration_id = $parameters['integration_id'] ?? null;
                $paymob_type = $parameters['paymob_type'] ?? null;
                $iframe_id_or_wallet_number = $parameters['iframe_id_or_wallet_number'] ?? null;
                $request = $parameters['request'] ?? null;
                
                
                return new PaymobPaymentMethod(
                    $total_price,
                    $paymentId,
                    $integration_id,
                    $paymob_type,
                    $iframe_id_or_wallet_number,
                    $request,
                    new OrderService(new CartService),
                    new PaymobCheckoutHandler()
                );
                // Add more cases for other payment types
            default:
                throw new \Exception("Payment method not supported " . $paymentMethodSlug);
        }
    }
}
