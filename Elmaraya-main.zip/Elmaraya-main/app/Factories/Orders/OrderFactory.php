<?php

namespace App\Factories\Orders;

use App\Models\Book;
use App\Bll\Orders\OrderBook;
use App\Models\WorkshopOnline;
use Illuminate\Support\Facades\Log;
use App\Contracts\CartItemInterface;
use App\Bll\Orders\OrderWorkshopOnline;

class OrderFactory
{
    /**
     * Create an order creation instance based on the item type.
     *
     * @param CartItemInterface $item The item for which the order is created.
     * @param int $quantity The quantity of the item in the order.
     * @param int $orderId The ID of the order to which the item belongs.
     * @return mixed An instance of an order creation class for the specified item type.
     * @throws \InvalidArgumentException If the item type is invalid.
     */

    public static function createOrder(CartItemInterface $cartItemInterface, $quantity, $orderId, $order)
    {
        // Determine the type of item and create the corresponding order creation class

        if ($cartItemInterface instanceof Book) {
            return new OrderBook($cartItemInterface, $quantity, $orderId, $order);
        } elseif ($cartItemInterface instanceof WorkshopOnline) {
            return new OrderWorkshopOnline($cartItemInterface, $quantity, $orderId);
        }
        // Throw an exception if the item type is invalid
        Log::error('Error while create order type ');
        throw new \InvalidArgumentException('Invalid item type');
    }
}
