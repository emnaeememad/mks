<?php


namespace App\Factories;

use App\Models\Book;
use App\Models\Movie;
use App\Models\WorkshopOnline;
use Illuminate\Support\Facades\Log;
use App\Contracts\CartItemInterface;

class CartItemFactory
{
    /**
     * Create a new instance of a cart item based on the specified item type.
     *
     * @param string $itemType The type of item to create (e.g., 'book', 'movie', 'workshoponline').
     * @return CartItemInterface An instance of a cart item implementing the CartItemInterface.
     * @throws \InvalidArgumentException If the specified item type is not recognized.
     */
    public static function make(string $itemType): CartItemInterface
    {
        // if($itemType != 'book'){
        //     dd($itemType);
        // }
        switch ($itemType) {
            case 'book':
                return new Book();/// the Book Model implement CartItemInterface
            case 'movie':
                return new Movie();  // the Movie Model implement CartItemInterface
                // Add more cases for other item types as needed
            case 'workshoponline':
                return new WorkshopOnline();  // the WorkshopOnline Model implement CartItemInterface
                // Add more cases for other item types as needed
            default:
                Log::error('Find item in the cart using type error invalid type! the value
                of passed type is : ' . $itemType);
                throw new \InvalidArgumentException('Invalid item type');
        }
    }
}
