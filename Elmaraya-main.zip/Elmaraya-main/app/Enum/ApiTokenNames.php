<?php

namespace App\Enum;

class ApiTokenNames
{
    const customerLogin = 'api-login';
}
