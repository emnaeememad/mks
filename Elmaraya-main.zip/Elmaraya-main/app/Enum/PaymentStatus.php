<?php

namespace App\Enum;

class PaymentStatus
{
    const pending = 'pending';

    const purchased = 'purchased';

    const failed = 'failed';

    const prepared = 'prepared';

    const delivered = 'delivered';
    
    public static function getStatuses(): array
    {
        return [
            self::pending,
            self::purchased,
            self::failed,
            self::delivered,
            self::prepared,
        ];
    }
}
