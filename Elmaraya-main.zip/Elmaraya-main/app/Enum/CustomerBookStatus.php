<?php

namespace App\Enum;

class CustomerBookStatus
{
    const full_time = 'full_time';

    const subscription = 'subscription';

    public static function getStatuses(): array
    {
        return [
            self::full_time,
            self::subscription,
        ];
    }
}
