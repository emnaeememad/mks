<?php

namespace App\Enum;

class BookRequestType
{
    const buy_only = 'buy_only';

    const subscription_only = 'subscription_only';

    const all = 'all';

    public static function getTypes(): array
    {
        return [
            self::buy_only,
            self::subscription_only,
            self::all,
        ];
    }

    public static function getTypesTranslated(): array
    {
        return [
            self::buy_only => 'شراء فقط',
            self::subscription_only => 'اشتراك فقط',
            self::all => 'الكل',
        ];
    }
}
