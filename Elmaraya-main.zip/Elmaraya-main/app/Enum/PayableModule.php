<?php

namespace App\Enum;

class PayableModule
{
    const books = 'books';

    const subscribe = 'subscribe';

    const all = 'all';

    public static function getModules(): array
    {
        return [
            self::books,
            self::subscribe,
            self::all,
        ];
    }
}
