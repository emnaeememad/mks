<?php

namespace App\Enum;

class PublishStatus
{
    const draft = 'draft';

    const published = 'published';

    const archived = 'archived';

    public static function getStatuses(): array
    {
        return [
            self::draft,
            self::published,
            self::archived,
        ];
    }

    public static function getStatusesTranslated(): array
    {
        return [
            self::published => 'تم النشر',
            self::draft => 'قيد المراجعة',
            self::archived => 'تم الأرشفة',
        ];
    }
}
