<?php

namespace App\Enum;

class PermissionActions
{
    const add = 'add';

    const edit = 'edit';

    const delete = 'delete';

    const view = 'view';

    public static function getActions(): array
    {
        return [
            self::add,
            self::edit,
            self::delete,
            self::view,
        ];
    }
}
