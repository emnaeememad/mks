<?php

namespace App\Enum;

class AuthorTypes
{
    const individual = 'individual';

    const company = 'company';

    public static function getTypes(): array
    {
        return [
            self::individual,
            self::company,
        ];
    }
}
