<?php

namespace App\Enum;

class BlogModules
{
    const blogs = 'blogs';

    const maraya_blogs = 'maraya_blogs';

    const seminars = 'seminars';

    const movie_news = 'movie_news';

    const festivals = 'festivals';

    const signing_parties = 'signing_parties';

    const exhibitions = 'exhibitions';

    public static function getModules(): array
    {
        return [
            self::blogs,
            self::maraya_blogs,
            self::seminars,
            self::movie_news,
            self::festivals,
            self::signing_parties,
            self::exhibitions,
        ];
    }
}
