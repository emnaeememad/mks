<?php

namespace App\Enum;

class BookRequestStatus
{
    const pending = 'pending';

    const prepared = 'prepared';

    const purchased = 'purchased';

    const delivered = 'delivered';

    const failed = 'failed';

    public static function getTypes(): array
    {
        return [
            self::pending,
            self::prepared,
            self::purchased,
            self::delivered,
            self::failed,
        ];
    }

    public static function getTypesTranslated(): array
    {
        return [
            self::pending => 'قيد الانتظار',
            self::prepared => 'تم التحضير',
            self::purchased => 'تم الدفع',
            self::delivered => 'تم التوصيل',
            self::failed => 'فشل العمليه',
        ];
    }

    public static function getTypesAndTranslated(): array
    {
        return [
            self::pending => [
                'name_en' => 'pending',
                'name_ar' => 'قيد الانتظار',
            ],
            self::prepared => [
                'name_en' => 'prepared',
                'name_ar' => 'تم التحضير',
            ],
            self::purchased => [
                'name_en' => 'purchased',
                'name_ar' => 'تم الدفع',
            ],
            self::delivered => [
                'name_en' => 'delivered',
                'name_ar' => 'تم التوصيل',
            ],
            self::failed => [
                'name_en' => 'failed',
                'name_ar' => 'فشل العمليه',
            ],
        ];
    }
}
