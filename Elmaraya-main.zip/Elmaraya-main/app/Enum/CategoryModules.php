<?php

namespace App\Enum;

class CategoryModules
{
    const blogs = 'blogs';

    const books = 'books';

    const maraya_books = 'maraya_books';

    const maraya_blogs = 'maraya_blogs';

    const stories = 'stories';

    const nadara = 'nadara';

    const movies = 'movies';

    const longmovies = 'longmovies';

    public static function getModules(): array
    {
        return [
            self::blogs,
            self::books,
            self::maraya_books,
            self::maraya_blogs,
            self::stories,
            self::nadara,
            self::movies,
            self::longmovies,
        ];
    }

    public static function getModulesTranslated(): array
    {
        return [
            self::blogs => 'المدونات',
            self::books => 'الكتب',
            self::maraya_books => 'كتب المرايا',
            self::maraya_blogs => 'مدونات المرايا',
            self::stories => 'الحكايات',
            self::nadara => 'نضارة',
            self::movies => 'افلام',
            self::longmovies => 'افلام طويله',
        ];
    }

    public static function getModule(string $module): string
    {
        return match ($module) {
            self::blogs => 'المدونات',
            self::books => 'الكتب',
            self::maraya_books => 'كتب المرايا',
            self::maraya_blogs => 'مدونات المرايا',
            self::stories => 'الحكايات',
            self::nadara => 'نضارة',
            self::movies => 'افلام',
            self::longmovies => 'افلام طويله',
            default => ''
        };
    }
}
