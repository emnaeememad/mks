<?php

namespace App\Enum;

class PublishType
{
    const all = 'all';

    const mobile = 'mobile';

    const web = 'web';

    public static function getTypes(): array
    {
        return [
            self::all,
            self::mobile,
            self::web,
        ];
    }

    public static function getTypesTranslated(): array
    {
        return [
            self::all => 'الكل',
            self::mobile => 'الموبايل',
            self::web => 'الويب',
        ];
    }
}
