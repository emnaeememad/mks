<?php

namespace App\Enum;

class PaymentSlugs
{
    const cash = 'cash';

    const paymobVisa = 'paymob-visa';
}
