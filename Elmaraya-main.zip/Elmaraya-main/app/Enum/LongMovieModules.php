<?php


namespace App\Enum;
class LongMovieModules
{
 
    const longmovies = 'longmovies';  

    public static function getModules(): array
    {
        return [
             self::longmovies, 
        ];
    }
}
