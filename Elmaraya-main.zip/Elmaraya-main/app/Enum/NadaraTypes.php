<?php

namespace App\Enum;

class NadaraTypes
{
    const photos = 'photos';

    const reels = 'reels';

    public static function getTypes(): array
    {
        return [
            self::photos,
            self::reels,
        ];
    }

    public static function getTypesTranslated(): array
    {
        return [
            self::photos => 'صور',
            self::reels => 'فيديو',
        ];
    }

    public static function getTypesAndTranslated(): array
    {
        return [
            self::photos => [
                'name_ar' => 'صور',
                'name_en' => 'Photos',
            ],
            self::reels => [
                'name_ar' => 'فيديو',
                'name_en' => 'Reels',
            ],
        ];
    }
}
