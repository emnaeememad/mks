<?php

namespace App\Enum;

class Genders
{
    const male = [
        'name_en' => 'male',
        'name_ar' => 'ذكر',
    ];

    const female = [
        'name_en' => 'female',
        'name_ar' => 'انثي',
    ];

    public static function getGenders(): array
    {
        return [
            self::male,
            self::female,
        ];
    }
}
