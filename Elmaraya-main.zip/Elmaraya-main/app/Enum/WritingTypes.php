<?php

namespace App\Enum;

class WritingTypes
{
    const writer = 'writer';

    const trainer = 'trainer';

    public static function getTypes(): array
    {
        return [
            self::writer,
            self::trainer,
        ];
    }

    public static function getTypesTranslated(): array
    {
        return [
            self::writer => 'كاتب',
            self::trainer => 'مدرب',
        ];
    }

    public static function getTypesAndTranslated(): array
    {
        return [
            self::writer => [
                'name_en' => 'writer',
                'name_ar' => 'كاتب',
            ],
            self::trainer => [
                'name_en' => 'trainer',
                'name_ar' => 'مدرب',
            ],
        ];
    }
}
