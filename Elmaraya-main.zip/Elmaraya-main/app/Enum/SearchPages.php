<?php

namespace App\Enum;

class SearchPages
{
    const books = 'books';

    const blogs = 'blogs';

    const stories = 'stories';

    const movies = 'movies';

    const workshops = 'workshops';

    const nadara = 'nadara';

    const authors = 'authors';

    const all = 'all';

    public static function getPages(): array
    {
        return [
            self::books,
            self::blogs,
            self::stories,
            self::movies,
            self::workshops,
            self::nadara,
            self::authors,
            self::all,
        ];
    }

    public static function getPagesTranslated(): array
    {
        return [
            self::all => __('landing/home.all'),
            self::books => __('landing/home.books'),
            self::movies => __('landing/home.movies'),
            self::workshops => __('landing/home.workshop'),
            self::blogs => __('landing/home.blogs'),
            self::stories => __('landing/home.stories'),
            self::nadara => __('landing/home.nadara'),
            self::authors => __('landing/home.authors'),
        ];
    }
}
