<?php

namespace App\Enum;

class OrderType
{
    const book = 'book';

    const workshoponline = 'workshoponline';

 
    public static function getTypes(): array
    {
        return [
            self::book,
            self::workshoponline,
         ];
    }
}
