<?php

namespace App\Enum;

class MovieModules
{
    const movies = 'movies';

 
    public static function getModules(): array
    {
        return [
            self::movies,
        ];
    }
}
