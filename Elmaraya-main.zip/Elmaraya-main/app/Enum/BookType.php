<?php

namespace App\Enum;

class BookType
{
    const digital = 'digital';

    const physical = 'physical';

 
    public static function getTypes(): array
    {
        return [
            self::digital,
            self::physical,
         ];
    }
}
