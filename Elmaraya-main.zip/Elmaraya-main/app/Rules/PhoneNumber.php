<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;

class PhoneNumber implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        $len = strlen($value);
        if ($len >= 8 && $len <= 11 && preg_match('/^[0-9]+$/', $value)) {
            return;
        }
        $fail(__('validation.phone-number'));
    }
}
