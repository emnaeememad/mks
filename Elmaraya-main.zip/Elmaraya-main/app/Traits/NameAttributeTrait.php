<?php

namespace App\Traits;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Support\Str;

trait NameAttributeTrait
{
    public function smallName(): Attribute
    {
        return Attribute::make(
            get: fn () => Str::limit(app()->getLocale() == 'ar' ? $this->name_ar : $this->name_en, 70)
        );
    }

    public function nameTranslated(): Attribute
    {
        return Attribute::make(
            get: fn () => app()->getLocale() == 'ar' ? $this->name_ar : $this->name_en
        );
    }
}
