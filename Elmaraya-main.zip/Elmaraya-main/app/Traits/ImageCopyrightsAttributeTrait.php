<?php

namespace App\Traits;

use Illuminate\Database\Eloquent\Casts\Attribute;

trait ImageCopyrightsAttributeTrait
{
    public function mainImageCopyrights(): Attribute
    {
        return Attribute::make(
            get: fn () => app()->getLocale() == 'ar' ? $this->main_image_copyrights_ar : $this->main_image_copyrights_en
        );
    }

    public function thumbImageCopyrights(): Attribute
    {
        return Attribute::make(
            get: fn () => app()->getLocale() == 'ar' ? $this->thumb_image_copyrights_ar : $this->thumb_image_copyrights_en
        );
    }

    public function coverCopyrights(): Attribute
    {
        return Attribute::make(
            get: fn () => app()->getLocale() == 'ar' ? $this->cover_copyrights_ar : $this->cover_copyrights_en
        );
    }
}
