<?php

namespace App\Traits;

use Illuminate\Support\Str;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;

trait UploadTrait
{
    public function moveFileToPublic(UploadedFile $file, string $path): string
    {
        $fileName = explode($file->getClientOriginalExtension(), $file->getClientOriginalName())[0];
        $fileName = Str::slug($fileName).'-'.rand(10000, 99999).'.'.$file->getClientOriginalExtension();
        Storage::disk('public')->put($path.'/'.$fileName, $file->get());

        return "$path/$fileName";
    }

    public function filePublicUrl(?string $fullPath): string
    {
        return $fullPath ? Storage::disk('public')->url($fullPath) : url('noimage.jpg');
    }

    public function deleteFromPublic(?string $fullPath)
    {
        if (Storage::disk('public')->exists($fullPath)) {
            Storage::disk('public')->delete($fullPath);
        }
    }
}
