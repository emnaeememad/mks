<?php

namespace App\Traits;

use App\Enum\BlogModules;
use App\Enum\PublishStatus;
use App\Http\Requests\Admin\Blog\StoreBlogRequest;
use App\Http\Requests\Admin\Blog\UpdateBlogRequest;
use App\Models\Author;
use App\Models\Blog;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use RealRashid\SweetAlert\Facades\Alert;

trait BlogModulesControllerTrait
{
    public function index(): View
    {
        return view('dashboard.blog_modules.index', [
            'collection' => Blog::moduleType($this->getModuleType())->descOrder()->paginate(40),
            'pageTitle' => $this->getPageTitle(),
            'moduleName' => $this->getModuleName(),
            'routeParent' => $this->getRouteParent(),
            'routeModelName' => 'blog',
        ]);
    }

    public function create(): View
    {
        return view('dashboard.blog_modules.create', [
            'publishStatuses' => PublishStatus::getStatusesTranslated(),
            'categories' => $this->getCategories(),
            'showCategories' => $this->getShowCategories(),
            'authors' => Author::individuals()->get(['id', 'name_ar']),
            'moduleName' => $this->getModuleName(),
            'routeParent' => $this->getRouteParent(),
            'checks' => $this->getChecksData(),
            'showTranslator' => isset($this->showTranslator) && $this->showTranslator,
        ]);
    }

    public function store(StoreBlogRequest $request): RedirectResponse
    {
        if ($this->getModuleType() == BlogModules::blogs) {
            $this->validate($request, [
                'linked_data' => 'nullable|array|filled|min:1|max:4',
                'linked_data.*' => 'nullable|integer|exists:blogs,id',
            ], [], [
                'linked_data' => 'مدونات إقرأوا أيضاً',
            ]);
        }
        $slugs = [
            'slug_ar' => Blog::slug($request->get('title_ar')),
            'slug_en' => Blog::slug($request->get('title_en')),
        ];
        if (
            Blog::isNotSlugable(
                data: $slugs,
                extraConditions: ['module_type' => $this->getModuleType()]
            )
        ) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        $data = [
            'module_type' => $this->getModuleType(),
            ...$request->validated(),
            ...$slugs,
        ];
        if ($this->getModuleType() == BlogModules::blogs) {
            $data['linked_data'] = $request->get('linked_data', []);
        }
        Blog::create($data);
        Alert::success('عملية ناجحة', 'تم إضافة '.$this->getModuleName().' بنجاح');

        return to_route('admin.'.$this->getRouteParent().'.index');
    }

    public function show(Blog $blog): View
    {
        return view('dashboard.blog_modules.show', [
            'model' => $blog->load([
                'category' => fn ($q) => $q->withTrashed(),
                'author' => fn ($q) => $q->withTrashed(),
            ]),
            'moduleName' => $this->getModuleName(),
            'checks' => $this->getChecksData(),
        ]);
    }

    public function edit(Blog $blog): View
    {
        return view('dashboard.blog_modules.edit', [
            'publishStatuses' => PublishStatus::getStatusesTranslated(),
            'categories' => $this->getCategories(),
            'showCategories' => $this->getShowCategories(),
            'authors' => Author::individuals()->get(['id', 'name_ar']),
            'moduleName' => $this->getModuleName(),
            'routeParent' => $this->getRouteParent(),
            'model' => $blog,
            'routeModelName' => 'blog',
            'checks' => $this->getChecksData(),
            'showTranslator' => isset($this->showTranslator) && $this->showTranslator,
        ]);
    }

    public function update(UpdateBlogRequest $request, Blog $blog): RedirectResponse
    {
        if ($this->getModuleType() == BlogModules::blogs) {
            $this->validate($request, [
                'linked_data' => 'nullable|array|filled|min:1|max:4',
                'linked_data.*' => 'nullable|integer|exists:blogs,id',
            ], [], [
                'linked_data' => 'مدونات إقرأوا أيضاً',
            ]);
        }
        $slugs = [
            'slug_ar' => Blog::slug($request->get('title_ar')),
            'slug_en' => Blog::slug($request->get('title_en')),
        ];
        if (Blog::isNotSlugable($slugs, $blog->id, ['module_type' => $this->getModuleType()])) {
            Alert::error('عملية فاشلة', 'يرجي التأكد من ان العنوان مميز و غير موجود (العنوان عربي و إنجليزي) من قبل لتحسين البحث في الموقع');

            return back()->withInput();
        }
        $data = [
            ...$request->validated(),
            ...$slugs,
        ];
        if ($this->getModuleType() == BlogModules::blogs) {
            $data['linked_data'] = $request->get('linked_data', []);
        }
        $blog->update($data);
        Alert::success('عملية ناجحة', 'تم تعديل بيانات '.$this->getModuleName().' بنجاح');

        return back();
    }

    public function destroy(Blog $blog): RedirectResponse
    {
        $blog->delete();
        Alert::success('عملية ناجحة', 'تم حذف '.$this->getModuleName().' بنجاح');

        return back();
    }
}
