<?php

namespace App\Traits;

use App\Enum\PublishStatus;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\Attribute;

trait Published
{
    public function scopePublished(Builder $query): Builder
    {
        return $query->where('status', PublishStatus::published);
    }

    public function publishStatus(): Attribute
    {
        return Attribute::make(
            get: fn () => match ($this->status) {
                PublishStatus::draft => PublishStatus::getStatusesTranslated()[PublishStatus::draft] ?? '',
                PublishStatus::published => PublishStatus::getStatusesTranslated()[PublishStatus::published] ?? '',
                PublishStatus::archived => PublishStatus::getStatusesTranslated()[PublishStatus::archived] ?? '',
                default => '',
            }
        );
    }
}
