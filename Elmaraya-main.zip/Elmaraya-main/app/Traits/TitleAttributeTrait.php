<?php

namespace App\Traits;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Support\Str;

trait TitleAttributeTrait
{
    public function smallTitle(): Attribute
    {
        return Attribute::make(
            get: fn () => Str::limit(app()->getLocale() == 'ar' ? $this->title_ar : $this->title_en, 70)
        );
    }

    public function titleTranslated(): Attribute
    {
        return Attribute::make(
            get: fn () => app()->getLocale() == 'ar' ? $this->title_ar : $this->title_en
        );
    }
}
