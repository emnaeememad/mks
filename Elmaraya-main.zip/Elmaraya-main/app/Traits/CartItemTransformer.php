<?php


namespace App\Traits;

use App\Models\Book;
use App\Enum\OrderType;
use App\Models\WorkshopOnline;
use Illuminate\Support\Facades\Log;
use App\Models\WorkshoponlinePurchase;
use Illuminate\Database\Eloquent\Model;
use App\Integrations\Payments\Paymob\Order;
use App\Http\Resources\Api\Cart\BookResource;
use App\Http\Resources\Api\Cart\BookResourceCollection;
use App\Http\Resources\Api\Cart\WorkshopOnlineResource;

trait CartItemTransformer
{
    protected function transformItemType($itemType)
    {
        // Define mappings from class namespaces to user-friendly names
        $typeMappings = [
            Book::class => OrderType::book,
            WorkshopOnline::class => OrderType::workshoponline,
            // Add more mappings as needed for other item types
        ];

        return $typeMappings[$itemType] ?? $itemType;
    }

    protected function transformItemDetails($itemType, $itemId, $cart_id)
    {
        switch ($itemType) {
            case Book::class:
                $item = Book::find($itemId);
                return   new BookResourceCollection(collect([new BookResource($item)]), $cart_id);
            case WorkshopOnline::class:
                $item = WorkshopOnline::find($itemId);
                return new WorkshopOnlineResource($item);
                // Add more cases for other item types as needed
            default:
                Log::error('Unknow type CartItemTransformer');
                return null; // Or handle unknown item types accordingly
        }
    }

    protected function getModelKeyword(  $model)
    {
        $modelToKeyWordMap = [
            Book::class => OrderType::book,
            WorkshopOnline::class => OrderType::workshoponline,
        ];
        return $modelToKeyWordMap[$model] ?? 'default';
    }

    protected function getItemTypeKeyword($itemType){
        switch ($itemType) {
            case WorkshopOnline::class:
                return OrderType::workshoponline;
            case Book::class:
                return OrderType::book;
            default:
                return null;
        }
    }
}
