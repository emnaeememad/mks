<?php

namespace App\Traits;

use App\Enum\PaymentStatus;
use Illuminate\Database\Eloquent\Casts\Attribute;

trait PaymentStatusAttribute
{
    public function paymentStatusName(): Attribute
    {
        return Attribute::make(
            get: function () {
                return match ($this->{$this->getStatusAttributeName()}) {
                    PaymentStatus::pending => 'في إنتظار الدفع',
                    PaymentStatus::purchased => 'مدفوعة',
                    PaymentStatus::failed => 'مرفوضة',
                    default => ''
                };
            }
        );
    }

    public function paymentStatusClass(): Attribute
    {
        return Attribute::make(
            get: function () {
                return match ($this->{$this->getStatusAttributeName()}) {
                    PaymentStatus::pending => 'text-info',
                    PaymentStatus::purchased => 'text-success',
                    PaymentStatus::failed => 'text-danger',
                    default => ''
                };
            }
        );
    }
}
