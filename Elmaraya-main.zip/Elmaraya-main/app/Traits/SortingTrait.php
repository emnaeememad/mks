<?php

namespace App\Traits;

use Illuminate\Database\Eloquent\Builder;

trait SortingTrait
{
    public function scopeAscOrder(Builder $query): Builder
    {
        return $query->orderBy('id', 'asc');
    }

    public function scopeDescOrder(Builder $query): Builder
    {
        return $query->orderBy('id', 'desc');
    }

    public function scopeAscCustomOrder(Builder $query, $column): Builder
    {
        return $query->orderBy($column, 'asc');
    }

    public function scopeDescCustomOrder(Builder $query, $column): Builder
    {
        return $query->orderBy($column, 'desc');
    }
}
