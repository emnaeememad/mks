<?php

namespace App\Traits;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Support\Str;

trait BriefAttributeTrait
{
    public function smallBrief(): Attribute
    {
        return Attribute::make(
            get: fn () => Str::limit(app()->getLocale() == 'ar' ? $this->brief_ar : $this->brief_en, 120)
        );
    }
	
	    public function smallDes(): Attribute
    {
        return Attribute::make(
            get: fn () => Str::words(app()->getLocale() == 'ar' ? $this->description_ar : $this->description_en, 45)
        );
    }

    public function briefTranslated(): Attribute
    {
        return Attribute::make(
            get: fn () => app()->getLocale() == 'ar' ? $this->brief_ar : $this->brief_en
        );
    }
}
