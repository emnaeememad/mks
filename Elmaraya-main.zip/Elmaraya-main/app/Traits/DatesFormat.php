<?php

namespace App\Traits;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Casts\Attribute;

trait DatesFormat
{
    public function createdFormat(): Attribute
    {
        return Attribute::make(
            get: fn () => Carbon::parse($this->post_date ?? $this->created_at)->format('Y.m.d')
        );
    }
}
