<?php

namespace App\Traits;

use Error;
use Exception;
use Illuminate\Database\Eloquent\Builder;

trait SearchableTrait
{
    public function scopeSearch(Builder $query, string $search): Builder
    {
        try {
            $columns = $this->getSearchableColumns();
            if (is_array($columns) && ! empty($columns)) {
                for ($i = 0; $i < count($columns); $i++) {
                    if ($i == 0) {
                        $query->where($columns[$i], 'like', "%$search%");
                    } else {
                        $query->orWhere($columns[$i], 'like', "%$search%");
                    }
                }
            }
        } catch (Exception|Error $e) {
            // just to ignore any exception or error for undeclared function for getting columns
        }

        return $query;
    }
}
