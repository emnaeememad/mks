<?php

namespace App\Traits;

use Illuminate\Database\Eloquent\Casts\Attribute;

trait DescriptionAttributeTrait
{
    public function descriptionTranslated(): Attribute
    {
        return Attribute::make(
            get: fn () => app()->getLocale() == 'ar' ? $this->description_ar : $this->description_en
        );
    }
}
