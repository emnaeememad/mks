<?php

namespace App\Traits;

use Illuminate\Database\Eloquent\Casts\Attribute;

trait SlugableTrait
{
    public static function isNotSlugable(
        array $data,
        ?int $ignoredId = null,
        ?array $extraConditions = []
    ): bool {
        return self::where(function ($query) use ($data) {
            $index = 0;
            foreach ($data as $key => $value) {
                if ($index == 0) {
                    $query->where($key, $value);
                } else {
                    $query->orWhere($key, $value);
                }
                $index++;
            }
        })
            ->when($ignoredId, fn ($q) => $q->where('id', '!=', $ignoredId))
            ->when($extraConditions, function ($query) use ($extraConditions) {
                foreach ($extraConditions as $key => $value) {
                    $query->where($key, $value);
                }
            })
            ->exists();
    }

    /**
     * @hint copied from stack overflow
     */
    public static function slug(string $string, string $separator = '-'): string
    {
        if (is_null($string)) {
            return '';
        }

        $string = trim($string);

        $string = mb_strtolower($string, 'UTF-8');

        $string = preg_replace("/[^a-z0-9_\sءاأإآؤئبتثجحخدذرزسشصضطظعغفقكلمنهويةى]#u/", '', $string);

        $string = preg_replace("/[\s-]+/", ' ', $string);

        $string = preg_replace("/[\s_]/", $separator, $string);

        return $string;
    }

    public function slugTranslated(): Attribute
    {
        return Attribute::make(
            get: fn () => app()->getLocale() == 'ar' ? $this->slug_ar : $this->slug_en
        );
    }
}
