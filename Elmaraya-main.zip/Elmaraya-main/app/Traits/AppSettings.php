<?php

namespace App\Traits;

use App\Models\MarayaSetting;

trait AppSettings
{
    private function app_settings(): array
    {
        $app_settings = MarayaSetting::get(['key', 'value']);

        return [
            'linkedin_url' => $app_settings->where('key', 'linkedin_url')->first()->value,
            'facebook_url' => $app_settings->where('key', 'facebook_url')->first()->value,
            'twitter_url' => $app_settings->where('key', 'twitter_url')->first()->value,
            'instagram_url' => $app_settings->where('key', 'instagram_url')->first()->value,
            'youtube_url' => $app_settings->where('key', 'youtube_url')->first()->value,
            'tiktok_url' => $app_settings->where('key', 'tiktok_url')->first()->value,
            'ios_url' => $app_settings->where('key', 'ios_url')->first()->value,
            'android_url' => $app_settings->where('key', 'android_url')->first()->value,
            'email' => $app_settings->where('key', 'email')->first()->value,
            'phone_1' => $app_settings->where('key', 'phone_1')->first()->value,
            'phone_2' => $app_settings->where('key', 'phone_2')->first()->value,
            'phone_3' => $app_settings->where('key', 'phone_3')->first()->value,
            'phone_4' => $app_settings->where('key', 'phone_4')->first()->value,
            'phone_5' => $app_settings->where('key', 'phone_5')->first()->value,
            'address_ar' => $app_settings->where('key', 'address_ar')->first()->value,
            'address_en' => $app_settings->where('key', 'address_en')->first()->value,
            'footer_about_ar' => $app_settings->where('key', 'footer_about_ar')->first()->value,
            'footer_about_en' => $app_settings->where('key', 'footer_about_en')->first()->value,
        ];
    }
}
