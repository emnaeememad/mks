<?php

namespace App\Traits;

use Illuminate\Support\Facades\App;

trait OtpGenerator
{
    private function generateCode(): string
    {
        return App::isProduction() ? rand(1000, 9999) : 1234;
    }
}
