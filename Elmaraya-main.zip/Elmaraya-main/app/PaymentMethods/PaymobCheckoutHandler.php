<?php

namespace App\PaymentMethods;

use Illuminate\Support\Facades\Http;



class PaymobCheckoutHandler
{
    public function __construct()
    {
    }

    public function initiateCheckout($total_price)
    {
        $responseFirstCall = Http::withHeaders([
            'content-type' => 'application/json'
        ])->post('https://accept.paymob.com/api/auth/tokens', [
            "api_key" => env('PAYMOB_API_KEY')
        ]);
        $jsonFirstCall = $responseFirstCall->json();

        $order_id = rand(1000, 9999);

        $responseSecondCall = Http::withHeaders([
            'content-type' => 'application/json'
        ])->post('https://accept.paymob.com/api/ecommerce/orders', [
            "auth_token" => $jsonFirstCall['token'],
            "delivery_needed" => "false",
            "amount_cents" => $total_price   * 100,
            "merchant_order_id" => $order_id
        ]);


        $jsonSecondCall = $responseSecondCall->json();

        return [$jsonFirstCall,  $jsonSecondCall];
    }

    public function generateFinalToken($customer, $jsonFirstCall,  $jsonSecondCall, $integration_id)
    {
        [$first_name, $last_name] = $this->getDetailsName($customer->name);

        //  step 3: send customer data
        $responseThirdCall = Http::withHeaders([
            'content-type' => 'application/json'
        ])->post('https://accept.paymob.com/api/acceptance/payment_keys', [
            "auth_token" => $jsonFirstCall['token'],
            "expiration" => 36000,
            "amount_cents" => $jsonSecondCall['amount_cents'],
            "order_id" => $jsonSecondCall['id'],
            "billing_data" => [
                "first_name"            => $first_name,
                "last_name"             => $last_name,
                "phone_number"          => $customer->phone_number ?? "NA", //$user->phone ?: "NA"
                "email"                 => $customer->email ?? "NA",
                "apartment"             => "NA",
                "floor"                 => "NA",
                "street"                => 'NA', ///$user->address
                "building"              => "NA",
                "shipping_method"       => "NA",
                "postal_code"           => '73747',
                "city"                  => 'NA',
                "state"                 => "NA",
                "country"               => 'NA',
            ],
            "currency" => "EGP",
            "integration_id" => $integration_id
        ]);

        $jsonThirdCall = $responseThirdCall->json();
        return $jsonThirdCall;
    }

    public function getDetailsName($customer_name)
    {
        if ((count(explode(" ", $customer_name)) == 1)) {
            $first_name = $customer_name;
            $last_name = $customer_name;
        } else {
            $first_name = explode(" ", $customer_name)[0];
            $last_name = explode(" ", $customer_name)[1];
        }
        return [$first_name, $last_name];
    }

    public function generateWalletUrl($jsonThirdCall, $iframe_id_or_wallet_number)
    {
        $response_iframe = Http::withHeaders([
            'content-type' => 'application/json'
        ])->post('https://accept.paymob.com/api/acceptance/payments/pay', [
            "source" => [
                "identifier" => $iframe_id_or_wallet_number,
                "subtype" => "WALLET"
            ],
            "payment_token" => $jsonThirdCall['token'],
        ]);
        return  $response_iframe->json();
    }

    public function generatePaymentCardUrl($iframe_id_or_wallet_number, $jsonThirdCall)
    {
        $url = 'https://accept.paymobsolutions.com/api/acceptance/iframes/' . $iframe_id_or_wallet_number . '?payment_token=' . $jsonThirdCall['token'];
        return $url;
    }
}
