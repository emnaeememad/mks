<?php


namespace App\PaymentMethods;

use PDO;
use App\Models\Book;
use App\Models\Order;
use App\Models\Orders;
use App\Enum\OrderType;
use App\Models\OrdersBooks;
use App\Models\BookPurchase;
use Illuminate\Http\Request;
use App\Models\CombinedOrder;
use App\Models\OnlinePayment;
use App\Services\CartService;
use Illuminate\Http\JsonResponse;
use App\Factories\CartItemFactory;
use Illuminate\Support\Facades\DB;
use App\Traits\CartItemTransformer;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Utility\NotificationUtility;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\RedirectResponse;
use App\Factories\Orders\OrderFactory;
use Illuminate\Database\Eloquent\Model;
use App\Factories\PaymentMethodInterface;
use App\Services\Api\Orders\OrderService;
use App\Http\Controllers\ApiBaseController;
use App\Http\Controllers\CheckoutController;
use App\PaymentMethods\PaymobCheckoutHandler;

class PaymobPaymentMethod extends ApiBaseController  implements PaymentMethodInterface
{

    use CartItemTransformer;
    /**
     * Display checkout page.
     *
     * @param $payment_method
     * @param $integration_id
     * @param $order_id
     * @param $iframe_id_or_wallet_number
     * @return  
     */
    protected $total_price;
    protected $paymentId;
    protected $integration_id;
    protected $iframe_id_or_wallet_number;
    protected $paymob_type;
    protected $orderService;
    protected $paymobCheckoutHandler;
    protected   $request;
    public function __construct(
        $total_price,
        $paymentId,
        $integration_id,
        $paymob_type,
        $iframe_id_or_wallet_number,
        $request,
        OrderService $orderService,
        PaymobCheckoutHandler $paymobCheckoutHandler
    ) {
        $this->total_price = $total_price;
        $this->paymentId = $paymentId;
        $this->integration_id = $integration_id;
        $this->paymob_type = $paymob_type;
        $this->iframe_id_or_wallet_number = $iframe_id_or_wallet_number;
        $this->iframe_id_or_wallet_number = $iframe_id_or_wallet_number;
        $this->request = $request;
        $this->orderService = $orderService;
        $this->paymobCheckoutHandler = $paymobCheckoutHandler;
    }
    public function checkingOut()
    {
        try {
            $customer = auth('sanctum')->user();
            DB::beginTransaction(); // Begin a database transaction


            [$jsonFirstCall,  $jsonSecondCall] = $this->paymobCheckoutHandler->initiateCheckout($this->total_price);
            $this->orderService->createOrderAndOrderItems($customer->id, $jsonSecondCall['id'], $this->paymentId,   $this->request );

            $jsonThirdCall  = $this->paymobCheckoutHandler->generateFinalToken(
                $customer,
                $jsonFirstCall,
                $jsonSecondCall,
                $this->integration_id
            );
            

       
            $paymentUrl = $this->generatePaymentUrl($jsonThirdCall);
            DB::commit(); // Commit the transaction if all operations are successful
            return  $paymentUrl;
        } catch (\Exception $ex) {
            DB::rollback(); // Rollback the transaction in case of an exception
            Log::error($ex);
            return false;
        }
    }

    public function callback(Request $request, $bookPurchase)
    {
        $payment_details = json_encode($request->all());
        $onlinePayment = OnlinePayment::where('gateway_tracking', $request->order)->first();
        // for testing i will suggest it is false to make operations
        if ($request->success !== "true") {
            $bookPurchase->update([
                'status' => 'purchased'
            ]);
            $onlinePayment->update([
                'status' => 'purchased'
            ]);
            return $this->successResponse([], __('api.book-purchase-success'));
            // return (new CheckoutController)->checkout_done($request->merchant_order_id, $payment_details);
        } else {

            $bookPurchase->update([
                'status' => 'failed'
            ]);
            $onlinePayment->update([
                'status' => 'failed'
            ]);
            return $this->successResponse([], __('api.book-purchase-failed'));
        }
    }


    public function generatePaymentUrl($jsonThirdCall)
    {
        switch ($this->paymob_type) {
            case 'wallet':
                return  $this->generateWalletPaymentUrl($jsonThirdCall);
            case 'card_payment':
            case 'kiosk_payment':
                return $this->generateCardOrKioskPaymentUrl($jsonThirdCall);

            default:
                // Handle unknown paymob_type
                Log::error('payment-type-unsupported line 143 PaymobPaymentMethod');
                return $this->failResponse(__('api.payment-type-unsupported'));
        }
    }
    public function generateWalletPaymentUrl($jsonThirdCall)
    {
        $response_iframe_data = $this->paymobCheckoutHandler->generateWalletUrl($jsonThirdCall,  $this->iframe_id_or_wallet_number);

        if (isset($response_iframe_data['redirect_url'])) {
            return $response_iframe_data['redirect_url'];
        } else {
            Log::error('payment-failed line 154 generateWalletPaymentUrl function');

            return $this->failResponse(__('api.payment-failed'));
        }
    }
    public function generateCardOrKioskPaymentUrl($jsonThirdCall)
    {
        $url = $this->paymobCheckoutHandler->generatePaymentCardUrl($this->iframe_id_or_wallet_number, $jsonThirdCall);
        if (isset($url)) {
            return  $url;
        } else {
            Log::error('payment-failed line 164 generateCardOrKioskPaymentUrl function');

            return $this->failResponse(__('api.payment-failed'));
        }
    }
}
