<?php


namespace App\Bll;

use App\Models\Book;
use App\Models\Order;
use App\Models\BookPurchase;
use Illuminate\Http\Request;
use App\Models\CombinedOrder;
use App\Models\OnlinePayment;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Utility\NotificationUtility;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\RedirectResponse;
use App\Factories\PaymentMethodInterface;
use App\Http\Controllers\ApiBaseController;
use App\Http\Controllers\CheckoutController;

class CODPaymentMethod extends ApiBaseController implements PaymentMethodInterface  
{

    /**
     * Display checkout page.
     *
     * @param $payment_method
     * @param $integration_id
     * @param $order_id
     * @param $iframe_id_or_wallet_number
     * @return  
     */
     protected $paymentId;
    protected $total_price;
  
    public function __construct(  $paymentId,  $total_price )
    {
         $this->paymentId = $paymentId;
        $this->total_price = $total_price;
      }
    public function checkingOut()
    {
        
    }

    public function callback(Request $request, $bookPurchase)
    {
         /// will not implment callback for COD
    }
}
