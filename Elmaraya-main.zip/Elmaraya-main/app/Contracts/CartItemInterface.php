<?php


namespace App\Contracts;

/**
* Interface CartItemInterface
*
* This interface defines the contract for cart items in the system.
* Cart items are objects that can be added to a user's cart.
*/
interface CartItemInterface
{
   /**
    * Find the item with the specified ID.
    *
    * @param mixed $itemId The ID of the item to find.
    * @return mixed The found item.
    */
   public function findItem($itemId);
}