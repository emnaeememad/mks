<?php

namespace App\Contracts;

interface PayByWebPage
{
    public function gatewayTrackingNumber(): string;

    public function getRedirectUrl(): string;

    public function getSuccessUrl(): string;

    public function getFailureUrl(): string;
}
