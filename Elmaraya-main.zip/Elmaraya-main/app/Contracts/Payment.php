<?php

namespace App\Contracts;

interface Payment
{
    public function payByWebPage(): PayByWebPage;
}
