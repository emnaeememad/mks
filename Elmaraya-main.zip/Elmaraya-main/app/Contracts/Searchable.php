<?php

namespace App\Contracts;

interface Searchable
{
    public function getSearchableColumns(): array;
}
