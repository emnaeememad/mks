<?php

namespace App\Bll\Orders;

use App\Models\WorkshopOnline;
use App\Models\OrdersWorkshopsOnline;

class OrderWorkshopOnline
{
    protected $item;
    protected $quantity;
    protected $orderId;

    public function __construct(WorkshopOnline $item, int $quantity, int $orderId)
    {
        $this->item = $item;
        $this->quantity = $quantity;
        $this->orderId = $orderId;
    }

    public function save()
    {
        OrdersWorkshopsOnline::create([
            'price' => $this->item->price,
            'quantity' => $this->quantity,
            'workshop_online_id' => $this->item->id,
            'order_id' => $this->orderId,
        ]);
    }
}
