<?php

namespace App\Bll\Orders;

use App\Models\Book;
use App\Enum\BookType;
use App\Models\OrdersBooks;


class OrderBook
{

    private $item;
    private $quantity;
    private $orderId;
    private $order;

    public function __construct(
        Book $item,
        $quantity,
        $orderId,
        $order
    ) {
        $this->item = $item;
        $this->quantity = $quantity;
        $this->orderId = $orderId;
        $this->order = $order;
    }

    public function save()
    {
        if($this->order->book_type == BookType::physical){
            $price = $this->item->hard_copy_price;
            $this->item->update(['total_hard_purchased' => $this->item->total_hard_purchased + 1]);
           
        }else {
            $price = $this->item->epob_price;
        }
        OrdersBooks::create([
            'price' => $price,
            'quantity' => $this->quantity,
            'book_id' => $this->item->id,
            'order_id' => $this->orderId,
        ]);
        
    }
}
