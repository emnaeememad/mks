<?php


namespace App\Bll;

use App\Models\Book;
use App\Models\Order;
use App\Models\BookPurchase;
use Illuminate\Http\Request;
use App\Models\CombinedOrder;
use App\Models\OnlinePayment;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Utility\NotificationUtility;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\RedirectResponse;
use App\Factories\PaymentMethodInterface;
use App\Http\Controllers\ApiBaseController;
use App\Http\Controllers\CheckoutController;

class CODPaymentMethod extends ApiBaseController implements PaymentMethodInterface  
{

    /**
     * Display checkout page.
     *
     * @param $payment_method
     * @param $integration_id
     * @param $order_id
     * @param $iframe_id_or_wallet_number
     * @return  
     */
     protected $paymentId;
    protected $integration_id;
    protected $iframe_id_or_wallet_number;
    protected $paymob_type;

    public function __construct(  $paymentId, $integration_id,  $paymob_type, $iframe_id_or_wallet_number)
    {
         $this->paymentId = $paymentId;
        $this->integration_id = $integration_id;
        $this->paymob_type = $paymob_type;
        $this->iframe_id_or_wallet_number = $iframe_id_or_wallet_number;
    }
    public function checkingOut()
    {
        try {

            $book = Book::where('id', $this->bookId)->first();
            $customer = auth()->user();
            // dd('start script');
            DB::beginTransaction(); // Begin a database transaction
            // step 1: login to paymob get first token
            $response = Http::withHeaders([
                'content-type' => 'application/json'
            ])->post('https://accept.paymob.com/api/auth/tokens', [
                "api_key" => env('PAYMOB_API_KEY')
            ]);
            $json = $response->json();
 
             $order_id = rand(1000, 9999);
            // step 2: send order data
            $response_final = Http::withHeaders([
                'content-type' => 'application/json'
            ])->post('https://accept.paymob.com/api/ecommerce/orders', [
                "auth_token" => $json['token'],
                "delivery_needed" => "false",
                "amount_cents" => $book->epob_price   * 100,
                "merchant_order_id" => $order_id
            ]);


            $json_final = $response_final->json();

            $bookPurchase = BookPurchase::create([
                'book_id' => $book->id,
                'customer_id' => $customer->id,
                'payment_id' => $this->paymentId,
                'price' => $book->epob_price,
                'gateway_tracking' => $json_final['id'],
            ]);

            OnlinePayment::create([
                'amount_in_cents' => $book->epob_price * 100,
                'gateway_tracking' => $json_final['id'],
                'related_model' => BookPurchase::class,
                'related_model_id' => $bookPurchase->id,
            ]);

            $customer_name =  $customer->name;
            if ((count(explode(" ", $customer_name)) == 1)) {
                $first_name = $customer_name;
                $last_name = $customer_name;
            } else {
                $first_name = explode(" ", $customer_name)[0];
                $last_name = explode(" ", $customer_name)[1];
            }
 
            //  step 3: send customer data
            $response_final_final = Http::withHeaders([
                'content-type' => 'application/json'
            ])->post('https://accept.paymob.com/api/acceptance/payment_keys', [
                "auth_token" => $json['token'],
                "expiration" => 36000,
                "amount_cents" => $json_final['amount_cents'],
                "order_id" => $json_final['id'],
                "billing_data" => [
                    "first_name"            => $first_name,
                    "last_name"             => $last_name,
                    "phone_number"          => $customer->phone_number ?? "NA", //$user->phone ?: "NA"
                    "email"                 => $customer->email ?? "NA",
                    "apartment"             => "NA",
                    "floor"                 => "NA",
                    "street"                => 'NA', ///$user->address
                    "building"              => "NA",
                    "shipping_method"       => "NA",
                    "postal_code"           => '73747',
                    "city"                  => 'NA',
                    "state"                 => "NA",
                    "country"               => 'NA',
                ],
                "currency" => "EGP",
                "integration_id" => $this->integration_id
            ]);
 
            $response_final_final_json = $response_final_final->json(); 

             if ($this->paymob_type == 'wallet') {
                 try {
                    $response_iframe = Http::withHeaders([
                        'content-type' => 'application/json'
                    ])->post('https://accept.paymob.com/api/acceptance/payments/pay', [
                        "source" => [
                            "identifier" => $this->iframe_id_or_wallet_number,
                            "subtype" => "WALLET"
                        ],
                        "payment_token" => $response_final_final_json['token'],
                    ]);
                    DB::commit(); // Commit the transaction if all operations are successful
                    $response_iframe_data = $response_iframe->json();

                    if (isset($response_iframe_data['redirect_url'])) {
                        return $response_iframe_data['redirect_url'];
                    } else {
                        return $this->failResponse(__('api.payment-failed'));
                    }
                } catch (\Exception $ex) {
                    // Rollback the transaction in case of an exception
                    DB::rollback();
                    Log::error($ex);
                    return $this->failResponse(__('api.payment-failed'));
                }
            } elseif ($this->paymob_type == 'card_payment' || $this->paymob_type == 'kiosk_payment') {
                $url = 'https://accept.paymobsolutions.com/api/acceptance/iframes/' . $this->iframe_id_or_wallet_number . '?payment_token=' . $response_final_final_json['token'];
                DB::commit(); // Commit the transaction if all operations are successful
                return $url;
            } else {

                // Handle unknown paymob_type
                return $this->failResponse(__('api.payment-type-unsupported'));
            }
        } catch (\Exception $ex) { 
            DB::rollback(); // Rollback the transaction in case of an exception

             Log::error($ex);
            return false; 
        }
    }

    public function callback(Request $request, $bookPurchase)
    {
        $payment_details = json_encode($request->all());
        $onlinePayment = OnlinePayment::where('gateway_tracking', $request->order)->first();
        // for testing i will suggest it is false to make operations
        if ($request->success !== "true") {
            $bookPurchase->update([
                'status' => 'purchased'
            ]);
            $onlinePayment->update([
                'status' => 'purchased'
            ]);
            return $this->successResponse([], __('api.book-purchase-success'));
            // return (new CheckoutController)->checkout_done($request->merchant_order_id, $payment_details);
        } else {

            $bookPurchase->update([
                'status' => 'failed'
            ]);
            $onlinePayment->update([
                'status' => 'failed'
            ]);
            return $this->successResponse([], __('api.book-purchase-failed')); 
        }
    }
}
