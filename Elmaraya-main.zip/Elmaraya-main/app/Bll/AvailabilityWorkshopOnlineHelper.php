<?php

namespace App\Bll;


use Carbon\Carbon;
 use Illuminate\Database\Eloquent\Builder;

class AvailabilityWorkshopOnlineHelper
{
    public static function checkAvailability(Builder $model): bool
    {
        $now = Carbon::now();

        return $model->where('availability_start_date', '<=', $now)
            ->where(function ($query) use ($now) {
                $query->where('availability_end_date', '>', $now)
                    ->orWhereDate('availability_end_date', $now);
            })->exists();
    }
}
