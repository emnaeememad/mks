<?php

namespace App\Services;

use App\Models\Nadara;
use App\Enum\NadaraTypes;
use Illuminate\Http\Request;
use App\Exceptions\ModelNotFound;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class NadaraService
{
    public function getFeatured(
        int $limit = 2,
        string $publish_type = 'all'
    ): Collection {
        return Nadara::published()
            ->where('type', NadaraTypes::photos)
            ->whereIn('publish_type', ['all', $publish_type])
            ->where('is_featured', 1)
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }

    public function getDistinct(
        int $limit = 2,
        string $publish_type = 'all'
    ): Collection {
        return Nadara::published()
            // ->where('type', NadaraTypes::photos)
            ->whereIn('publish_type', ['all', $publish_type])
            ->where('is_distinctive', 1)
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }

    public function getFeaturedReels(
        int $limit = 6,
        string $publish_type = 'all'
    ): Collection {
        return Nadara::published()
            ->where('type', NadaraTypes::reels)
            ->whereIn('publish_type', ['all', $publish_type])
            ->where('is_featured', 1)
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }

    public function getRecommendation(
        int $limit = 4,
        string $publish_type = 'all'
    ): Collection {
        return Nadara::published()
            ->inRandomOrder()
            ->web()
            ->where('is_recommended', 1)
            ->limit($limit)
            ->get();
    }

    public function getFiltered(
        Request $request,
        string $publish_type = 'all',
        int $featured = 0
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');
        $category = $request->query('category');
        $author = $request->query('author');

        $nadaras =  Nadara::descOrder()
            ->published()
            // ->where('type', NadaraTypes::photos)
            ->whereIn('publish_type', ['all', $publish_type])
            ->when($category, fn ($q) => $q->where('category_id', $category))
            ->when($search, fn ($q) => $q->search($search))
            ->when($author, fn ($q) => $q->where('author_id', $author))
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ]);
        return $featured ? $nadaras->where('featured_group', 1)->paginate($limit) : $nadaras->paginate($limit);
    }

    public function getFilteredReels(
        Request $request,
        string $publish_type = 'all'
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 100);
        $search = $request->query('search');
        $category = $request->query('category');
        $author = $request->query('author');

        return Nadara::descOrder()
            ->published()
            ->where('type', NadaraTypes::reels)
            ->where('is_featured', 0)
            ->whereIn('publish_type', ['all', $publish_type])
            ->when($category, fn ($q) => $q->where('category_id', $category))
            ->when($search, fn ($q) => $q->search($search))
            ->when($author, fn ($q) => $q->where('author_id', $author))
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->paginate($limit);
    }

    public function getHomeReels(
        int $limit = 4,
        string $publish_type = 'all'
    ): Collection {
        return Nadara::published()
            ->where('type', NadaraTypes::reels)
            ->whereIn('publish_type', ['all', $publish_type])
            ->where('is_home', 1)
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }
/*
    public function getHomePhotos(
        int $limit = 6,
        string $publish_type = 'all'
    ): Collection {
        return Nadara::published()
            ->where('type', NadaraTypes::photos)
            ->whereIn('publish_type', ['all', $publish_type])
            ->where('is_home', 1)
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }
    */

    public function getHomePhotos(
        int $limit = 3,
        string $publish_type = 'all'
    ): Collection {
        return Nadara::published()
            ->web()
            ->where('is_home', 1)
            ->limit($limit)
            ->get();
    }

    public function getMobileFiltered(
        int $limit = 3,
        string $publish_type = 'all'
    ): Collection {
        return Nadara::published()
            ->web()
            ->where('featured_group', 1)
            ->limit($limit)
            ->get();
    }
    

    public function getHomeSlider(
        int $limit = 4,
        string $publish_type = 'all'
    ): Collection {
        return Nadara::published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->where('is_home_slider', 1)
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }

    public function getNadaraDetails(int $id): Nadara
    {
        $nadara = Nadara::with('images')->find($id);
        if ($nadara) {
            return $nadara;
        }
        throw new ModelNotFound;
    }

    public function getSlugableNadaraDetails(string $slug): Nadara
    {
        return Nadara::with('images')
            ->where('slug_'.app()->getLocale(), $slug)
            ->firstOrFail();
    }

    public function getRandomNadara(): ?Nadara
    {
        return Nadara::inRandomOrder()->published()->web()->first();
    }

    public function eventShare(int $id): void
    {
        Nadara::where('id', $id)->update([
            'total_shares' => DB::raw('total_shares + 1'),
        ]);

    }

    public function eventView(int $id): void
    {
        Nadara::where('id', $id)->update([
            'total_views' => DB::raw('total_views + 1'),
        ]);

    }

    public function eventPlay(int $id): void
    {
        Nadara::where('id', $id)->update([
            'total_plays' => DB::raw('total_views + 1'),
        ]);

    }
}
