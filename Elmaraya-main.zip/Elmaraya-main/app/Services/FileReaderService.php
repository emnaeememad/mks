<?php

namespace App\Services;

use App\Models\Orders;
use App\Models\Customer;

class FileReaderService
{
    /**
     * Check if the user can read the file.
     *
     * @param \App\Models\User $user
     * @param int $bookId
     * @return bool
     */
    public function canUserReadFile(Customer $user, int $bookId): bool
    {
        $orders = Orders::whereHas('orderBooks', function($q) use ($bookId) {
            $q->where('book_id', $bookId);
        })
        ->where('customer_id', $user->id)
        ->whereIn('status', ['purchased'])
        ->get();

        $isCustomerHasActiveSubscription = $user->customerSubscriptions()->active()->exists();

        $isPurchased = $orders->count() > 0;
        $canRead = $isPurchased || $isCustomerHasActiveSubscription;

        return $canRead;
    }
}