<?php

namespace App\Services;

use App\Enum\BlogModules;
use App\Exceptions\ModelNotFound;
use App\Models\Blog;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Collection as SupportCollection;
use Illuminate\Support\Facades\DB;

class BlogModulesService
{
    public function getRecommendation(
        string $module,
        int $limit = 3,
        string $publish_type = 'all'
    ): Collection {
        return Blog::moduleType($this->mapModuleFromEnum($module))
            ->published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->where('is_recommended', 1)
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }

    public function getFeatured(
        string $module,
        int $limit = 3,
        string $publish_type = 'all'
    ): Collection {
        return Blog::moduleType($this->mapModuleFromEnum($module))
            ->published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->where('is_featured', 1)
            ->orderBy('updated_at', 'Desc')
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }

    public function getFeaturedBlog(
        string $module,
        int $limit = 1,
        string $publish_type = 'all'
    ): Collection {
        return Blog::moduleType($this->mapModuleFromEnum($module))
            ->published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->where('is_feature_blog', 1)
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }

    public function getMostRead(
        string $module,
        int $limit = 4,
        string $publish_type = 'all'
    ): Collection {
        return Blog::moduleType($this->mapModuleFromEnum($module))
            ->published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->mostRead()
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }

    public function getReadToo(string $module, int $limit, int $categoryId, string $publish_type = 'all'): Collection
    {
        return Blog::moduleType($this->mapModuleFromEnum($module))
            ->published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->where('category_id', $categoryId)
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }

    public function getHomeSlider(
        string $module,
        int $limit = 4,
        string $publish_type = 'all'
    ): Collection {
        $blogs = Blog::moduleType($this->mapModuleFromEnum($module))
            ->published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->where('is_home_slider', 1)
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
                'category' => fn ($c) => $c->withTrashed(),
            ])
            ->get();



        return $blogs;
    }

    public function getHome(
        string $module,
        int $limit = 4,
        string $publish_type = 'all'
    ): Collection {
        return Blog::moduleType($this->mapModuleFromEnum($module))
            ->published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->where('is_home', 1)
            ->orderBy('blog_order_home', 'Desc')
            ->orderBy('post_date', 'Desc')
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
                'category' => fn ($c) => $c->withTrashed(),
            ])
            ->get();
    }

    public function getFeaturedHome(
        string $module,
        int $limit = 7,
        string $publish_type = 'all'
    ): Collection {
        return Blog::moduleType($this->mapModuleFromEnum($module))
            ->published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->where(function ($query) {
                $query->where('is_recommended', 1)
                    ->orWhere('is_featured', 1)
                    ->orWhere('is_home', 1);
            })
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
                'category' => fn ($c) => $c->withTrashed(),
            ])
            ->get();
    }

    public function getMostPublishedAuthors(
        string $module,
        int $limit = 4,
        string $publish_type = 'all'
    ): Collection {
        return Blog::moduleType($this->mapModuleFromEnum($module))
            ->published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->whereHas('author', fn ($a) => $a->where('is_public', 1))
            ->groupBy('author_id')
            ->limit($limit)
            ->select('author_id', DB::raw('COUNT(id) as blogs_count'))
            ->orderBy('blogs_count', 'DESC')
            ->with([
                'author' => fn ($a) => $a->where('is_public', 1),
            ])
            ->get();
    }

    public function getFiltered(
        string $module,
        Request $request,
        string $publish_type = 'all'
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');
        $category = $request->query('category');
        $author = $request->query('author');

        return Blog::moduleType($this->mapModuleFromEnum($module))
            ->orderBy('post_date', 'Desc')
            ->published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->when($category, fn ($q) => $q->where('category_id', $category))
            ->when($search, fn ($q) => $q->search($search))
            ->when($author, fn ($q) => $q->where('author_id', $author))
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->paginate($limit);
    }

    public function getBlogDetails(int $id): Blog
    {
        $blog = Blog::with([
            'author' => fn ($a) => $a->withTrashed(),
            'category' => fn ($c) => $c->withTrashed(),
        ])->find($id);
        if ($blog) {
            return $blog;
        }
        throw new ModelNotFound;
    }

    public function getSlugableBlogDetails(string $slug): Blog
    {
        return Blog::with([
            'author' => fn ($a) => $a->withTrashed(),
            'category' => fn ($c) => $c->withTrashed(),
        ])->where('slug_'.app()->getLocale(), $slug)
            ->firstOrFail();
    }

    public function eventView(int $id): void
    {
        Blog::where('id', $id)->update([
            'total_views' => DB::raw('total_views + 1'),
        ]);

    }

    public function eventWebView(string $slug): void
    {
        Blog::where('slug_'.app()->getLocale(), $slug)->update([
            'total_views' => DB::raw('total_views + 1'),
        ]);
    }

    public function eventShare(int $id): void
    {
        Blog::where('id', $id)->update([
            'total_shares' => DB::raw('total_shares + 1'),
        ]);

    }

    public function getBlogMostRead(
        Blog $blog,
        string $publish_type = 'all'
    ): SupportCollection {
        return count($blog->linked_data ?? []) > 0 ? Blog::published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->whereIn('id', $blog->linked_data)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get() : collect([]);
    }

    private function mapModuleFromEnum(string $module): string
    {
        return match ($module) {
            BlogModules::maraya_blogs => BlogModules::maraya_blogs,
            BlogModules::seminars => BlogModules::seminars,
            BlogModules::movie_news => BlogModules::movie_news,
            BlogModules::festivals => BlogModules::festivals,
            BlogModules::signing_parties => BlogModules::signing_parties,
            BlogModules::exhibitions => BlogModules::exhibitions,
            default => BlogModules::blogs
        };
    }
}
