<?php

namespace App\Services;

use App\Models\Movie;
use Illuminate\Http\Request;
use App\Exceptions\ModelNotFound;
use Illuminate\Support\Facades\DB;
use App\Scopes\NullMovieModuleScope;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class LongMoviesService
{
    public function getFeatured(
        int $limit = 2,
        string $publish_type = 'all'
    ): Collection {
        return Movie::withoutGlobalScope(NullMovieModuleScope::class)->published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->where('module_type', 'longmovies')
            ->where('is_featured', 1)
            ->inRandomOrder()
            ->limit($limit)
            ->get();
    }

    public function getRecommendation(
        int $limit = 4,
        string $publish_type = 'all'
    ): Collection {
        return Movie::withoutGlobalScope(NullMovieModuleScope::class)->published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->where('module_type', 'longmovies')
            ->inRandomOrder()
            ->limit($limit)
            ->get();
    }

    public function getFiltered(
        Request $request,
        string $publish_type = 'all'
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');

        return Movie::withoutGlobalScope(NullMovieModuleScope::class)->descOrder()
            ->published()
            ->where('module_type', 'longmovies')
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->when($search, fn ($q) => $q->search($search))
            ->paginate($limit);
    }

    public function getFilteredAndByCategories(
        Request $request,
        $categoryIds = [],
        string $publish_type = 'all'
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');

        return Movie::withoutGlobalScope(NullMovieModuleScope::class)->descOrder()
            ->published()
            ->where('module_type', 'longmovies')
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->when($search, fn ($q) => $q->search($search))
            ->whereHas('categories', function ($query) use ($categoryIds) {
                $query->whereIn('categories.id', $categoryIds);
            })
            ->paginate($limit);
    }
    public function getMovieDetails(int $id): Movie
    {
        $movie = Movie::withoutGlobalScope(NullMovieModuleScope::class)
            ->where('module_type', 'longmovies')
            ->with('images', 'videos')->find($id);
        if ($movie) {
            return $movie;
        }
        throw new ModelNotFound;
    }

    public function getSlugableMovieDetails(string $slug): Movie
    {
        return Movie::withoutGlobalScope(NullMovieModuleScope::class)->with('images', 'videos')
            ->where('module_type', 'longmovies')
            ->where('slug_' . app()->getLocale(), $slug)
            ->firstOrFail();
    }

    public function getRandomMovie(): ?Movie
    {
        return Movie::withoutGlobalScope(NullMovieModuleScope::class)
            ->where('module_type', 'longmovies')->web()->inRandomOrder()->published()->first();
    }

    public function eventShare(int $id): void
    {
        Movie::withoutGlobalScope(NullMovieModuleScope::class)->where('id', $id)->update([
            'total_shares' => DB::raw('total_shares + 1'),
        ]);
    }

    public function eventView(int $id): void
    {
        Movie::withoutGlobalScope(NullMovieModuleScope::class)
            ->where('id', $id)
            ->where('module_type', 'longmovies')
            ->update([
                'total_views' => DB::raw('total_views + 1'),
            ]);
    }
}
