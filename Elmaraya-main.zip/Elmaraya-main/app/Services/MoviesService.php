<?php

namespace App\Services;

use App\Exceptions\ModelNotFound;
use App\Models\Movie;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MoviesService
{
    public function getFeatured(
        int $limit = 2,
        string $publish_type = 'all'
    ): Collection {
        return Movie::published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->where('is_featured', 1)
            ->inRandomOrder()
            ->limit($limit)
            ->get();
    }

    public function getRecommendation(
        int $limit = 4,
        string $publish_type = 'all'
    ): Collection {
        return Movie::published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->inRandomOrder()
            ->limit($limit)
            ->get();
    }

    public function getFiltered(
        Request $request,
        string $publish_type = 'all'
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');

        return Movie::descOrder()
            ->published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->when($search, fn ($q) => $q->search($search))
            ->paginate($limit);
    }

    public function getFilteredAndByCategories(
        Request $request,
        $categoryIds = [],
        string $publish_type = 'all'
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');

        return Movie::descOrder()
            ->published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->when($search, fn ($q) => $q->search($search))
            ->whereHas('categories', function ($query) use ($categoryIds) {
                $query->whereIn('categories.id', $categoryIds);
            })
            ->paginate($limit);

    }
    public function getMovieDetails(int $id): Movie
    {
        $movie = Movie::with('images', 'videos')->find($id);
        if ($movie) {
            return $movie;
        }
        throw new ModelNotFound;
    }

    public function getSlugableMovieDetails(string $slug): Movie
    {
        return Movie::with('images', 'videos')
            ->where('slug_'.app()->getLocale(), $slug)
            ->firstOrFail();
    }

    public function getRandomMovie(): ?Movie
    {
        return Movie::web()->inRandomOrder()->published()->first();
    }

    public function eventShare(int $id): void
    {
        Movie::where('id', $id)->update([
            'total_shares' => DB::raw('total_shares + 1'),
        ]);

    }

    public function eventView(int $id): void
    {
        Movie::where('id', $id)->update([
            'total_views' => DB::raw('total_views + 1'),
        ]);

    }
}
