<?php

namespace App\Services;

use App\Enum\PayableModule;
use App\Models\PaymentMethod;
use Illuminate\Database\Eloquent\Collection;

class PaymentMethodService
{
    public function getBooksPaymentMethods(): Collection
    {
        return PaymentMethod::payableModule(PayableModule::books)
            ->active()
            ->get([
                'id',
                'name_ar',
                'name_en',
                'image',
            ]);
    }
    public function getAllPaymentMethods(): Collection
    {
        return PaymentMethod::with('types')->active()
            ->get([
                'id',
                'name_ar',
                'name_en',
                'image',
            ]);
    }
}
