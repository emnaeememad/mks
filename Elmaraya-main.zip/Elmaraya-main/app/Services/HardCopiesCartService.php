<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;

class HardCopiesCartService
{
    public function getFeeForTotalPrice($totalPrice)
    {
        $fee = DB::table('additional_fees')
            ->where('min_price', '<=', $totalPrice)
            ->where('max_price', '>=', $totalPrice)
            ->first();

        return $fee ? (float) $fee->fee : 0;
    }
}