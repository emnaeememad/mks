<?php

namespace App\Services;

use App\Enum\NadaraTypes;
use App\Exceptions\ModelNotFound;
use App\Models\Author;
use App\Models\Nadara;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AuthorService
{
    public function getFiltered(
        Request $request,
        string $publish_type = 'all'
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');
        

        return Author::descOrder()
            ->when($search, fn ($q) => $q->search($search))
            ->paginate($limit);
    }

    public function getAuthorDetails(int $id): Author
    {
        $author = Author::find($id);
        if ($author) {
            return $author;
        }
        throw new ModelNotFound;
    }
}
