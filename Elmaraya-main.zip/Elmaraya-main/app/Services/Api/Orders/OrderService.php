<?php

namespace App\Services\Api\Orders;

use App\Enum\BookType;
use App\Models\Orders;
use App\Enum\OrderType;
use App\Models\Shipping;
use App\Services\CartService;
use App\Models\ShippingDetails;
use App\Factories\CartItemFactory;
use Illuminate\Support\Facades\DB;
use App\Traits\CartItemTransformer;
use App\Factories\Orders\OrderFactory;
use App\Integrations\Payments\Paymob\Order;

class OrderService
{
    use CartItemTransformer;

    protected $cartService;

    public function __construct(CartService $cartService)
    {
        $this->cartService = $cartService;
    }
    public function createOrderAndOrderItems($customer_id, $gateway_tracking, $paymentId, $request)
    {
        $cartItems = $this->cartService->getAllItems($customer_id);
        $cartItemsByTypes = $cartItems->groupBy('item_type');

        // dd($cartItemsByTypes);
        foreach ($cartItemsByTypes as $type => $items) {

            $total_price_by_type = $this->cartService
                ->getTotalPriceByType($customer_id,  $type);

            $typeKeyword = $this->getModelKeyword($type);

            if ($typeKeyword == OrderType::book) {

                $itemsBooksGroupByTypes = $items->groupBy('book_type');
                foreach ($itemsBooksGroupByTypes as $booktype => $itemsBook) {
                    $total_price_by_type_and_book =  $this->cartService
                        ->getTotalPriceByTypeAndBookType(
                            $itemsBook
                        );
                    $orderbook =  Orders::create([
                        'customer_id' => $customer_id,
                        'payment_id'      => $paymentId,
                        'gateway_tracking'      => $gateway_tracking,
                        'total_price'     => $total_price_by_type_and_book,
                        'status' => 'pending',
                        'order_type' => OrderType::book,
                        'book_type' => $booktype
                    ]);
                
                    if ($booktype == BookType::physical) {
                        $shipping = Shipping::find($request->shipping_id);

                        ShippingDetails::create([
                            'first_name' => $request->first_name,
                            'last_name' => $request->last_name,
                            'phone_number' => $request->phone_number,
                            'email' => $request->email,
                            'order_id' => $orderbook->id,
                            'shipping_id' => $shipping->id,
                        ]);
                        $fee = DB::table('additional_fees')
                            ->where('min_price', '<=', $total_price_by_type_and_book)
                            ->where('max_price', '>=', $total_price_by_type_and_book)
                            ->first();
                        $total_price_by_type_and_book += $shipping->price;

                        if ($fee) {
                            $total_price_by_type_and_book += $fee->fee; // Assuming the fee column in the additional_fees table holds the fee amount
                            // Update the orderbook with the total_price and the additional_fee_id
                            $orderbook->update([
                                'total_price' => $total_price_by_type_and_book,
                                'additional_fee_id' => $fee->id, // Save the additional_fee_id to the orders table
                            ]);
                        } else {
                            $orderbook->update([
                                'total_price' => $total_price_by_type_and_book,
                            ]);
                        }
                    }
                    foreach ($itemsBook as $cartItemBook) {
                        $item_book = CartItemFactory::make(OrderType::book)->findItem($cartItemBook->item_id);
                        $orderFactoryBook = OrderFactory::createOrder($item_book, $cartItemBook->quantity, $orderbook->id, $orderbook);

                        $orderFactoryBook->save();
                    }
                }
            } else {
                $order =  Orders::create([
                    'customer_id' => $customer_id,
                    'payment_id'      => $paymentId,
                    'gateway_tracking'      => $gateway_tracking,
                    'total_price'     => $total_price_by_type,
                    'status' => 'pending',
                    'order_type' => $this->getModelKeyword($type),
                ]);
                foreach ($items as $cartItem) {
                    $item = CartItemFactory::make($this->getModelKeyword($type))->findItem($cartItem->item_id);
                    $orderFactory = OrderFactory::createOrder($item, $cartItem->quantity, $order->id, $order);
                    $orderFactory->save();
                }
            }
        }
    }
}
