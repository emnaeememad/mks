<?php

namespace App\Services\Api\Auth;

use App\Http\Requests\Api\Auth\EmailForgotPasswordRequest;
use App\Http\Requests\Api\Auth\EmailResetPasswordRequest;
use App\Http\Requests\Api\Auth\PhoneForgotPasswordRequest;
use App\Http\Requests\Api\Auth\PhoneResetPasswordRequest;
use App\Models\Customer;
use App\Services\Notifications\EmailNotification;
use App\Services\Notifications\SmsNotification;
use App\Traits\OtpGenerator;

class ForgotPasswordService
{
    use OtpGenerator;

    public function phoneForgotPassword(PhoneForgotPasswordRequest $request): bool
    {
        $customer = Customer::phone($request->get('phone_number'))->first();
        if ($customer) {
            $otp = $this->generateCode();
            $customerData = [
                'code' => $otp,
                'code_valid_till' => now()->addHour()->toDateTimeString(),
            ];
            if ($customer->canSendSms()) {
                $customerData['sms_count'] = $customer->sms_count <= 3 ? ($customer->sms_count + 1) : 1;
                $customerData['last_sms_time'] = now()->toDateTimeString();
                SmsNotification::sendResetOtp($customer, $otp);
            }
            $customer->update($customerData);
        }

        return true;
    }

    public function phoneResetPassword(PhoneResetPasswordRequest $request): bool
    {
        $customer = Customer::phone($request->get('phone_number'))->code($request->get('code'))->first();
        $this->changePassword($request, $customer);

        return true;
    }

    public function emailForgotPassword(EmailForgotPasswordRequest $request): bool
    {
        $customer = Customer::email($request->get('email'))->first();
        if ($customer) {
            $otp = $this->generateCode();
            $customerData = [
                'code' => $otp,
                'code_valid_till' => now()->addHour()->toDateTimeString(),
            ];
            EmailNotification::sendResetOtp($customer, $otp);
            $customer->update($customerData);
        }

        return true;
    }

    public function emailResetPassword(EmailResetPasswordRequest $request): bool
    {
        $customer = Customer::email($request->get('email'))->code($request->get('code'))->first();
        if($customer == null){
            return false;
        }
        $this->changePassword($request, $customer);

        return true;
    }

    private function changePassword(
        EmailResetPasswordRequest|PhoneResetPasswordRequest $request,
        ?Customer $customer = null
    ) {
        if ($customer && $customer->codeStillValid()) {
            $data = ['password' => $request->get('password')];

            if (! $customer->verified_at) {
                $data['verified_at'] = now()->toDateTimeString();
            }

            $customer->update($data);
        }
    }
}
