<?php

namespace App\Services\Api\Auth;

use Vonage\Client;
use App\Models\Customer;
use App\Traits\OtpGenerator;
use Vonage\Laravel\Facade\Vonage;
use Illuminate\Support\Facades\Log;
use Vonage\Verify\Client as VerifyClient;
use App\Services\TwoFactorAuthService;
use App\Http\Requests\Api\Auth\VerifyRequest;
use App\Http\Requests\Api\Auth\RegisterRequest;
use App\Services\Notifications\SmsNotification;
use App\Services\Notifications\EmailNotification;
use App\Http\Requests\Api\Auth\ResendVerificationRequest;

class RegisterService
{
    use OtpGenerator;

    public function register(RegisterRequest $request): Customer
    {
        $otp = $this->generateCode();

        $customer = Customer::create([
            ...$request->validated(),
            'code' => $otp,
            'code_valid_till' => now()->addHour()->toDateTimeString(),
            'sms_count' => 1,
            'last_sms_time' => now()->toDateTimeString(),
        ]);
        SmsNotification::sendOtp($customer, $otp);/// TODO old
        EmailNotification::sendOtp($customer, $otp);

        try {
            $twoFactorAuthService = new TwoFactorAuthService;
            $requestId = $twoFactorAuthService->sendVerificationOTP($customer);
        } catch (\Exception $ex) {
            Log::error('Failed to send otp code' . $ex);
            return $customer;
        }

      
        return $customer;
    }

    public function verify(VerifyRequest $request): bool
    {
        $customer = Customer::where([
            'phone_number' => $request->get('phone_number'),
            'email' => $request->get('email'),
            'code' => $request->get('code'),
        ])
            ->first();
        if ($customer == null) {
            return false;
        }
        // related to email
        if ($customer && $customer->codeStillValid()) {
            if (!$customer->verified_at) {
                $customer->update(['verified_at' => now()->toDateTimeString()]);
            }

            return true;
        }
        // related vonage
        if ($customer->verification_request_id) {
            // $verification = Vonage::verify()->check([
            //     'request_id' => $customer->verification_request_id,
            //     'code' => $request->input('code'), // The OTP code entered by the user
            // ]);
            try {

                $verificationResult = app(Client::class)->verify2()
                    ->check($customer->verification_request_id, $request->input('code'));

                if ($verificationResult) {
                    // Verification successful
                    // Update the verified_at timestamp for the customer
                    if (!$customer->verified_at) {
                        $customer->update(['verified_at' => now()->toDateTimeString()]);
                    }
                    return true;
                }
            } catch (\Exception $ex) {
                Log::error($ex);
                return false;
            }
        } else {
            return false;
        }
    }

    public function resendOtp(ResendVerificationRequest $request): bool
    {
        $customer = Customer::where('phone_number', $request->get('phone_number'))
            ->when($request->has('email'), fn ($q) => $q->where('email', $request->get('email')))
            ->whereNull('verified_at')
            ->first();

        if ($customer) {
            $otp = $this->generateCode();
            $customerData = [
                'code' => $otp,
                'code_valid_till' => now()->addHour()->toDateTimeString(),
                'verified_at' => null,
            ];
            if ($customer->canSendSms()) {
                $customerData['sms_count'] = $customer->sms_count <= 3 ? ($customer->sms_count + 1) : 1;
                $customerData['last_sms_time'] = now()->toDateTimeString();
                SmsNotification::sendOtp($customer, $otp);
            }
            EmailNotification::sendOtp($customer, $otp);
            $customer->update($customerData);
        }

        return true;
    }
}
