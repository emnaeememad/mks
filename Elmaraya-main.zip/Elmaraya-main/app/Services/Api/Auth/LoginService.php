<?php

namespace App\Services\Api\Auth;

use App\Enum\ApiTokenNames;
use App\Exceptions\NonVerifiedCustomer;
use App\Http\Requests\Api\Auth\LoginRequest;
use App\Models\Customer;
use Exception;
use Illuminate\Support\Facades\Hash;

class LoginService
{
    public function login(LoginRequest $loginRequest): Customer
    {
        $customer = Customer::where('phone_number', $loginRequest->get('phone_number'))->first();
        if (
            ! $customer ||
            (
                $customer &&
                ! Hash::check($loginRequest->get('password'), $customer->password)
            )
        ) {
            throw new Exception(__('api.invalid-credentials'));
        } elseif (! $customer->verified_at) {
            throw new NonVerifiedCustomer;
        }

        return $customer;
    }

    public function generateToken(Customer $customer): string
    {
        return $customer->createToken(ApiTokenNames::customerLogin)->plainTextToken;
    }
}
