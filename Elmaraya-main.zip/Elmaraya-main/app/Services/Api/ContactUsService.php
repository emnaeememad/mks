<?php

namespace App\Services\Api;

use App\Http\Requests\Api\ContactUs\ContactUsRequest;
use App\Models\ContactUs;

class ContactUsService
{
    public function apiContactUs(
        ContactUsRequest $request
    ): void {
        $nameTokens = collect(explode(' ', $request->get('name')));
        $data = $request->validated();
        $data['first_name'] = $nameTokens->pop() ?? '';
        $data['last_name'] = $nameTokens->implode(' ');
        $this->createContactUs($data);

    }

    private function createContactUs(
        array $data
    ): void {
        ContactUs::create([
            'first_name' => $data['first_name'] ?? '',
            'last_name' => $data['last_name'] ?? '',
            'phone_number' => $data['phone_number'] ?? '',
            'email' => $data['email'] ?? '',
            'message' => $data['message'] ?? '',
        ]);
    }
}
