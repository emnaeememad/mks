<?php

namespace App\Services\Api\Books;

use App\Models\Book;
use App\Models\Customer;
use Illuminate\Http\Request;
use App\Enum\CustomerBookStatus;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class CustomerBookService
{
    public function getBooks(
        Customer $customer,
        Request $request
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');

        $isCustomerHasActiveSubscription = $customer->customerSubscriptions()->active()->exists();

        return $customer->customerBooks()
            ->when($search, function ($query) use ($search) {
                $query->whereHas('book', fn ($b) => $b->withTrashed()->published()->search($search));
            })
            ->when(
                !$search,
                fn ($q) => $q->whereHas(
                    'book',
                    fn ($b) => $b->withTrashed()->published()
                )
            )
            ->when(!$isCustomerHasActiveSubscription, function ($query) {
                $query->where('book_access', CustomerBookStatus::full_time);
            })
            ->with([
                'book' => fn ($b) => $b->withTrashed()->select('id', 'name_ar', 'name_en', 'main_image', 'file'),
            ])
            ->paginate($limit);
    }

    public function getBooksNeedSub(
        Customer $customer,
        Request $request
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');
        $category = $request->query('category');
        $author = $request->query('author');

        return Book::loadAllRelations()
            ->requestTypeSubscription()
            ->published()
            ->when($request->has('most_read'), fn ($q) => $q->mostRead())
            ->when($request->has('most_sold'), fn ($q) => $q->mostSold())
            ->when($request->has('is_home'), fn ($q) => $q->isHome())
            ->when($request->has('is_featured'), fn ($q) => $q->isFeatured())
            ->when($request->has('is_recommended'), fn ($q) => $q->isRecommended())
            ->when($search, fn ($q) => $q->search($search))
            ->when($category, fn ($q) => $q->where('category_id', $category))
            ->when($author, fn ($q) => $q->where('author_id', $author))
            ->when(!$request->has('most_read'), fn ($q) => $q->descOrder())
            ->when(!$request->has('most_sold'), fn ($q) => $q->descOrder())
            ->paginate($limit);
    }


    public function getBooksNeedBurch(
        Customer $customer,
        Request $request
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');
        $category = $request->query('category');
        $author = $request->query('author');

        return Book::loadAllRelations()
            ->requestTypePurchased()
            ->published()
            ->when($request->has('most_read'), fn ($q) => $q->mostRead())
            ->when($request->has('most_sold'), fn ($q) => $q->mostSold())
            ->when($request->has('is_home'), fn ($q) => $q->isHome())
            ->when($request->has('is_featured'), fn ($q) => $q->isFeatured())
            ->when($request->has('is_recommended'), fn ($q) => $q->isRecommended())
            ->when($search, fn ($q) => $q->search($search))
            ->when($category, fn ($q) => $q->where('category_id', $category))
            ->when($author, fn ($q) => $q->where('author_id', $author))
            ->when(!$request->has('most_read'), fn ($q) => $q->descOrder())
            ->when(!$request->has('most_sold'), fn ($q) => $q->descOrder())
            ->paginate($limit);
    }

    public function getDistinctiveBooksNeedSub(
        Customer $customer,
        Request $request
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');
        $category = $request->query('category');
        $author = $request->query('author');

        return Book::loadAllRelations()
            ->requestTypeSubscription()
            ->published()
            ->isDistinctive()
            ->when($request->has('most_read'), fn ($q) => $q->mostRead())
            ->when($request->has('most_sold'), fn ($q) => $q->mostSold())
            ->when($request->has('is_home'), fn ($q) => $q->isHome())
            ->when($request->has('is_featured'), fn ($q) => $q->isFeatured())
            ->when($request->has('is_recommended'), fn ($q) => $q->isRecommended())
            ->when($search, fn ($q) => $q->search($search))
            ->when($category, fn ($q) => $q->where('category_id', $category))
            ->when($author, fn ($q) => $q->where('author_id', $author))
            ->when(!$request->has('most_read'), fn ($q) => $q->descOrder())
            ->when(!$request->has('most_sold'), fn ($q) => $q->descOrder())
            ->paginate($limit);
    }
}




