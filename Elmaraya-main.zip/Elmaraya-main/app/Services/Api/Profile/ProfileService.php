<?php

namespace App\Services\Api\Profile;

use App\Http\Requests\Api\Profile\ChangePasswordRequest;
use App\Http\Requests\Api\Profile\EditProfileRequest;
use App\Models\Customer;
use Exception;
use Illuminate\Support\Facades\Hash;

class ProfileService
{
    public function edit(
        Customer $customer,
        EditProfileRequest $request
    ): Customer {
        $customer->update($request->validated());

        return $customer;
    }

    public function changePassword(
        Customer $customer,
        ChangePasswordRequest $request
    ): bool {
        if (! Hash::check($request->get('old_password'), $customer->password)) {
            throw new Exception(__('api.wrong-old-password'));
        }
        $customer->update(['password' => $request->get('password')]);

        return true;
    }
}
