<?php

namespace App\Services;

use App\Models\MarayaBook;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Http\Request;

class MarayaBooksService
{
    public function bookList(
        Request $request
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');
        $category = $request->query('category');
        $author = $request->query('author');

        return MarayaBook::descOrder()
            ->published()
            ->when($category, fn ($q) => $q->where('category_id', $category))
            ->when($author, fn ($q) => $q->where('author_id', $author))
            ->when($search, fn ($q) => $q->search($search))
            ->paginate($limit);
    }
}
