<?php

namespace App\Services;

use App\Exceptions\ModelNotFound;
use App\Models\Trainer;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class TrainerService
{
    public function getTrainers($perPage = 20): LengthAwarePaginator
    {
        return Trainer::descOrder()->paginate($perPage);
    }

    public function getFiltered(
        Request $request,
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');
        

        return Trainer::descOrder()
            ->when($search, fn ($q) => $q->search($search))
            ->paginate($limit);
    }

    public function createTrainer(array $data): Trainer
    {
        $data['slug_en'] = $data['name_en'];
        $data['slug_ar'] = $data['name_ar'];
        $data['photo'] = Storage::disk('public')->put('trainers', $data['photo']);
        return Trainer::create($data);
    }

    public function find(int $id): Trainer
    {
        $trainer = Trainer::find($id);
        if ($trainer) {
            return $trainer;
        }
        throw new ModelNotFound;
    }

    public function update(array $data, int $id): Trainer
    {
        $trainer = $this->find($id);
        $data['slug_en'] = $data['name_en'];
        $data['slug_ar'] = $data['name_ar'];
        if (isset($data['photo'])) {
            Storage::disk('public')->delete($trainer->photo);
            $data['photo'] = Storage::disk('public')->put('trainers', $data['photo']);
        }
        $trainer->update($data);
        return $trainer;
    }
}