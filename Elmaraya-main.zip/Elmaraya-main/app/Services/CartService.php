<?php

namespace App\Services;

use App\Models\Book;
use App\Models\Cart;
use App\Enum\BookType;
use App\Enum\OrderType;
use App\Models\Customer;
use GuzzleHttp\Psr7\Request;
use App\Bll\Orders\OrderBook;
use App\Models\WorkshopOnline;
use App\Factories\CartItemFactory;
use App\Traits\CartItemTransformer;
use App\Http\Controllers\ApiBaseController;
use App\Integrations\Payments\Paymob\Order;

class CartService extends ApiBaseController
{
    use CartItemTransformer;

    public function addToCart(Customer $customer, $item, $quantity, $request)
    {
        // Add item to the user's cart
        $cartItem = new Cart();
        $cartItem->customer_id = $customer->id;
        $cartItem->item_id = $item->id;
        $cartItem->item_type = get_class($item);
        $cartItem->quantity = $quantity;
        if ($request->has('book_type')) {
            $cartItem->book_type = $request->book_type;
        }
        $cartItem->save();

        // You can add more logic here if needed, such as updating quantities or calculating totals
    }

    public function updateQuantity($cartId, $quantity)
    {
        // Find the cart item
        $cartItem = Cart::findOrFail($cartId);

        if ($this->getItemTypeKeyword($cartItem->item_type) == OrderType::workshoponline) {
            return $cartItem;
        }
        if ($cartItem->book_type == BookType::digital) {
            return $cartItem;
        }
        // Update the quantity
        $cartItem->update(['quantity' => $quantity]);

        // Return the updated cart item
        return $cartItem;
    }

    public function removeFromCart($cartId)
    {
        // Find the cart item
        $cartItem = Cart::findOrFail($cartId);

        // Delete the cart item
        $cartItem->delete();

        // Return true to indicate successful removal
        return true;
    }
    public function getAllItems($userId)
    {
        // Retrieve all cart items for the user
        return Cart::where('customer_id', $userId)->get();
    }

    public function getTotalPrice($userId, $type)
    {
        // Retrieve all cart items for the user
        $cartItems = Cart::where('customer_id', $userId)->get();

        // Calculate the total price
        $totalPrice = 0;
        foreach ($cartItems as $cartItem) {
            $item = CartItemFactory::make($this->getModelKeyword($type))->findItem($cartItem->item_id);
            $totalPrice += $this->calculatePriceForItem($item, $cartItem->quantity, $this->getModelKeyword($type), $cartItem);
        }

        return $totalPrice;
    }

    public function calculatePriceForItem($item, $quantity, $type, $cartItem)
    {
        switch ($type) {
            case OrderType::book:
                return $this->calculatePriceForBook($item, $quantity, $cartItem);
            case OrderType::workshoponline:
                return $this->calculatePriceForWorkshopOnline($item);
            default:
                return 0;
        }
    }
    public function calculatePriceForBook($item, $quantity, $cartItem)
    {
        if ($item instanceof Book) {
            if ($cartItem->book_type == BookType::digital) {
                return $item->epob_price;
            } else {
                return $item->hard_copy_price * $quantity;
            }
        }
        return 0;
    }
    public function calculatePriceForWorkshopOnline($item)
    {
        if ($item instanceof WorkshopOnline) {
            return $item->price;
        }
        return 0;
    }

    public function getTotalPriceByType($customer_id, $type)
    {
        // Retrieve all cart items for the user
        $cartItems = Cart::where('customer_id', $customer_id)
            ->where('item_type', ($type))
            ->get();

        // Calculate the total price
        $totalPrice = 0;
        foreach ($cartItems as $cartItem) {
            $item = CartItemFactory::make($this->getModelKeyword($type))->findItem($cartItem->item_id);
            $totalPrice += $this->calculatePriceForItem($item, $cartItem->quantity, $this->getModelKeyword($type), $cartItem);
        }

        return $totalPrice;
    }

    public function getTotalPricePerItemType($customer_id)
    {
        $total_price = 0;
        $cartItems = $this->getAllItems($customer_id);
        if ($cartItems->isEmpty()) {
            return 0;
        }

        $cartItemsByTypes = $cartItems->groupBy('item_type');
        foreach ($cartItemsByTypes as $type => $cartItem) {
            $total_price += $this->getTotalPriceByType($customer_id, $type);
        }
        return $total_price;
    }


    public function clearCart($customer_id)
    {
        $cartItems = Cart::where('customer_id', $customer_id);
        $cartItems->delete();
    }
    public function getTotalPriceByTypeAndBookType($itemsBook)
    {
        $totalPrice = 0;
        foreach ($itemsBook as $cartItem) {
            $item = CartItemFactory::make(OrderType::book)->findItem($cartItem->item_id);
            $totalPrice += $this->calculatePriceForItem($item, $cartItem->quantity, OrderType::book, $cartItem);
        }

        return $totalPrice;
    }

    public function getPhysicalBookItems($customer_id)
    {
        $physicalItems = Cart::where('customer_id', $customer_id)
            ->where('book_type', BookType::physical)
            ->get();
        return $physicalItems;
    }

    public function calculatePriceForPhysicalBook($customer_id)
    {
        $physicalItems = $this->getPhysicalBookItems($customer_id);

        $total_price = 0;
        foreach ($physicalItems as $physicalItem) {
            $book = Book::find($physicalItem->item_id);
            $total_price += $book->hard_copy_price * $physicalItem->quantity;
        }
        return  $total_price;
    }

    public function clearCartById($cartIds)
    {
        // Use the whereIn method to find all cart items with IDs in the $cartIds array
        $cartItems = Cart::whereIn('id', $cartIds)->get();

        // Loop through each cart item and delete it
        foreach ($cartItems as $cartItem) {
            $cartItem->delete();
        }
    }

    public function getAllItemsCount($customer_id)
    {
        $cart = $this->getAllItems($customer_id);
        return ($cart->sum('quantity'));
    }


    public function calculatePriceForHardCopies( $items)
    {
        $total_price = 0;
        foreach ($items as $physicalItem) {
            $book = Book::find($physicalItem->item_id);
            $total_price += $book->hard_copy_price * $physicalItem->quantity;
        }
        return  $total_price;
    }

    public function getAllDigitalItems($userId)
    {
        // Retrieve all cart items for the user
        return Cart::where('customer_id', $userId)
            ->where(function ($query) {
                $query->where('book_type', BookType::digital)
                    ->orWhere('book_type', null);
            })
            ->get();
    }

    public function getTotalPricePerDigitalType($cartItems)
    {
        if ($cartItems->isEmpty()) {
            return 0;
        }

        $cartItemsByTypes = $cartItems->groupBy('item_type');
        $totalPrice = 0;

        foreach ($cartItemsByTypes as $type => $cartItems) {
            foreach ($cartItems as $cartItem) {
                $item = CartItemFactory::make($this->getModelKeyword($type))->findItem($cartItem->item_id);
                $totalPrice += $this->calculatePriceForDigitalItem($item, $this->getModelKeyword($type));
            }
        }
        return $totalPrice;
    }
 
  
    public function calculatePriceForDigitalItem($item, $type)
    {
        switch ($type) {
            case OrderType::book:
                return $this->calculatePriceForDigitalBook($item);
            case OrderType::workshoponline:
                return $this->calculatePriceForWorkshopOnline($item);
            default:
                return 0;
        }
    }
    public function calculatePriceForDigitalBook($item)
    {
        return $item->epob_price; 
    }
    
}
