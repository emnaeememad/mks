<?php

namespace App\Services;

use App\Exceptions\ModelNotFound;
use App\Models\DigitalTraining;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class DigitalTrainingService
{
    public function getDigtals($perPage = 20): LengthAwarePaginator
    {
        return DigitalTraining::descOrder()->paginate($perPage);
    }

    public function getAllDigtals()
    {
        return DigitalTraining::descOrder()->get();
    }

    public function getAllDigtalsIgnorCurrent($id)
    {
        return DigitalTraining::descOrder()->where('id', '!=', $id)->get();
    }

    public function getFiltered(
        Request $request,
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');
        

        return DigitalTraining::descOrder()
            ->when($search, fn ($q) => $q->search($search))
            ->paginate($limit);
    }

    public function createDigitalTraining(array $data): DigitalTraining
    {
        $data['slug_en'] = $data['title_en'];
        $data['slug_ar'] = $data['title_ar'];
        $data['intro'] = Storage::disk('public')->put('digital-training/intro', $data['intro']);
        $digitalTraining = DigitalTraining::create($data);
        $digitalTraining->similars()->sync($data['similar_digitals']);
        return $digitalTraining;
    }

    public function find(int $id): DigitalTraining
    {
        $digitalTraining = DigitalTraining::find($id);
        if ($digitalTraining) {
            return $digitalTraining;
        }
        throw new ModelNotFound;
    }

    public function update(array $data, int $id): DigitalTraining
    {
        $digitalTraining = $this->find($id);
        $data['slug_en'] = $data['title_en'];
        $data['slug_ar'] = $data['title_ar'];
        if (isset($data['intro'])) {
            $data['intro'] = Storage::disk('public')->put('digital-training/intro', $data['intro']);
            Storage::disk('public')->delete($digitalTraining->intro);
        }
        if(isset($data['similar_digitals'])){
            $digitalTraining->similars()->sync($data['similar_digitals']);
        }
        $digitalTraining->update($data);
        return $digitalTraining;
    }
}