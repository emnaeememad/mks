<?php

namespace App\Services;

use App\Enum\BlogModules;
use App\Models\Author;
use App\Models\Blog;
use App\Models\Book;
use App\Models\Movie;
use App\Models\Nadara;
use App\Models\Story;
use App\Models\Workshop;
use Throwable;

final class BreadcrumbService
{
    public static function getModelBreadcrumb($model): array
    {
        if ($model instanceof Book) {
            return self::getBookBreadcrumb($model);
        } elseif ($model instanceof Movie) {
            return self::getMovieBreadcrumb($model);
        } elseif ($model instanceof Workshop) {
            return self::getWorkshopBreadcrumb($model);
        } elseif ($model instanceof Story) {
            return self::getStoryBreadcrumb($model);
        } elseif ($model instanceof Author) {
            return self::getAuthorBreadcrumb($model);
        } elseif ($model instanceof Nadara) {
            return self::getNadaraBreadcrumb($model);
        } elseif ($model instanceof Blog) {
            return self::getBlogModuleBreadcrumb($model);
        }

        return [];
    }

    private static function getBookBreadcrumb(Book $model): array
    {
        $breadcrumb = collect([
            ['label' => __('landing/home.home'), 'link' => route('landingPage.home', ['lang' => app()->getLocale()])],
            ['label' => __('landing/home.books'), 'link' => route('landingPage.book', ['lang' => app()->getLocale()])],
        ]);

        if ($model?->category?->parentCategory) {
            $breadcrumb->push([
                'label' => $model?->category?->parentCategory->name_translated,
                'link' => route('landingPage.book', ['lang' => app()->getLocale(), 'category' => $model?->category?->parentCategory->id]),
            ]);
        }

        $breadcrumb->push([
            'label' => $model?->category?->name_translated,
            'link' => route('landingPage.book', ['lang' => app()->getLocale(), 'category' => $model?->category?->id]),
        ]);

        //        $breadcrumb->push(['label' => $model?->name_translated, 'link' => '']);

        return $breadcrumb->toArray();
    }

    private static function getMovieBreadcrumb(Movie $model): array
    {
        return [
            ['label' => __('landing/home.home'), 'link' => route('landingPage.home', ['lang' => app()->getLocale()])],
            ['label' => __('landing/home.movies'), 'link' => route('landingPage.movie', ['lang' => app()->getLocale()])],
            //            ['label' => $model?->name_translated, 'link' => ''],
        ];
    }

    private static function getWorkshopBreadcrumb(Workshop $model): array
    {
        return [
            ['label' => __('landing/home.home'), 'link' => route('landingPage.home', ['lang' => app()->getLocale()])],
            ['label' => __('landing/home.workshops'), 'link' => route('landingPage.workshop', ['lang' => app()->getLocale()])],
            //            ['label' => $model?->title_translated, 'link' => ''],
        ];
    }

    private static function getStoryBreadcrumb(Story $model): array
    {
        $breadcrumb = collect([
            ['label' => __('landing/home.home'), 'link' => route('landingPage.home', ['lang' => app()->getLocale()])],
            ['label' => __('landing/home.stories'), 'link' => route('landingPage.story', ['lang' => app()->getLocale()])],
        ]);

        if ($model?->category?->parentCategory) {
            $breadcrumb->push([
                'label' => $model?->category?->parentCategory->name_translated,
                'link' => route('landingPage.story', ['lang' => app()->getLocale(), 'category' => $model?->category?->parentCategory->id]),
            ]);
        }

        $breadcrumb->push([
            'label' => $model?->category?->name_translated,
            'link' => route('landingPage.story', ['lang' => app()->getLocale(), 'category' => $model?->category?->id]),
        ]);

        //        $breadcrumb->push(['label' => $model?->title_translated, 'link' => '']);

        return $breadcrumb->toArray();
    }

    private static function getAuthorBreadcrumb(Author $model): array
    {
        return [
            ['label' => __('landing/home.home'), 'link' => route('landingPage.home', ['lang' => app()->getLocale()])],
            ['label' => __('landing/home.our_writers'), 'link' => route('landingPage.authors', ['lang' => app()->getLocale()])],
            //            ['label' => $model?->name_translated, 'link' => ''],
        ];
    }

    private static function getNadaraBreadcrumb(Nadara $model): array
    {
        $breadcrumb = collect([
            ['label' => __('landing/home.home'), 'link' => route('landingPage.home', ['lang' => app()->getLocale()])],
            ['label' => __('landing/home.glass'), 'link' => route('landingPage.nadara', ['lang' => app()->getLocale()])],
        ]);

        if ($model?->category?->parentCategory) {
            $breadcrumb->push([
                'label' => $model?->category?->parentCategory->name_translated,
                'link' => route('landingPage.nadara', ['lang' => app()->getLocale(), 'category' => $model?->category?->parentCategory->id]),
            ]);
        }

        $breadcrumb->push([
            'label' => $model?->category?->name_translated,
            'link' => route('landingPage.nadara', ['lang' => app()->getLocale(), 'category' => $model?->category?->id]),
        ]);

        //        $breadcrumb->push(['label' => $model?->title_translated, 'link' => '']);

        return $breadcrumb->toArray();
    }

    private static function getBlogModuleBreadcrumb(Blog $model): array
    {
        $breadcrumb = collect([
            ['label' => __('landing/home.home'), 'link' => route('landingPage.home', ['lang' => app()->getLocale()])],
        ]);

        $routeLabel = $routeName = '';

        switch ($model->module_type) {
            case BlogModules::blogs:
                $routeLabel = __('landing/home.blogs');
                $routeName = 'landingPage.blogs';
                break;
            case BlogModules::maraya_blogs:
                $routeLabel = __('landing/home.maraya_blogs');
                $routeName = 'landingPage.maraya-blogs';
                break;
            case BlogModules::seminars:
                $routeLabel = __('landing/home.seminars');
                $routeName = 'landingPage.seminars';
                break;
            case BlogModules::movie_news:
                $routeLabel = __('landing/home.movie_news');
                $routeName = 'landingPage.movie_news';
                break;
            case BlogModules::festivals:
                $routeLabel = __('landing/home.festivals');
                $routeName = 'landingPage.festivals';
                break;
            case BlogModules::signing_parties:
                $routeLabel = __('landing/home.signing_parties');
                $routeName = 'landingPage.signing_parties';
                break;
            case BlogModules::exhibitions:
                $routeLabel = __('landing/home.exhibitions');
                $routeName = 'landingPage.exhibitions';
                break;
        }

        if ($routeName && $routeLabel) {
            $breadcrumb->push(['label' => $routeLabel, 'link' => route($routeName, ['lang' => app()->getLocale()])]);

            try {
                if ($model?->category?->parentCategory) {
                    $breadcrumb->push([
                        'label' => $model?->category?->parentCategory->name_translated,
                        'link' => route($routeName, ['lang' => app()->getLocale(), 'category' => $model?->category?->parentCategory->id]),
                    ]);
                }
            } catch (Throwable $e) {
                // just for ignore exceptions in case of changing route name
            }

            try {
                $breadcrumb->push([
                    'label' => $model?->category?->name_translated,
                    'link' => route($routeName, ['lang' => app()->getLocale(), 'category' => $model?->category?->id]),
                ]);
            } catch (Throwable $e) {
                // just for ignore exceptions in case of changing route name
            }

//            $breadcrumb->push(['label' => $model?->title_translated, 'link' => '']);
        }

        return $breadcrumb->toArray();
    }
}
