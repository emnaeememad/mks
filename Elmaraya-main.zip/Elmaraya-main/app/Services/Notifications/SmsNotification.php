<?php

namespace App\Services\Notifications;

use App\Models\Customer;
use Illuminate\Support\Facades\Log;

class SmsNotification
{
    /**
     * @todo implementation missed
     */
    public static function sendOtp(
        Customer $customer,
        string $otp
    ): void {
        $msg = __('emails.sms.verify-otp', ['otp' => $otp]);
        Log::info('we try to send an otp via sms', ['otp' => $otp, 'phone' => $customer->phone_number, 'msg' => $msg]);
    }

    /**
     * @todo implementation missed
     */
    public static function sendResetOtp(
        Customer $customer,
        string $otp
    ): void {
        $msg = __('emails.sms.reset-otp', ['otp' => $otp]);
        Log::info('we try to send a reset otp via sms', ['otp' => $otp, 'phone' => $customer->phone_number, 'msg' => $msg]);
    }
}
