<?php

namespace App\Services\Notifications;

use App\Mail\ResetCustomerOtp;
use App\Mail\VerifyCustomerOtp;
use App\Models\Customer;
use Error;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class EmailNotification
{
    public static function sendOtp(
        Customer $customer,
        string $otp
    ): void {
        $lang = 'ar';
        $message = __('emails.verify-otp', ['name' => $customer->name, 'otp' => $otp]);
        try {
            Mail::to($customer->email)
            ->send(new VerifyCustomerOtp($lang, $message));
            Log::channel('emails')->info('we try to send an otp via mail', [
                'otp' => $otp,
                'email' => $customer->email,
            ]);
        } catch (Exception|Error $e) {
            Log::channel('emails')->error('We can`t send an otp via mail', [
                'otp' => $otp,
                'email' => $customer->email,
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);
        }
    }

    /**
     * @todo implementation missed
     */
    public static function sendResetOtp(
        Customer $customer,
        string $otp
    ): void {
        $lang = 'ar';
        $message = __('emails.reset-otp', ['name' => $customer->name, 'otp' => $otp]);
        try {
            Mail::to($customer->email)->send(new ResetCustomerOtp($lang, $message));
 
            Log::channel('emails')->info('we try to send a reset otp via mail', [
                'otp' => $otp,
                'email' => $customer->email,
            ]);
        } catch (Exception|Error $e) {
            Log::error($e);

 
             Log::channel('emails')->error('We can`t send a reset otp via mail', [
                'otp' => $otp,
                'email' => $customer->email,
                'exception' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);
        }
    }
}
