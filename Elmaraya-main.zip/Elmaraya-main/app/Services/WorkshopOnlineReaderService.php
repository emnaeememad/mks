<?php

namespace App\Services;

use App\Models\Orders;
use App\Models\Customer;
use App\Models\WorkshopOnline;
use App\Bll\AvailabilityWorkshopOnlineHelper;

class WorkshopOnlineReaderService
{
    /**
     * Check if the user can read the file.
     *
     * @param \App\Models\User $user
     * @param int $workshoponlineId
     * @return bool
     */
    public function canUserReadFile(Customer $user, int $workshoponlineId): bool
    {
        $orders = Orders::whereHas('orderWorkshopsOnline', function($q) use ($workshoponlineId) {
            $q->where('workshop_online_id', $workshoponlineId);
        })
        ->where('customer_id', $user->id)
        ->whereIn('status', ['purchased'])
        ->get();

        $isCustomerHasActiveSubscription = $user->customerSubscriptions()->active()->exists();
        $isAccessFreeAvailability = AvailabilityWorkshopOnlineHelper::checkAvailability(WorkshopOnline::where('id', $workshoponlineId));

        $isPurchased = $orders->count() > 0;
        $canRead = $isPurchased || $isCustomerHasActiveSubscription ||  $isAccessFreeAvailability;

        return $canRead;
    }
}