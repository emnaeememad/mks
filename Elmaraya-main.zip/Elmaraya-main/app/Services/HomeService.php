<?php

namespace App\Services;

use App\Models\Book;
use App\Models\Movie;
use App\Models\Workshop;
use stdClass;

class HomeService
{
    public function getArtSection(): object
    {
        $result = new stdClass;

        $result->movie = Movie::published()->descOrder()->first();
        $result->workshop = Workshop::descOrder()->first();
        $result->books = Book::isHome()->published()->descOrder()->limit(3)->get();

        return $result;
    }

    public function getRandomData(): array
    {
        return [
            'book' => (new BooksService)->getRandomBook(),
            'movie' => (new MoviesService)->getRandomMovie(),
            'workshop' => (new WorkshopsService)->getRandomWorkshop(),
        ];
    }
}
