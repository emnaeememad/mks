<?php

namespace App\Services;

use App\Exceptions\ModelNotFound;
use App\Http\Requests\Api\Workshops\ApplyForWorkshopRequest;
use App\Models\Workshop;
use App\Models\WorkshopRequest;
use App\Models\WorkshopRequestAttachment;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class WorkshopsService
{
    public function getCurrent(
        Request $request,
        string $publish_type = 'all'
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');

        return Workshop::descOrder()
            ->where('is_current', 1)
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->when($search, fn ($q) => $q->search($search))
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->paginate($limit);
    }

    public function getPassed(
        Request $request,
        string $publish_type = 'all'
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');

        return Workshop::descOrder()
            ->where('is_current', 0)
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->when($search, fn ($q) => $q->search($search))
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->paginate($limit);
    }

    public function getFiltered(
        Request $request,
        string $publish_type = 'all'
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');
        $author = $request->query('author');

        return Workshop::descOrder()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->when($search, fn ($q) => $q->search($search))
            ->when($author, fn ($q) => $q->where('author_id', $author))
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->paginate($limit);
    }

    public function getMostApplied(
        int $limit = 4,
        string $publish_type = 'all'
    ): Collection {
        return Workshop::descOrder()
            ->where('is_current', 1)
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->mostApplied()
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }

    public function getWorkshopDetails(int $id): Workshop
    {
        $workshop = Workshop::with([
            'author' => fn ($a) => $a->withTrashed(),
        ])->find($id);
        if ($workshop) {
            return $workshop;
        }
        throw new ModelNotFound;
    }

    public function getSlugableWorkshopDetails(string $slug): Workshop
    {
        return Workshop::with([
            'author' => fn ($a) => $a->withTrashed(),
        ])->where('slug_'.app()->getLocale(), $slug)
            ->firstOrFail();
    }

    public function getRandomWorkshop(): ?Workshop
    {
        return Workshop::web()->inRandomOrder()->first();
    }

    public function applyForWorkshop(
        int $workshopId,
        ApplyForWorkshopRequest $request,
    ): void {
        $workshop = Workshop::find($workshopId);
        if ($workshop) {
            $workshopRequest = WorkshopRequest::create([
                'workshop_id' => $workshopId,
                'name' => $request->get('name'),
                'age' => $request->get('age'),
                'phone_number' => $request->get('phone_number'),
                'email' => $request->get('email'),
                'address' => $request->get('address'),
                'why_join_us' => $request->get('why_join_us'),
                'customer_id' => $request->user('sanctum')->id ?? null,
            ]);
            foreach ($request->file('files', []) as $file) {
                WorkshopRequestAttachment::create([
                    'workshop_request_id' => $workshopRequest->id,
                    'attachment' => $file,
                ]);
            }
            Workshop::where('id', $workshopId)->update([
                'total_requests' => DB::raw('total_requests + 1'),
            ]);
        }
    }

    public function eventShare(int $id): void
    {
        Workshop::where('id', $id)->update([
            'total_shares' => DB::raw('total_shares + 1'),
        ]);

    }
}
