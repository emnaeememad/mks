<?php

declare(strict_types=1);

namespace App\Services;

use Exception;
use Vonage\Client;
use App\Models\Customer;
use Vonage\Verify\Request;

use Vonage\Laravel\Facade\Vonage;
use Illuminate\Support\Facades\Log;
use Vonage\Client\Credentials\Basic;
use Vonage\Verify\Client as VerifyClient;
use Vonage\Verify2\Request\SMSRequest;
use Vonage\Verify2\VerifyObjects\VerificationWorkflow;

final class TwoFactorAuthService
{
    public function sendVerification(Customer $user): string
    {
        $smsRequest = (new SMSRequest(
            to: $user->phone_number,
            brand: 'Vonage Verify',
        ));

        $voiceWorkflow = new VerificationWorkflow(
            channel: VerificationWorkflow::WORKFLOW_VOICE,
            to: $user->phone_number,
        );

        $smsRequest->addWorkflow($voiceWorkflow);

        $result = app(Client::class)
            ->verify2()
            ->startVerification($smsRequest);

        return $result['request_id'];
    }

    public function verify(string $code, string $requestId): bool
    {
        try {
            return app(Client::class)
                ->verify2()
                ->check($requestId, $code);
        } catch (Exception) {
            return false;
        }
    }

    public function sendVerificationOTP(Customer $user)
    {
        // $verification = new Request($user->phone_number, 'Elmaraya.net');
        // $vonageKey = env('VONAGE_KEY');

        // $vonageSecret = env('VONAGE_SECRET');
      
        $formattedPhoneNumber = $this->addPrefixIfNotZero($user->phone_number);
        $verification = Vonage::verify()->start([
            'number' => $formattedPhoneNumber,
            'brand' => 'elmaraya.net',
        ]);

        if ($verification->getResponseData()['status'] == '0') {
            // Verification request successful
            $requestId = $verification->getResponseData()['request_id'];

            // Store the request ID in the user's record for verification later
            $user->verification_request_id = $requestId;
            $user->save();

            // return response()->json([
            //     'message' => 'Verification code sent successfully',
            // ]);
        } else {
            Log::error('Failed to send otp code  sendVerificationOTP function line 78');
        }

        // Verification request failed
        // return response()->json([
        //     'message' => 'Failed to send verification code',
        // ], 500);

    }

    public function verifyCode(Request $request, $customer)
    {

        $verification = Vonage::verify()->check([
            'request_id' => $customer->verification_request_id,
            'code' => $request->input('code'), // The OTP code entered by the user
        ]);

        if ($verification->getResponseData()['status'] == '0') {
            // Verification successful
            // Perform your desired actions for a verified user
            // return response()->json([
            //     'message' => 'Verification successful',
            // ]);
        }

        // // Verification failed
        // return response()->json([
        //     'message' => 'Verification failed',
        // ], 400);
    }

    function addPrefixIfNotZero($phoneNumber)
    {
        // Check if the first character is not '0'
        if ($phoneNumber[0] !== '0') {
            // Add the '+20' prefix
            $phoneNumber = '+20' . $phoneNumber;
        }else {
            $phoneNumber = '+2' . $phoneNumber;
        }
        return $phoneNumber;
    }
}
