<?php

namespace App\Services;

use App\Exceptions\ModelNotFound;
use App\Models\Story;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StoriesService
{
    public function getRecommendation(
        int $limit = 3,
        string $publish_type = 'all'
    ): Collection {
        return Story::published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->where('is_recommended', 1)
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }

    public function getFeatured(
        int $limit = 3,
        string $publish_type = 'all'
    ): Collection {
        return Story::published()
            ->whereIn('publish_type', ['all', $publish_type])
            ->where('is_featured', 1)
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }

    public function getHome(
        int $limit = 3,
        string $publish_type = 'all'
    ): Collection {
        return Story::published()
            ->whereIn('publish_type', ['all', $publish_type])
            ->where('is_home', 1)
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }

    public function getFeaturedHome(
        int $limit = 2,
        string $publish_type = 'all'
    ): Collection {
        return Story::published()
            ->whereIn('publish_type', ['all', $publish_type])
            ->where(function ($query) {
                $query->where('is_recommended', 1)
                    ->orWhere('is_featured', 1)
                    ->orWhere('is_home', 1);
            })
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
                'category' => fn ($c) => $c->withTrashed(),
            ])
            ->get();
    }

    public function getHomeSlider(
        int $limit = 4,
        string $publish_type = 'all'
    ): Collection {
        return Story::published()
            ->whereIn('publish_type', [$publish_type, 'all'])
            ->where('is_home_slider', 1)
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
                'category' => fn ($c) => $c->withTrashed(),
            ])
            ->get();
    }

    public function getMostPlayed(
        int $limit = 4,
        string $publish_type = 'all'
    ): Collection {
        return Story::published()
            ->whereIn('publish_type', ['all', $publish_type])
            ->mostPlayed()
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }

    public function getFiltered(
        Request $request,
        string $publish_type = 'all'
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');
        $category = $request->query('category');
        $author = $request->query('author');

        return Story::descOrder()
            ->published()
            ->whereIn('publish_type', ['all', $publish_type])
            ->when($category, fn ($q) => $q->where('category_id', $category))
            ->when($search, fn ($q) => $q->search($search))
            ->when($author, fn ($q) => $q->where('author_id', $author))
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->paginate($limit);
    }

    public function getReadToo(int $categoryId, int $limit = 4, string $publish_type = 'all'): Collection
    {
        return Story::descOrder()
            ->published()
            ->whereIn('publish_type', ['all', $publish_type])
            ->where('category_id', $categoryId)
            ->inRandomOrder()
            ->limit($limit)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }

    public function getStoryDetails(int $id): Story
    {
        $story = Story::with([
            'author' => fn ($a) => $a->withTrashed(),
            'category' => fn ($c) => $c->withTrashed(),
        ])->find($id);
        if ($story) {
            return $story;
        }
        throw new ModelNotFound;
    }

    public function getOtherStories(Story $story): Collection
    {
        return Story::published()
            ->where('id', '!=', $story->id)
            ->where('category_id', $story->category_id)
            ->inRandomOrder()
            ->limit(4)
            ->with([
                'author' => fn ($a) => $a->withTrashed(),
            ])
            ->get();
    }
    
    public function getSlugableStoryDetails(string $slug): Story
    {
        return Story::with([
            'author' => fn ($a) => $a->withTrashed(),
            'category' => fn ($c) => $c->withTrashed(),
        ])->where('slug_'.app()->getLocale(), $slug)
            ->firstOrFail();
    }

    public function eventPlay(int $id): void
    {
        Story::where('id', $id)->update([
            'total_plays' => DB::raw('total_plays + 1'),
        ]);

    }

    public function eventShare(int $id): void
    {
        Story::where('id', $id)->update([
            'total_shares' => DB::raw('total_shares + 1'),
        ]);

    }
}
