<?php

namespace App\Services;

use App\Exceptions\ModelNotFound;
use App\Http\Requests\Api\Books\HardCopyRequest;
use App\Http\Requests\Api\Books\PurchaseRequest;
use App\Integrations\Payments\PaymentFactory;
use App\Models\Book;
use App\Models\BookPurchase;
use App\Models\BookRequest;
use App\Models\Customer;
use App\Models\OnlinePayment;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BooksService
{
    public function getMostSold(
        Request $request
    ): LengthAwarePaginator {
        $request->merge(['most_sold' => true]);

        return $this->getBooks($request);
    }

    public function getMostRead(
        Request $request
    ): LengthAwarePaginator {
        $request->merge(['most_read' => true]);

        return $this->getBooks($request);
    }

    public function getFeatured(
        Request $request
    ): LengthAwarePaginator {
        $request->merge(['is_featured' => true]);

        return $this->getBooks($request);
    }

    public function getFiltered(
        Request $request
    ): LengthAwarePaginator {
        return $this->getBooks($request);
    }

    public function getBookDetails(int $id): Book
    {
        $book = Book::loadAllRelations()->published()->find($id);
        if ($book) {
            return $book;
        }
        throw new ModelNotFound;
    }

    public function getSlugableBookDetails(string $slug): Book
    {
        return Book::with([
            'author' => fn ($a) => $a->withTrashed(),
            'category' => fn ($c) => $c->withTrashed(),
        ])->where('slug_'.app()->getLocale(), $slug)
            ->firstOrFail();
    }

    public function getRandomBook(): ?Book
    {
        return Book::inRandomOrder()->published()->first();
    }

    public function eventView(int $id): void
    {
        Book::where('id', $id)->update(['total_views' => DB::raw('total_views + 1')]);
    }

    public function eventWebView(string $slug): void
    {
        Book::where('slug_'.app()->getLocale(), $slug)->update([
            'total_views' => DB::raw('total_views + 1'),
        ]);
    }

    public function eventShare(int $id): void
    {
        Book::where('id', $id)->update(['total_shares' => DB::raw('total_shares + 1')]);
    }

    public function hardCopy(HardCopyRequest $request, int $id): void
    {
        $book = Book::find($id);
        if ($book) {
            $data = $request->validated();
            $data['book_id'] = $id;
            BookRequest::create($data);
            $book->update(['total_hard_purchased' => $book->total_hard_purchased + 1]);
        }
    }

    public function purchase(
        PurchaseRequest $request,
        Customer $customer,
        int $id
    ): array {
        $book = Book::findOrFail($id);

        $payByWebPage = PaymentFactory::createPayment(
            $customer,
            $book->epob_price,
            $request->get('payment_id')
        )->payByWebPage();

        $bookPurchase = BookPurchase::create([
            'book_id' => $book->id,
            'customer_id' => $customer->id,
            'payment_id' => $request->get('payment_id'),
            'price' => $book->epob_price,
            'gateway_tracking' => $payByWebPage->gatewayTrackingNumber(),
        ]);

        OnlinePayment::create([
            'amount_in_cents' => $book->epob_price * 100,
            'gateway_tracking' => $payByWebPage->gatewayTrackingNumber(),
            'related_model' => BookPurchase::class,
            'related_model_id' => $bookPurchase->id,
        ]);

        return [
            'redirect_url' => $payByWebPage->getRedirectUrl(),
            'success_url' => $payByWebPage->getSuccessUrl(),
            'fail_url' => $payByWebPage->getFailureUrl(),
        ];
    }

    private function getBooks(
        Request $request
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');
        $category = $request->query('category');
        $author = $request->query('author');

        return Book::loadAllRelations()
            ->published()
            ->when($request->has('most_read'), fn ($q) => $q->mostRead())
            ->when($request->has('most_sold'), fn ($q) => $q->mostSold())
            ->when($request->has('is_home'), fn ($q) => $q->isHome())
            ->when($request->has('is_featured'), fn ($q) => $q->isFeatured())
            ->when($request->has('is_recommended'), fn ($q) => $q->isRecommended())
            ->when($search, fn ($q) => $q->search($search))
            ->when($category, fn ($q) => $q->where('category_id', $category))
            ->when($author, fn ($q) => $q->where('author_id', $author))
            ->when(! $request->has('most_read'), fn ($q) => $q->descOrder())
            ->when(! $request->has('most_sold'), fn ($q) => $q->descOrder())
            ->paginate($limit);
    }

    public function getFilteredAll(
        Request $request
    ): LengthAwarePaginator {
        $limit = $request->query('per_page', 10);
        $search = $request->query('search');
        $category = $request->query('category');
        $author = $request->query('author');

        return Book::loadAllRelations()
            ->published()
            ->requestTypeAll()
            ->when($request->has('most_read'), fn ($q) => $q->mostRead())
            ->when($request->has('most_sold'), fn ($q) => $q->mostSold())
            ->when($request->has('is_home'), fn ($q) => $q->isHome())
            ->when($request->has('is_featured'), fn ($q) => $q->isFeatured())
            ->when($request->has('is_recommended'), fn ($q) => $q->isRecommended())
            ->when($search, fn ($q) => $q->search($search))
            ->when($category, fn ($q) => $q->where('category_id', $category))
            ->when($author, fn ($q) => $q->where('author_id', $author))
            ->when(! $request->has('most_read'), fn ($q) => $q->descOrder())
            ->when(! $request->has('most_sold'), fn ($q) => $q->descOrder())
            ->paginate($limit);
    }
}
