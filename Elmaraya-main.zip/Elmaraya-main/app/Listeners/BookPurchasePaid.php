<?php

namespace App\Listeners;

use App\Enum\PaymentStatus;
use App\Events\OnlinePaymentPaid;
use App\Models\BookPurchase;

class BookPurchasePaid
{
    /**
     * Create the event listener.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     */
    public function handle(OnlinePaymentPaid $event): void
    {
        $onlinePayment = $event->getOnlinePayment();
        if ($onlinePayment->related_model == BookPurchase::class) {
            $bookPurchase = BookPurchase::find($onlinePayment->related_model_id);
            if ($bookPurchase && $bookPurchase->status == PaymentStatus::pending) {
                $bookPurchase->status = PaymentStatus::purchased;
                $bookPurchase->save();
            }
        }
    }
}
