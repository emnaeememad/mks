<?php

namespace App\Exceptions;

use Exception;

class ModelNotFound extends Exception
{
    public function __construct()
    {
        parent::__construct(__('api.model-not-found'), 404);
    }
}
