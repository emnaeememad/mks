<?php

namespace App\Exceptions;

use Exception;

class ValidationResponseException extends Exception
{
    public function __construct(
        private array $errors,
        protected $message = ''
    ) {
        parent::__construct($message ?? 'Validation errors', 422);
    }

    public function getErrors(): array
    {
        return $this->errors;
    }
}
