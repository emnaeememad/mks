<?php

namespace App\Exceptions;

use Exception;

class NonVerifiedCustomer extends Exception
{
    public function __construct()
    {
        parent::__construct(__('api.verify-account-first'), 469);
    }
}
