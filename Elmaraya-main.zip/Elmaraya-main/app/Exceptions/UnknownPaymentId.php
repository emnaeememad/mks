<?php

namespace App\Exceptions;

use Exception;

class UnknownPaymentId extends Exception
{
    public function __construct()
    {
        parent::__construct(__('payment.unknown-payment'), 404);
    }
}
