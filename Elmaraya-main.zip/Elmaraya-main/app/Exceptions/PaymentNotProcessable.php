<?php

namespace App\Exceptions;

use Exception;

class PaymentNotProcessable extends Exception
{
    public function __construct()
    {
        parent::__construct(__('payment.not-processable'), 400);
    }
}
