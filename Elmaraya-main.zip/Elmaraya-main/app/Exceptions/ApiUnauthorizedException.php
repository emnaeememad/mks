<?php

namespace App\Exceptions;

use Exception;

class ApiUnauthorizedException extends Exception
{
    public function __construct()
    {
        parent::__construct(__('api.login-first'), 401);
    }
}
