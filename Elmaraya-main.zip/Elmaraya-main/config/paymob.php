<?php

return [
    'api_key' => env('PAYMOB_API_KEY'),
    'api_base_url' => env('PAYMOB_API_BASE_URL'),
    'channel_id' => env('PAYMOB_CHANNEL_ID'),
    'iframe_link' => env('PAYMOB_IFRAME_LINK'),
    'hmac_secret' => env('PAYMOB_HMAC_SECRET'),
];
